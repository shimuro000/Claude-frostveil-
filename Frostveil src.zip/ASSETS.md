# ASSETS

Art assets still missing. Path, size, and what it should look like (only from the design document).

| Path | Size | Description |
|------|------|-------------|
| `assets/frostveil/textures/gui/menu_background.png` | 256x256 | PLACEHOLDER. Not yet created; main menu background, Frostveil theme. |
| `assets/frostveil/textures/entity/` | varies | PLACEHOLDER. GeckoLib models/textures for mobs and NPCs, not yet created. |
| `pack.png` | 128x128 | PLACEHOLDER. Mod logo, not yet created. |

| `assets/frostveil/textures/gui/title_background.png` | 1920x1080 | PLACEHOLDER. Title screen background: Tatsuma at dawn (snow, grey sky, round wooden houses, lantern light), per G2. |
| `assets/frostveil/textures/gui/hud/*.png` | 16x16 | PLACEHOLDER. Icons for Skin Sense, Forge, Shroud, Infuse, technique, Flow (HUD currently uses text and bars). |

No texture files are shipped in this first slice.
