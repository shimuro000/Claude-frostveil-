# Placeholder assets
Generated placeholders (replace with your art, same paths):
- `assets/frostveil/textures/item/*.png` item icons (16x16)
- `assets/frostveil/textures/mob_effect/*.png` effect icons (18x18)
- `assets/frostveil/textures/entity/ice.png` ice crystal texture used by every ice shape
- NPC skins: painted at runtime from `NpcDefs`; override with `textures/entity/npc/<id>.png` (64x64, classic arms)
- Beasts use vanilla cow/pig models tinted by kind (GeckoLib models are a later upgrade)
- Sounds: vanilla sounds are layered; no custom sound files yet
