package com.Ken.frostveil.client.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.util.Mth;

/** Mouse-wheel scrolling for a column of widgets: moves them, hides the ones outside the viewport (so nothing overlaps the fixed buttons). */
final class Scroller {
    private final List<AbstractWidget> ws = new ArrayList<>();
    private final List<Integer> ys = new ArrayList<>();
    private int scroll = 0, top = 0, bottom = 100, content = 0;

    void clear() { ws.clear(); ys.clear(); }
    void add(AbstractWidget w, int baseY) { ws.add(w); ys.add(baseY); }
    int offset() { return scroll; }
    int top() { return top; }
    int bottom() { return bottom; }

    void bounds(int top, int bottom, int contentBottom) {
        this.top = top; this.bottom = bottom; this.content = contentBottom - top;
        scroll = Mth.clamp(scroll, 0, Math.max(0, content - (bottom - top)));
        apply();
    }

    void apply() {
        for (int i = 0; i < ws.size(); i++) {
            AbstractWidget w = ws.get(i);
            w.setY(ys.get(i) - scroll);
            w.visible = w.getY() >= top && w.getY() + w.getHeight() <= bottom;
        }
    }

    boolean wheel(double delta) {
        int max = Math.max(0, content - (bottom - top));
        if (max <= 0) return false;
        int old = scroll;
        scroll = Mth.clamp(scroll - (int) (delta * 24), 0, max);
        if (old != scroll) apply();
        return true;
    }

    /** Thin scroll bar on the right edge of the viewport. */
    void bar(net.minecraft.client.gui.GuiGraphics g, int x) {
        int max = content - (bottom - top);
        if (max <= 0) return;
        int h = bottom - top;
        int bh = Math.max(14, h * h / content);
        int by = top + (int) ((h - bh) * (scroll / (float) max));
        g.fill(x, top, x + 3, bottom, 0x55000000);
        g.fill(x, by, x + 3, by + bh, 0xFF8FB4D6);
    }
}
