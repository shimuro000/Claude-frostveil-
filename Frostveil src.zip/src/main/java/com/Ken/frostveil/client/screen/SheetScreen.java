package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.ice.IceStyle;
import com.Ken.frostveil.ice.ShapeLimits;
import com.Ken.frostveil.network.FvNet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Character sheet: stats, control levels, techniques, ice playstyle and the perks it has unlocked. */
public class SheetScreen extends Screen {
    private static final String[] STATS = {"Aura Quantity", "Aura Output", "Aura Efficiency", "Strength", "Speed", "Endurance", "Perception", "Body Limit"};

    public SheetScreen() { super(Component.literal("Character")); }

    @Override
    protected void init() {
        for (int i = 0; i < STATS.length; i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal("+"), b -> FvNet.toServer(new FvNet.ActionMsg("point", idx))).bounds(190, 44 + i * 18, 18, 16).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Shape Studio (R)"), b -> minecraft.setScreen(new ShapeStudioScreen())).bounds(20, height - 34, 120, 20).build());
    }

    private float statValue(FvData d, int i) {
        return switch (i) { case 0 -> d.quantity; case 1 -> d.output; case 2 -> d.efficiency * 100f; case 3 -> d.strength; case 4 -> d.speed; case 5 -> d.endurance; case 6 -> d.perception; default -> d.bodyLimit; };
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        FvData d = FvCap.CLIENT;
        g.fillGradient(0, 0, width, height, 0xE00A1220, 0xE018304A);
        g.drawString(font, "Character  -  element: " + d.element + "  -  age stage " + d.ageStage, 20, 14, 0xFFDDF1FF, false);
        g.drawString(font, "Points to spend: " + d.points, 20, 28, 0xFF9AE0A8, false);
        for (int i = 0; i < STATS.length; i++) g.drawString(font, STATS[i] + ": " + String.format("%.1f", statValue(d, i)), 20, 48 + i * 18, 0xFFFFFFFF, false);
        int x = 250;
        g.drawString(font, "EIU control (the three levels)", x, 44, 0xFF9ED0FF, false);
        g.drawString(font, "1 Mental " + d.ctrlMental + "   2 Physical " + d.ctrlPhysical + "   3 External " + d.ctrlExternal, x, 58, 0xFFFFFFFF, false);
        ShapeLimits lim = ShapeLimits.of(d);
        g.drawString(font, String.format("Reach %.1f blocks  |  max length %.1f  |  max width %.1f  |  max volley %d", lim.reach(), lim.maxLength(), lim.maxWidth(), lim.maxCount()), x, 72, 0xFF8FB4D6, false);
        g.drawString(font, "Techniques: Skin Sense " + d.skinSenseStage + "  Forge " + d.forgeStage + "  Cutoff " + d.cutoffStage + "  Infuse " + d.infuseStage, x, 92, 0xFFFFFFFF, false);
        g.drawString(font, "Ice forms: " + (d.formUnlocked(0) ? "Solid Shaper " : "") + (d.formUnlocked(1) ? "Snowmaker " : "") + (d.formUnlocked(2) ? "Ice Halo" : ""), x, 106, 0xFFFFFFFF, false);
        g.drawString(font, "Your ice style (how you shape decides who you become)", x, 130, 0xFF9ED0FF, false);
        int total = 0;
        for (IceStyle s : IceStyle.values()) total += d.styleUses(s);
        int y = 146;
        for (IceStyle s : IceStyle.values()) {
            int n = d.styleUses(s);
            int w = (int) (120f * Math.min(1f, n / (float) IceStyle.PERK_AT));
            g.fill(x, y + 2, x + 120, y + 10, 0xFF22303F);
            g.fill(x, y + 2, x + w, y + 10, n >= IceStyle.PERK_AT ? 0xFF6BE3A0 : 0xFF58A6D6);
            g.drawString(font, s.title + "  " + n + "/" + IceStyle.PERK_AT + (n >= IceStyle.PERK_AT ? "  PERK: " + s.perk : ""), x + 128, y + 2, n >= IceStyle.PERK_AT ? 0xFF9AE0A8 : 0xFFB7D3EA, false);
            y += 16;
        }
        IceStyle dom = d.dominantStyle();
        g.drawString(font, dom == null ? "You have not formed a style yet." : "You are becoming a: " + dom.title + " (" + Math.round(100f * d.styleUses(dom) / Math.max(1, total)) + "% of your casts)", x, y + 8, 0xFFFFE08A, false);
        super.render(g, mx, my, pt);
    }
}
