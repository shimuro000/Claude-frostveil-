package com.Ken.frostveil.client;

import com.Ken.frostveil.client.fx.Juice;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.ice.ShapeSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Aura / Focus bars, rhythm ring, tracker with direction arrow, narrator captions, flash and vignettes. */
public final class Hud {
    private Hud() {}

    public static void render(GuiGraphics g, int w, int h, float pt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        FvData d = FvCap.CLIENT;
        long now = mc.level.getGameTime();
        // screen flash and hurt vignette
        if (Juice.flashAlpha > 0.02f) g.fill(0, 0, w, h, ((int) (Juice.flashAlpha * 160) << 24) | (Juice.flash & 0xFFFFFF));
        if (Juice.vignette > 0.02f) edge(g, w, h, 0xE01010, Juice.vignette);
        if (now < ClientState.flowUntil) edge(g, w, h, 0x7FD6FF, 0.55f);
        if (d.active() && d.created) {
            if (d.aura < d.quantity * 0.1f) edge(g, w, h, 0x101018, 0.7f); // Law 2: the world dims when aura runs out
            bars(g, w, h, d, now);
            ring(g, w, h, d);
            status(g, w, h, d);
            tracker(g, w, h, d, mc);
        }
        caption(g, w, h);
    }

    private static void edge(GuiGraphics g, int w, int h, int rgb, float a) {
        int n = 6;
        for (int i = 0; i < n; i++) {
            int al = (int) (a * 150 * (1f - i / (float) n));
            int c = (al << 24) | rgb;
            g.fill(i * 6, 0, i * 6 + 6, h, c); g.fill(w - i * 6 - 6, 0, w - i * 6, h, c);
            g.fill(0, i * 6, w, i * 6 + 6, c); g.fill(0, h - i * 6 - 6, w, h - i * 6, c);
        }
    }

    private static void bars(GuiGraphics g, int w, int h, FvData d, long now) {
        int x = 10, y = h - 62, bw = 110;
        float a = Mth.clamp(d.aura / Math.max(1f, d.quantity), 0, 1);
        g.fill(x - 1, y - 1, x + bw + 1, y + 7, 0xAA000000);
        g.fill(x, y, x + (int) (bw * a), y + 6, a < 0.15f ? 0xFFE05555 : 0xFF58C7F0);
        g.drawString(Minecraft.getInstance().font, "AURA " + (int) d.aura + "/" + (int) d.quantity, x, y - 10, 0xFFCDEBFF, true);
        float f = Mth.clamp(d.focus / 100f, 0, 1);
        g.fill(x - 1, y + 10, x + bw + 1, y + 15, 0xAA000000);
        g.fill(x, y + 11, x + (int) (bw * f), y + 14, f < 0.25f ? 0xFFE0A055 : 0xFFA8E6C8);
        float fl = Mth.clamp(d.flow / 100f, 0, 1);
        g.fill(x, y + 17, x + (int) (bw * fl), y + 19, now < ClientState.flowUntil ? 0xFFFFFFFF : 0xFF7FD6FF);
        if (d.fatigue > 1) g.drawString(Minecraft.getInstance().font, "Fatigue " + (int) d.fatigue, x, y + 22, 0xFFB0A090, true);
    }

    /** Level 2 rhythm ring: the outer ring shrinks while you hold F. Release when it meets the inner ring. */
    private static void ring(GuiGraphics g, int w, int h, FvData d) {
        if (!ClientEvents.isCharging() && !ClientEvents.isMeditating()) return;
        int cx = w / 2, cy = h / 2;
        if (ClientEvents.isMeditating()) {
            double ph = Math.sin(ClientEvents.meditationTicks() * Math.PI / 40.0) * 0.5 + 0.5;
            int r = 10 + (int) (14 * ph);
            dots(g, cx, cy, r, 0xFFA8E6C8, 28);
            g.drawString(Minecraft.getInstance().font, ClientEvents.meditationTicks() >= 60 ? "Feel it... release G" : "Breathe... hold G", cx - 40, cy + 34, 0xFFCDEBFF, true);
            return;
        }
        int held = ClientEvents.heldTicks();
        float t = Mth.clamp(held / 19f, 0f, 1.6f);
        int r = Math.max(8, Math.round(40 - 28 * Math.min(1f, t)));
        boolean perfect = Math.abs(held - 19) <= 1;
        dots(g, cx, cy, 12, perfect ? 0xFFFFFFFF : 0xFF7FD6FF, 20);
        dots(g, cx, cy, r, perfect ? 0xFFFFFFFF : 0xFFBFE8FF, 26);
        ShapeSpec s = FvCap.CLIENT.presets[FvCap.CLIENT.selected];
        g.drawString(Minecraft.getInstance().font, s.prim.key + (s.stroke ? " (freehand)" : ""), cx - 20, cy + 50, 0xFFCDEBFF, true);
    }

    private static void dots(GuiGraphics g, int cx, int cy, int r, int color, int n) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            int x = cx + (int) Math.round(Math.cos(a) * r), y = cy + (int) Math.round(Math.sin(a) * r);
            g.fill(x - 1, y - 1, x + 1, y + 1, color);
        }
    }

    private static void status(GuiGraphics g, int w, int h, FvData d) {
        StringBuilder sb = new StringBuilder();
        if (d.skinSenseOn) sb.append("[Skin Sense] ");
        if (d.forgeLimb != 0) sb.append("[Forge ").append(new String[]{"", "R-arm", "L-arm", "legs", "torso"}[d.forgeLimb]).append("] ");
        if (d.shroudOn) sb.append("[Shroud] ");
        if (d.infuseTicks > 0) sb.append("[Infused] ");
        if (d.haloOn) sb.append("[Halo ").append(d.haloShards).append("] ");
        if (d.guarding) sb.append("[Guard] ");
        ShapeSpec s = d.presets[Mth.clamp(d.selected, 0, d.presets.length - 1)];
        String slot = "Slot " + (d.selected + 1) + ": " + (s.form == 1 ? "Snowfield" : (s.form == 2 ? "Halo " : "") + s.prim.key + " " + s.behavior.name().toLowerCase());
        g.drawString(Minecraft.getInstance().font, slot, 10, h - 100, 0xFFB7D3EA, true);
        if (sb.length() > 0) g.drawString(Minecraft.getInstance().font, sb.toString(), 10, h - 88, 0xFF9AE0A8, true);
    }

    private static void tracker(GuiGraphics g, int w, int h, FvData d, Minecraft mc) {
        if (d.trackedTitle.isEmpty()) return;
        int x = w - 12;
        var f = mc.font;
        String t = d.trackedTitle, o = d.trackedObj;
        g.drawString(f, t, x - f.width(t), 12, 0xFFFFE08A, true);
        g.drawString(f, o, x - f.width(o), 24, 0xFFFFFFFF, true);
        if (d.trackedPos != 0) {
            BlockPos bp = BlockPos.of(d.trackedPos);
            Vec3 to = new Vec3(bp.getX() + 0.5 - mc.player.getX(), 0, bp.getZ() + 0.5 - mc.player.getZ());
            double dist = to.length();
            double ang = Math.atan2(-to.x, to.z) - Math.toRadians(mc.player.getYRot());
            String arrow = "^";
            int px = x - 20 + (int) Math.round(Math.sin(ang) * 14), py = 52 - (int) Math.round(Math.cos(ang) * 14);
            g.drawString(f, arrow, px, py, 0xFF9ED0FF, true);
            String dd = (int) dist + " m";
            g.drawString(f, dd, x - f.width(dd), 66, 0xFF8FB4D6, true);
        }
    }

    private static void caption(GuiGraphics g, int w, int h) {
        if (ClientState.captionTicks <= 0 || ClientState.caption.isEmpty()) return;
        float life = ClientState.captionTicks / (float) Math.max(1, ClientState.captionMax);
        float alpha = Mth.clamp(Math.min(life * 6f, (1f - life) * 6f), 0f, 1f);
        if (ClientState.captionBlack) g.fill(0, 0, w, h, ((int) (alpha * 230) << 24));
        else g.fill(0, h / 2 + 30, w, h / 2 + 30 + 14 + ClientState.caption.split("\n").length * 12, ((int) (alpha * 150) << 24));
        int y = ClientState.captionBlack ? h / 2 - 6 * ClientState.caption.split("\n").length : h / 2 + 36;
        for (String line : ClientState.caption.split("\n")) {
            g.drawCenteredString(Minecraft.getInstance().font, line, w / 2, y, ((int) (alpha * 255) << 24) | 0xE8F4FF);
            y += 12;
        }
    }
}
