package com.Ken.frostveil.client.fx;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.ClientState;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.PublicState;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.api.layered.modifier.AbstractFadeModifier;
import dev.kosmx.playerAnim.core.data.AnimationFormat;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.core.util.Ease;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;

/**
 * Player animation clips (PlayerAnimator). Each clip = a few key poses per body part: pitch / yaw / roll in radians
 * (negative pitch raises an arm forward). Edit the arrays to retune the feel; names are used by the combat/ice code.
 * Only the parts listed in a clip are overridden, so walking legs keep working during arm animations.
 */
public final class Anims {
    public static final ResourceLocation LAYER = Fv.id("anim");
    private static final Map<String, KeyframeAnimation> CLIPS = new HashMap<>();
    private static final Map<AbstractClientPlayer, String> ACTIVE = new HashMap<>();
    private static final Map<AbstractClientPlayer, Integer> OVERRIDE_UNTIL = new HashMap<>();
    private static final Map<AbstractClientPlayer, String> OVERRIDE = new HashMap<>();

    private Anims() {}

    private static float[] k(float... v) { return v; }

    private static void part(KeyframeAnimation.AnimationBuilder b, String name, int dur, boolean loop, float[] pitch, float[] yaw, float[] roll) {
        KeyframeAnimation.StateCollection c = b.getOrCreatePart(name);
        keys(c.pitch, pitch, dur, loop); keys(c.yaw, yaw, dur, loop); keys(c.roll, roll, dur, loop);
    }

    private static void keys(KeyframeAnimation.StateCollection.State ch, float[] v, int dur, boolean loop) {
        if (v == null || v.length == 0) return;
        for (int i = 0; i < v.length; i++) {
            int tick = v.length == 1 ? 0 : Math.round((float) (dur * i) / (float) (v.length - 1));
            ch.addKeyFrame(tick, v[i], i == 0 ? Ease.LINEAR : Ease.INOUTSINE);
        }
        if (v.length == 1) ch.addKeyFrame(dur, v[0], Ease.INOUTSINE);
    }

    private static KeyframeAnimation.AnimationBuilder begin(String name, int dur, boolean loop) {
        KeyframeAnimation.AnimationBuilder b = new KeyframeAnimation.AnimationBuilder(AnimationFormat.JSON_EMOTECRAFT).setName("frostveil." + name);
        b.beginTick = 0; b.endTick = dur; b.stopTick = dur; b.returnTick = 0; b.isLooped = loop;
        return b;
    }

    private static void def(String name, int dur, boolean loop, float[][] torso, float[][] rArm, float[][] lArm) {
        KeyframeAnimation.AnimationBuilder b = begin(name, dur, loop);
        if (torso != null) part(b, "torso", dur, loop, torso[0], torso[1], torso[2]);
        if (rArm != null) part(b, "rightArm", dur, loop, rArm[0], rArm[1], rArm[2]);
        if (lArm != null) part(b, "leftArm", dur, loop, lArm[0], lArm[1], lArm[2]);
        CLIPS.put(name, b.build());
    }

    static {
        // --- combat chain: three different swings so combos read clearly ---
        def("combo1", 9, false, new float[][]{k(0f, -0.25f, 0.2f, 0f), k(0f, 0.55f, -0.35f, 0f), k(0f)},
                new float[][]{k(-0.4f, -2.1f, 0.3f, 0f), k(0.5f, -0.2f, -0.5f, 0f), k(0f, 0.15f, 0.3f, 0f)}, new float[][]{k(0.1f, -0.2f, 0.1f, 0f), k(0f), k(0f)});
        def("combo2", 9, false, new float[][]{k(0f, 0.3f, -0.3f, 0f), k(0f, -0.5f, 0.35f, 0f), k(0f)},
                new float[][]{k(-0.2f, -1.2f, -0.4f, 0f), k(0.1f, -0.6f, 0.4f, 0f), k(0f)}, new float[][]{k(-0.5f, -2.0f, 0.4f, 0f), k(0.4f, -0.1f, -0.5f, 0f), k(0f, 0.2f, 0.3f, 0f)});
        def("combo3", 14, false, new float[][]{k(0f, -0.2f, 0.45f, 0.1f, 0f), k(0f), k(0f)},
                new float[][]{k(-0.2f, -2.7f, -2.9f, 0.4f, 0f), k(0f, 0.1f, 0.0f, 0f, 0f), k(0f)}, new float[][]{k(-0.2f, -2.5f, -2.8f, 0.3f, 0f), k(0f, -0.1f, 0f, 0f, 0f), k(0f)});
        def("heavy", 18, false, new float[][]{k(0f, 0.1f, -0.4f, 0.5f, 0.2f, 0f), k(0f, -0.5f, -0.5f, 0.6f, 0.1f, 0f), k(0f)},
                new float[][]{k(0f, -1.8f, -2.6f, 0.2f, 0f, 0f), k(0f, 0.3f, 0.3f, -0.3f, 0f, 0f), k(0f)}, new float[][]{k(0f, -1.5f, -2.4f, 0.1f, 0f, 0f), k(0f), k(0f)});
        def("guard", 20, true, new float[][]{k(0.12f, 0.15f, 0.12f), k(0f), k(0f)},
                new float[][]{k(-1.15f, -1.2f, -1.15f), k(-0.75f, -0.8f, -0.75f), k(0f)}, new float[][]{k(-1.15f, -1.2f, -1.15f), k(0.75f, 0.8f, 0.75f), k(0f)});
        def("dodge", 12, false, new float[][]{k(0f, 0.5f, 0.15f, 0f), k(0f, 0.25f, 0f, 0f), k(0f, 0.2f, 0f, 0f)},
                new float[][]{k(0f, 0.9f, 0.3f, 0f), k(0f), k(0f, 0.5f, 0f, 0f)}, new float[][]{k(0f, 0.9f, 0.3f, 0f), k(0f), k(0f, -0.5f, 0f, 0f)});
        // --- katana: quick, low, sweeping cuts ---
        def("katana1", 8, false, new float[][]{k(0f, 0.15f, 0f), k(-0.55f, 0.85f, 0f), k(0f)},
                new float[][]{k(-0.3f, -1.4f, -0.5f), k(-0.9f, 1.3f, 0f), k(0f)}, new float[][]{k(-0.4f, 0.2f, 0f), k(0.6f, 0.3f, 0f), k(0f)});
        def("katana2", 8, false, new float[][]{k(0.1f, -0.1f, 0f), k(0.5f, -0.75f, 0f), k(0f)},
                new float[][]{k(0.6f, -2.5f, -0.8f), k(0.8f, -0.4f, 0f), k(0f)}, new float[][]{k(0.2f, -0.2f, 0f), k(0.4f, 0.1f, 0f), k(0f)});
        def("katana3", 10, false, new float[][]{k(-0.25f, 0.5f, 0f), k(0f), k(0f)},
                new float[][]{k(-2.8f, 0.25f, -0.2f), k(0f), k(0f)}, new float[][]{k(-2.7f, 0.2f, -0.2f), k(0f), k(0f)});
        // --- ice shaping ---
        def("cast_charge", 24, true, new float[][]{k(-0.08f, -0.14f, -0.08f), k(0f), k(0f)},
                new float[][]{k(-1.35f, -1.45f, -1.35f), k(-0.4f, -0.3f, -0.4f), k(0f)}, new float[][]{k(-1.35f, -1.45f, -1.35f), k(0.4f, 0.3f, 0.4f), k(0f)});
        def("cast_release", 10, false, new float[][]{k(0.3f, 0.15f, 0f), k(0f), k(0f)},
                new float[][]{k(-1.57f, -1.65f, -1.2f, 0f), k(-0.1f, 0f, 0f, 0f), k(0f)}, new float[][]{k(-1.57f, -1.65f, -1.2f, 0f), k(0.1f, 0f, 0f, 0f), k(0f)});
        def("shape_hold", 40, true, new float[][]{k(0.1f, 0.14f, 0.1f), k(0.1f, -0.1f, 0.1f), k(0f)},
                new float[][]{k(-1.5f, -1.4f, -1.5f), k(-0.25f, 0.25f, -0.25f), k(0f)}, new float[][]{k(-0.5f, -0.6f, -0.5f), k(0.3f, 0.2f, 0.3f), k(0.2f)});
        def("halo_channel", 40, true, new float[][]{k(-0.05f, -0.1f, -0.05f), k(0f), k(0f)},
                new float[][]{k(-0.3f, -0.45f, -0.3f), k(0f), k(0.9f, 1.05f, 0.9f)}, new float[][]{k(-0.3f, -0.45f, -0.3f), k(0f), k(-0.9f, -1.05f, -0.9f)});
        // --- basic techniques ---
        def("skin_sense", 40, true, new float[][]{k(0.02f, 0.05f, 0.02f), k(0f), k(0f)},
                new float[][]{k(-0.35f, -0.45f, -0.35f), k(0f), k(0.35f, 0.45f, 0.35f)}, new float[][]{k(-0.35f, -0.45f, -0.35f), k(0f), k(-0.35f, -0.45f, -0.35f)});
        def("forge_flex", 24, true, new float[][]{k(0.1f, 0.14f, 0.1f), k(0f), k(0f)},
                new float[][]{k(-0.7f, -0.8f, -0.7f), k(-0.2f, -0.15f, -0.2f), k(0.3f, 0.4f, 0.3f)}, new float[][]{k(-0.3f, -0.4f, -0.3f), k(0.1f), k(-0.2f)});
        def("meditate", 60, true, new float[][]{k(0.22f, 0.26f, 0.22f), k(0f), k(0f)},
                new float[][]{k(-0.9f, -0.95f, -0.9f), k(-0.3f), k(0.1f)}, new float[][]{k(-0.9f, -0.95f, -0.9f), k(0.3f), k(-0.1f)});
        def("hurt", 8, false, new float[][]{k(0.35f, 0.1f, 0f), k(0f), k(0f)},
                new float[][]{k(0.3f, -0.2f, 0f), k(0f), k(0.6f, 0.2f, 0f)}, new float[][]{k(0.3f, -0.2f, 0f), k(0f), k(-0.6f, -0.2f, 0f)});
    }

    public static void registerFactory() {
        PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(LAYER, 42, player -> new ModifierLayer<IAnimation>());
    }

    /** Play a one-shot clip on the local player (attacks, casts, dodges...). */
    public static void play(AbstractClientPlayer p, String clip, int ticks) {
        OVERRIDE.put(p, clip);
        OVERRIDE_UNTIL.put(p, p.tickCount + ticks);
        ACTIVE.remove(p); // force restart
        apply(p, clip, 2);
        ACTIVE.put(p, clip);
    }

    public static String[] names() { return CLIPS.keySet().toArray(new String[0]); }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void apply(AbstractClientPlayer p, String clip, int blend) {
        Object data = PlayerAnimationAccess.getPlayerAssociatedData(p).get(LAYER);
        if (!(data instanceof ModifierLayer layer)) return;
        KeyframeAnimation anim = clip == null ? null : CLIPS.get(clip);
        if (anim == null) layer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(blend + 3, Ease.OUTCUBIC), null);
        else layer.replaceAnimationWithFade(AbstractFadeModifier.standardFadeIn(blend, Ease.OUTCUBIC), (IAnimation) new KeyframeAnimationPlayer(anim));
    }

    /** Called every tick for each player: pick the looping base pose from state (guard, skin sense, forge, halo, meditation). */
    public static void update(AbstractClientPlayer p, boolean local, boolean meditating, boolean charging, boolean shaping) {
        Integer until = OVERRIDE_UNTIL.get(p);
        if (until != null && p.tickCount < until) return; // a one-shot is playing
        PublicState st = local ? localState() : ClientState.pub(p.getUUID());
        String want = null;
        if (local && charging) want = shaping ? "shape_hold" : "cast_charge";
        else if (st.guard()) want = "guard";
        else if (meditating) want = "meditate";
        else if (st.haloOn()) want = "halo_channel";
        else if (st.forgeLimb() != 0) want = "forge_flex";
        else if (st.skinSense()) want = "skin_sense";
        String cur = ACTIVE.get(p);
        if ((want == null && cur == null) || (want != null && want.equals(cur))) return;
        apply(p, want, 6);
        if (want == null) ACTIVE.remove(p); else ACTIVE.put(p, want);
    }

    private static PublicState localState() {
        return new PublicState(FvCap.CLIENT.haloOn, FvCap.CLIENT.haloShards, 0, 1.6f, 0.9f, 0.3f, 0.5f, FvCap.CLIENT.forgeLimb, FvCap.CLIENT.skinSenseOn, FvCap.CLIENT.shroudOn, false, FvCap.CLIENT.guarding, com.Ken.frostveil.eiu.ElementInfo.index(FvCap.CLIENT.element));
    }
}
