package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.client.ClientState;
import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.network.FvNet;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * 3D character creator. The model on the right is your own player re-skinned live from the profile (SkinPainter), so every
 * change is visible at once. Story mode keeps Shimoro and only lets you pick outfit colours; Free World unlocks everything.
 */
public class CreatorScreen extends Screen {
    private static final int ROWS = 9;
    private final boolean story;
    private final CharacterProfile profile;
    private int page = 0;
    private float spin = 0f;
    private boolean dragging = false;
    private static final List<String> STORY_OPEN = List.of("coat_color", "shirt_color", "trim", "scarf");

    public CreatorScreen(boolean story) {
        super(Component.literal(story ? "Shimoro" : "Create your character"));
        this.story = story;
        FvData cur = FvCap.CLIENT;
        this.profile = story ? CharacterProfile.shimoro() : (cur.created ? cur.profile.copy() : CharacterProfile.defaults());
    }

    private static String pretty(String s) {
        String t = s.replace('_', ' ');
        return t.isEmpty() ? t : Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    @Override
    protected void init() {
        ClientState.preview = profile;
        clearWidgets();
        List<CharacterProfile.Option> opts = CharacterProfile.OPTIONS;
        int pages = (opts.size() + ROWS - 1) / ROWS;
        int top = 40;
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= opts.size()) break;
            CharacterProfile.Option o = opts.get(idx);
            boolean open = !story || STORY_OPEN.contains(o.key());
            int y = top + i * 24;
            Button l = Button.builder(Component.literal("<"), b -> step(o, -1)).bounds(150, y, 20, 20).build();
            Button r = Button.builder(Component.literal(">"), b -> step(o, 1)).bounds(260, y, 20, 20).build();
            l.active = open; r.active = open;
            addRenderableWidget(l); addRenderableWidget(r);
        }
        addRenderableWidget(Button.builder(Component.literal("Prev page"), b -> { page = Math.max(0, page - 1); init(); }).bounds(20, top + ROWS * 24 + 4, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Next page"), b -> { page = Math.min(pages - 1, page + 1); init(); }).bounds(104, top + ROWS * 24 + 4, 80, 20).build());
        Button hm = Button.builder(Component.literal("Height -"), b -> { profile.height = Mth.clamp(profile.height - 0.02f, 0.85f, 1.15f); }).bounds(190, top + ROWS * 24 + 4, 55, 20).build();
        Button hp = Button.builder(Component.literal("Height +"), b -> { profile.height = Mth.clamp(profile.height + 0.02f, 0.85f, 1.15f); }).bounds(248, top + ROWS * 24 + 4, 55, 20).build();
        hm.active = !story; hp.active = !story;
        addRenderableWidget(hm); addRenderableWidget(hp);
        Button rnd = Button.builder(Component.literal("Randomize"), b -> randomize()).bounds(20, top + ROWS * 24 + 28, 80, 20).build();
        rnd.active = !story;
        addRenderableWidget(rnd);
        addRenderableWidget(Button.builder(Component.literal(story ? "Begin the story" : "Create & enter the world"), b -> confirm()).bounds(width - 200, height - 34, 180, 22).build());
        if (FvCap.CLIENT.created) addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(width - 280, height - 34, 70, 22).build());
    }

    private void step(CharacterProfile.Option o, int dir) {
        List<String> v = o.values();
        int i = v.indexOf(o.get().apply(profile));
        String next = v.get(Math.floorMod(i + dir, v.size()));
        if (o.key().equals("eye_color") && next.equals("violet") && !story) next = v.get(Math.floorMod(i + 2 * dir, v.size())); // violet halo is not for players
        o.set().accept(profile, next);
    }

    private void randomize() {
        java.util.Random r = new java.util.Random();
        for (CharacterProfile.Option o : CharacterProfile.OPTIONS) {
            if (o.key().startsWith("parent")) continue;
            String v = o.values().get(r.nextInt(o.values().size()));
            if (v.equals("violet") && o.key().equals("eye_color")) v = "blue";
            o.set().accept(profile, v);
        }
    }

    private void confirm() {
        ClientState.preview = null;
        FvNet.toServer(new FvNet.ProfileMsg(profile.toTag(), story ? FvData.MODE_STORY : FvData.MODE_FREE));
        minecraft.setScreen(null);
    }

    @Override
    public void onClose() {
        ClientState.preview = null;
        super.onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xFF0A1220, 0xFF18304A);
        g.drawString(font, title, 20, 14, 0xFFDDF1FF, false);
        g.drawString(font, story ? "Story: you are Shimoro. Only outfit colours can be changed." : "Free World: every option is open. Parents decide your element.", 20, 26, 0xFF8FB4D6, false);
        List<CharacterProfile.Option> opts = CharacterProfile.OPTIONS;
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= opts.size()) break;
            CharacterProfile.Option o = opts.get(idx);
            int y = 40 + i * 24;
            g.drawString(font, pretty(o.key()), 20, y + 6, 0xFFB7D3EA, false);
            g.drawCenteredString(font, pretty(o.get().apply(profile)), 215, y + 6, 0xFFFFFFFF);
        }
        g.drawString(font, "Height: " + Math.round(174 * profile.height) + " cm  (page " + (page + 1) + ")", 20, 40 + ROWS * 24 + 52, 0xFF8FB4D6, false);
        if (!dragging) spin += 0.8f;
        int cx = width - 150, cy = height - 80;
        if (minecraft.player != null) {
            // the preview floats a little to the side and turns slowly; drag to rotate
            float fake = (float) Math.sin(Math.toRadians(spin)) * 70f;
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, cx, cy, 70, fake, -20f, minecraft.player);
        }
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dragX, double dragY) {
        if (button == 0 && x > width - 300) { dragging = true; spin += (float) dragX * 1.5f; return true; }
        return super.mouseDragged(x, y, button, dragX, dragY);
    }

    @Override public boolean mouseReleased(double x, double y, int b) { dragging = false; return super.mouseReleased(x, y, b); }
    @Override public boolean isPauseScreen() { return false; }
}
