package com.Ken.frostveil.client.fx;

import com.Ken.frostveil.client.render.IceRender;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** A bright crescent that sweeps through the air with every swing (different shape for each combo hit). */
public final class Slash {
    private record S(Vec3 c, Vec3 f, Vec3 r, Vec3 u, int style, int born) {}

    private static final List<S> LIST = new ArrayList<>();

    private Slash() {}

    /** style 0..2 = combo hits, 3 = heavy. */
    public static void add(LocalPlayer p, int style, int tick) {
        Vec3 f = p.getLookAngle();
        Vec3 r = f.cross(new Vec3(0, 1, 0));
        if (r.lengthSqr() < 1.0E-4) r = new Vec3(1, 0, 0);
        r = r.normalize();
        Vec3 u = r.cross(f).normalize();
        Vec3 c = p.getEyePosition().add(f.scale(0.25)).subtract(u.scale(0.3));
        LIST.add(new S(c, f, r, u, style, tick));
        if (LIST.size() > 8) LIST.remove(0);
    }

    public static void render(PoseStack ps, Vec3 cam, MultiBufferSource.BufferSource buf, float pt, int tick) {
        if (LIST.isEmpty()) return;
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(IceRender.TEX));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        LIST.removeIf(s -> tick - s.born() > 9);
        for (S s : LIST) {
            float age = tick - s.born() + pt;
            float reveal = Math.min(1f, age / 3f);
            float alpha = Math.max(0f, 1f - Math.max(0f, age - 3f) / 6f);
            float a0, a1, tilt, R = s.style() == 3 ? 2.7f : 2.2f;
            switch (s.style()) {
                case 0 -> { a0 = -1.0f; a1 = 1.0f; tilt = -0.45f; }
                case 1 -> { a0 = 1.0f; a1 = -1.0f; tilt = 0.45f; }
                case 2 -> { a0 = 1.2f; a1 = -0.35f; tilt = (float) Math.PI / 2f; }
                default -> { a0 = -1.55f; a1 = 1.55f; tilt = 0f; }
            }
            Vec3 rt = s.r().scale(Math.cos(tilt)).add(s.u().scale(Math.sin(tilt)));
            int N = 14;
            float end = a0 + (a1 - a0) * reveal;
            for (int i = 0; i < N; i++) {
                float t0 = (float) i / N, t1 = (float) (i + 1) / N;
                float th0 = a0 + (end - a0) * t0, th1 = a0 + (end - a0) * t1;
                float w0 = (float) Math.sin(Math.PI * t0) * 0.55f + 0.04f, w1 = (float) Math.sin(Math.PI * t1) * 0.55f + 0.04f;
                Vec3 d0 = s.f().scale(Math.cos(th0)).add(rt.scale(Math.sin(th0))), d1 = s.f().scale(Math.cos(th1)).add(rt.scale(Math.sin(th1)));
                Vec3[] v = {s.c().add(d0.scale(R)).subtract(cam), s.c().add(d1.scale(R)).subtract(cam), s.c().add(d1.scale(R - w1)).subtract(cam), s.c().add(d0.scale(R - w0)).subtract(cam)};
                float[][] uv = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
                float al = alpha * (0.35f + 0.65f * t1);
                for (int k = 0; k < 4; k++) vc.vertex(m, (float) v[k].x, (float) v[k].y, (float) v[k].z).color(0.9f, 0.97f, 1f, al).uv(uv[k][0], uv[k][1])
                        .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(15728880).normal(n, 0, 1, 0).endVertex();
            }
        }
        buf.endBatch(RenderType.entityTranslucent(IceRender.TEX));
    }
}
