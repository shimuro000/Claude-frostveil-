package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.client.render.IceRender;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.ice.IceShaping;
import com.Ken.frostveil.ice.IceStyle;
import com.Ken.frostveil.ice.ShapeLimits;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.network.FvNet;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * The Shape Studio: design your own ice. Pick a form (Solid Shaper / Snowmaker / Ice Halo), a base shape, then shape it with
 * length, width, curve, spread, spin and count. Choose what it does (launch / hold as a weapon / set as blocks / orbit) and whether
 * you draw it freehand. Save up to 8 recipes; in the world, press N to switch recipe and F to cast it.
 * What you can do is limited by your three control levels, so training widens the studio.
 */
public class ShapeStudioScreen extends Screen {
    private ShapeSpec spec;
    private int slot;
    private float spin = 0f;

    public ShapeStudioScreen() {
        super(Component.literal("Shape Studio"));
        FvData d = FvCap.CLIENT;
        slot = d.selected;
        spec = d.presets[slot].copy();
    }

    private static String pretty(String s) { return s.substring(0, 1).toUpperCase() + s.substring(1).toLowerCase(); }

    private static final class Slider extends AbstractSliderButton {
        private final String label; private final double min, max; private final Consumer<Double> cb; private final boolean integer;
        Slider(int x, int y, int w, String label, double min, double max, double cur, boolean integer, Consumer<Double> cb) {
            super(x, y, w, 16, Component.empty(), (Math.min(max, Math.max(min, cur)) - min) / Math.max(0.0001, max - min));
            this.label = label; this.min = min; this.max = max; this.cb = cb; this.integer = integer;
            updateMessage();
        }
        private double val() { double v = min + (max - min) * this.value; return integer ? Math.round(v) : Math.round(v * 20.0) / 20.0; }
        @Override protected void updateMessage() { setMessage(Component.literal(label + ": " + (integer ? String.valueOf((int) val()) : String.format("%.2f", val())))); }
        @Override protected void applyValue() { cb.accept(val()); }
    }

    @Override
    protected void init() {
        FvData d = FvCap.CLIENT;
        ShapeLimits lim = ShapeLimits.of(d);
        for (int i = 0; i < 8; i++) {
            final int s = i;
            Button b = Button.builder(Component.literal(String.valueOf(i + 1)), x -> { slot = s; spec = d.presets[s].copy(); FvNet.toServer(new FvNet.ActionMsg("slot", s)); rebuildWidgets(); }).bounds(14 + i * 22, 30, 20, 18).build();
            b.active = i != slot;
            addRenderableWidget(b);
        }
        String[] forms = {"Solid Shaper", "Snowmaker", "Ice Halo"};
        for (int f = 0; f < 3; f++) {
            final int ff = f;
            Button b = Button.builder(Component.literal(forms[f]), x -> { spec.form = ff; spec.behavior = ff == 1 ? ShapeSpec.Behavior.PLACE : (ff == 2 ? ShapeSpec.Behavior.ORBIT : ShapeSpec.Behavior.LAUNCH); rebuildWidgets(); }).bounds(14 + f * 82, 54, 80, 18).build();
            b.active = d.formUnlocked(f) && spec.form != f;
            addRenderableWidget(b);
        }
        if (spec.form != 1) {
            ShapeSpec.Prim[] ps = ShapeSpec.Prim.values();
            for (int i = 0; i < ps.length; i++) {
                final ShapeSpec.Prim p = ps[i];
                Button b = Button.builder(Component.literal(pretty(p.key)), x -> { spec.prim = p; rebuildWidgets(); }).bounds(14 + (i % 4) * 62, 78 + (i / 4) * 20, 60, 18).build();
                b.active = (spec.form != 0 || d.primUnlocked(p)) && spec.prim != p;
                addRenderableWidget(b);
            }
        }
        int y = 122;
        if (spec.form == 0) {
            addRenderableWidget(Button.builder(Component.literal("Does: " + pretty(spec.behavior.name())), x -> { ShapeSpec.Behavior[] bs = {ShapeSpec.Behavior.LAUNCH, ShapeSpec.Behavior.HOLD, ShapeSpec.Behavior.PLACE}; int i = 0; for (int k = 0; k < bs.length; k++) if (bs[k] == spec.behavior) i = k; spec.behavior = bs[(i + 1) % bs.length]; rebuildWidgets(); }).bounds(14, y, 120, 18).build());
        }
        if (spec.form != 2) {
            addRenderableWidget(Button.builder(Component.literal("Freehand: " + (spec.stroke ? "ON" : "off")), x -> { spec.stroke = !spec.stroke; rebuildWidgets(); }).bounds(138, y, 110, 18).build());
        }
        y += 22;
        if (spec.stroke || spec.form == 2) {
            String lab = spec.form == 2 ? "Pattern: " : "Stroke becomes: ";
            String val = spec.form == 2 ? new String[]{"Ring", "Spiral", "Shell"}[spec.extrude.ordinal()] : new String[]{"Wall (upright)", "Floor / bridge", "Blob / tunnel"}[spec.extrude.ordinal()];
            addRenderableWidget(Button.builder(Component.literal(lab + val), x -> { spec.extrude = ShapeSpec.Extrude.of((spec.extrude.ordinal() + 1) % 3); rebuildWidgets(); }).bounds(14, y, 234, 18).build());
            y += 22;
        }
        addRenderableWidget(new Slider(14, y, 234, spec.form == 1 ? "Snow depth / height" : "Length", 0.5, lim.maxLength(), spec.length, false, v -> spec.length = v.floatValue())); y += 18;
        addRenderableWidget(new Slider(14, y, 234, spec.form == 1 ? "Radius / brush width" : "Width", 0.5, lim.maxWidth(), spec.width, false, v -> spec.width = v.floatValue())); y += 18;
        if (spec.prim == ShapeSpec.Prim.BLADE || spec.prim == ShapeSpec.Prim.LANCE || spec.prim == ShapeSpec.Prim.WALL) { addRenderableWidget(new Slider(14, y, 234, "Curve", -1, 1, spec.curve, false, v -> spec.curve = v.floatValue())); y += 18; }
        if (spec.form != 1) {
            addRenderableWidget(new Slider(14, y, 234, spec.form == 2 ? "Orbit radius" : "Spread", 0, 1, spec.spread, false, v -> spec.spread = v.floatValue())); y += 18;
            addRenderableWidget(new Slider(14, y, 234, "Spin", 0, 1, spec.spin, false, v -> spec.spin = v.floatValue())); y += 18;
            addRenderableWidget(new Slider(14, y, 234, spec.form == 2 ? "Shards" : "Count (volley)", 1, lim.maxCount(), spec.count, true, v -> spec.count = v.intValue())); y += 18;
        }
        addRenderableWidget(Button.builder(Component.literal("Save to slot " + (slot + 1)), b -> FvNet.toServer(new FvNet.SaveSpecMsg(slot, spec))).bounds(14, height - 30, 110, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose()).bounds(130, height - 30, 60, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        FvData d = FvCap.CLIENT;
        g.fillGradient(0, 0, width, height, 0xF00A1220, 0xF018304A);
        g.drawString(font, "Shape Studio  -  design your own ice", 14, 12, 0xFFDDF1FF, false);
        ShapeLimits lim = ShapeLimits.of(d);
        int px = 270, pw = width - px - 14;
        g.fill(px, 30, px + pw, 30 + 150, 0xFF0E1A2A);
        spin += 1.2f;
        wire(g, px + pw / 2, 105, Math.min(pw, 150) / 2f - 8);
        float est = IceShaping.baseCost(spec);
        g.drawString(font, String.format("Base cost ~ %.1f aura   |   hit ~ %.1f", est, IceShaping.damageOf(spec, 1.2f, d)), px, 188, 0xFFB7D3EA, false);
        g.drawString(font, String.format("Reach %.1f  |  max length %.1f  |  max volley %d", lim.reach(), lim.maxLength(), lim.maxCount()), px, 200, 0xFF8FB4D6, false);
        IceStyle st = spec.style();
        g.drawString(font, "This trains: " + st.title + "  (" + d.styleUses(st) + "/" + IceStyle.PERK_AT + ")", px, 214, 0xFFFFE08A, false);
        g.drawWordWrap(font, Component.literal("Perk: " + st.perk), px, 228, pw, 0xFF9AE0A8);
        g.drawWordWrap(font, Component.literal("In the world: F charges (longer = clearer), release near the ring peak for a perfect cast. N cycles recipes."), px, 262, pw, 0xFF8FB4D6);
        super.render(g, mx, my, pt);
    }

    /** Rotating wireframe of the exact mesh that will be drawn in the world. */
    private void wire(GuiGraphics g, int cx, int cy, float radius) {
        List<float[]> quads = IceRender.mesh(spec);
        float maxR = 0.4f;
        for (float[] q : quads) for (int i = 0; i < 4; i++) maxR = Math.max(maxR, (float) Math.sqrt(q[i * 3] * q[i * 3] + q[i * 3 + 1] * q[i * 3 + 1] + (q[i * 3 + 2] - mid()) * (q[i * 3 + 2] - mid())));
        float sc = radius / maxR;
        double yaw = Math.toRadians(spin), pit = Math.toRadians(-24);
        double cyaw = Math.cos(yaw), syaw = Math.sin(yaw), cp = Math.cos(pit), sp = Math.sin(pit);
        for (float[] q : quads) {
            int[][] pts = new int[4][2];
            for (int i = 0; i < 4; i++) {
                double x = q[i * 3], y = q[i * 3 + 1], z = q[i * 3 + 2] - mid();
                double x1 = x * cyaw + z * syaw, z1 = -x * syaw + z * cyaw;
                double y2 = y * cp - z1 * sp;
                pts[i][0] = cx + (int) (x1 * sc);
                pts[i][1] = cy - (int) (y2 * sc);
            }
            for (int i = 0; i < 4; i++) line(g, pts[i][0], pts[i][1], pts[(i + 1) % 4][0], pts[(i + 1) % 4][1], 0xFF9AD6FF);
        }
    }

    private float mid() { return spec.prim == ShapeSpec.Prim.SPHERE || spec.prim == ShapeSpec.Prim.DISC || spec.prim == ShapeSpec.Prim.WALL ? 0f : spec.length * 0.5f; }

    private static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        int dx = x1 - x0, dy = y1 - y0;
        int steps = Math.max(Math.abs(dx), Math.abs(dy)) / 2;
        if (steps <= 0) { g.fill(x0, y0, x0 + 1, y0 + 1, color); return; }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + dx * i / steps, y = y0 + dy * i / steps;
            g.fill(x, y, x + 1, y + 1, color);
        }
    }
}
