package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.network.FvNet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;

/** Visual-novel style dialogue box with choices. The server decides what comes next; this screen only shows and answers. */
public class DialogueScreen extends Screen {
    private int entityId;
    private CompoundTag node;
    private int shown = 0;

    public DialogueScreen(int entityId, CompoundTag node) {
        super(Component.empty());
        this.entityId = entityId;
        this.node = node;
    }

    public void show(int entityId, CompoundTag node) {
        this.entityId = entityId;
        this.node = node;
        this.shown = 0;
        rebuildWidgets();
    }

    @Override
    protected void init() {
        ListTag ch = node.getList("choices", Tag.TAG_STRING);
        int n = ch.size();
        if (n == 0) {
            addRenderableWidget(Button.builder(Component.literal("Continue"), b -> send(0)).bounds(width / 2 - 50, height - 34, 100, 20).build());
            return;
        }
        for (int i = 0; i < n; i++) {
            final int idx = i;
            String t = ch.getString(i);
            Button b = Button.builder(Component.literal(t.equals("\u0000") ? "(locked)" : t), x -> send(idx)).bounds(width / 2 - 150, height - 34 - (n - 1 - i) * 22 - 0, 300, 20).build();
            b.active = !t.equals("\u0000");
            addRenderableWidget(b);
        }
    }

    private void send(int idx) { FvNet.toServer(new FvNet.ChoiceMsg(entityId, idx)); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int n = Math.max(1, node.getList("choices", Tag.TAG_STRING).size());
        int boxTop = height - 54 - n * 22 - 40;
        g.fill(40, boxTop, width - 40, height - 40 - (n - 1) * 22, 0xCC0A1220);
        g.fill(40, boxTop, width - 40, boxTop + 1, 0xFF8FB4D6);
        g.drawString(font, node.getString("speaker"), 54, boxTop + 8, 0xFF9ED0FF, false);
        String text = node.getString("text");
        shown = Math.min(text.length(), shown + 2);
        g.drawWordWrap(font, Component.literal(text.substring(0, shown)), 54, boxTop + 22, width - 108, 0xFFFFFFFF);
        super.render(g, mx, my, pt);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
