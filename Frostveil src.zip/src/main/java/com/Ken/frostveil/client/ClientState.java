package com.Ken.frostveil.client;

import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.PublicState;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;

/** Everything the client knows about other players and transient UI state. */
public final class ClientState {
    public static final Map<UUID, CharacterProfile> PROFILES = new HashMap<>();
    public static final Map<UUID, Integer> AGES = new HashMap<>();
    public static final Map<UUID, Integer> MODES = new HashMap<>();
    public static final Map<UUID, PublicState> PUBLIC = new HashMap<>();

    /** While the creator screen is open the local player shows this profile (live preview). */
    public static CharacterProfile preview = null;

    public static String caption = "";
    public static int captionTicks = 0, captionMax = 0;
    public static boolean captionBlack = false;

    public static CompoundTag journal = new CompoundTag();
    public static long flowUntil = 0;
    public static int combo = 0;
    public static long comboTick = -999;

    private ClientState() {}

    public static PublicState pub(UUID id) { return PUBLIC.getOrDefault(id, PublicState.NONE); }

    public static float scaleOf(UUID id) {
        CharacterProfile p = PROFILES.get(id);
        if (p == null || PROFILES.get(id) == null || MODES.getOrDefault(id, 0) == 0) return 1f;
        return p.effectiveScale(AGES.getOrDefault(id, 15));
    }

    public static final class Number {
        public final double x, y, z; public final float value; public final int color; public int age = 0; public final boolean big;
        public Number(double x, double y, double z, float value, int color, boolean big) { this.x = x; this.y = y; this.z = z; this.value = value; this.color = color; this.big = big; }
    }

    public static final List<Number> NUMBERS = new ArrayList<>();
}
