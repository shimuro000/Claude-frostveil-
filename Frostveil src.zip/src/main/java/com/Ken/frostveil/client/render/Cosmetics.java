package com.Ken.frostveil.client.render;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.SkinPainter;
import com.Ken.frostveil.data.CharacterProfile;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 3D character details with simple physics, drawn as small boxes on top of the painted skin:
 * hair (strands that swing with movement, turning and wind), coat tails / cloak / scarf (panels that flow when you walk and run),
 * fur collar, bag and backpack, and the face (3D eyes that blink, eyebrows that react, nose, mouth).
 * Physics = one damped spring per strand segment, driven by the entity's real movement. Tune the numbers in STIFF / DAMP / the style tables.
 * Used for players, NPCs and enemies (any LivingEntity with a CharacterProfile).
 */
public final class Cosmetics {
    static final ResourceLocation WHITE = Fv.id("textures/entity/white.png");
    private static final float STIFF = 0.16f, DAMP = 0.22f;

    /** One chain of segments hanging from an anchor. */
    private static final class Chain {
        final int n;
        final float[] ax, vx, az, vz, pax, paz;
        Chain(int n) { this.n = n; ax = new float[n]; vx = new float[n]; az = new float[n]; vz = new float[n]; pax = new float[n]; paz = new float[n]; }

        void step(float tx, float tz, float stiff, float damp, float follow) {
            for (int i = 0; i < n; i++) {
                pax[i] = ax[i]; paz[i] = az[i];
                float targetX = tx * (i == 0 ? 0.55f : 0.35f) + (i > 0 ? ax[i - 1] * follow : 0f);
                float targetZ = tz * (i == 0 ? 0.55f : 0.35f) + (i > 0 ? az[i - 1] * follow : 0f);
                vx[i] += (targetX - ax[i]) * stiff - vx[i] * damp;
                vz[i] += (targetZ - az[i]) * stiff - vz[i] * damp;
                ax[i] = Mth.clamp(ax[i] + vx[i], -1.25f, 1.25f);
                az[i] = Mth.clamp(az[i] + vz[i], -1.25f, 1.25f);
            }
        }
    }

    private static final class Sim {
        final Map<String, Chain> chains = new HashMap<>();
        int lastTick = -1, seen = 0;
        double lx, ly, lz;
        float lyaw;
        float fwd, side, dy, turn, limb, limbAmt;

        Chain chain(String key, int n) { return chains.computeIfAbsent(key, k -> new Chain(n)); }
    }

    private static final Map<Integer, Sim> SIMS = new HashMap<>();

    private Cosmetics() {}

    // ------------------------------------------------------------------ box helper
    private static void box(PoseStack ps, VertexConsumer vc, int light, float x0, float y0, float z0, float x1, float y1, float z1, int rgb, float a, float shade) {
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float r = ((rgb >> 16) & 255) / 255f * shade, g = ((rgb >> 8) & 255) / 255f * shade, b = (rgb & 255) / 255f * shade;
        float[][] faces = {
                {x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, 1.0f},   // top (model +y is down, so y0 is the top)
                {x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, 0.55f},   // bottom
                {x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0, 0, 0, -1, 0.85f},  // front
                {x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1, 0, 0, 1, 0.7f},    // back
                {x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1, -1, 0, 0, 0.75f},  // side
                {x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0, 1, 0, 0, 0.75f}};  // side
        float[][] uv = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
        for (float[] f : faces) {
            float sh = f[15];
            for (int i = 0; i < 4; i++) {
                vc.vertex(m, f[i * 3], f[i * 3 + 1], f[i * 3 + 2]).color(Math.min(1f, r * sh), Math.min(1f, g * sh), Math.min(1f, b * sh), a).uv(uv[i][0], uv[i][1])
                        .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, f[12], f[13], f[14]).endVertex();
            }
        }
    }

    private static void hang(PoseStack ps, VertexConsumer vc, int light, Chain c, float x, float y, float z, float len, float w, float d, int rgb, int rgbEnd, float baseX, float baseZ, float partial) {
        ps.pushPose();
        ps.translate(x, y, z);
        for (int i = 0; i < c.n; i++) {
            float ax = Mth.lerp(partial, c.pax[i], c.ax[i]) + (i == 0 ? baseX : 0f);
            float az = Mth.lerp(partial, c.paz[i], c.az[i]) + (i == 0 ? baseZ : 0f);
            ps.mulPose(Axis.XP.rotation(ax));
            ps.mulPose(Axis.ZP.rotation(az));
            float taper = 1f - 0.3f * i / Math.max(1, c.n);
            box(ps, vc, light, -w * 0.5f * taper, 0, -d * 0.5f * taper, w * 0.5f * taper, len, d * 0.5f * taper, i == c.n - 1 ? rgbEnd : rgb, 1f, 1f);
            ps.translate(0, len, 0);
        }
        ps.popPose();
    }

    // ------------------------------------------------------------------ the layer
    public static final class Layer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
        private final Function<T, CharacterProfile> look;

        public Layer(RenderLayerParent<T, M> parent, Function<T, CharacterProfile> look) {
            super(parent);
            this.look = look;
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, T e, float limbSwing, float limbAmt, float partial, float age, float headYaw, float headPitch) {
            CharacterProfile p = look.apply(e);
            if (p == null || e.isInvisible()) return;
            Sim sim = SIMS.computeIfAbsent(e.getId(), k -> new Sim());
            sim.seen = e.tickCount;
            update(sim, e, limbSwing, limbAmt);
            if (SIMS.size() > 160) SIMS.entrySet().removeIf(en -> Math.abs(en.getValue().seen - e.tickCount) > 400);
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(WHITE));
            int hairC = SkinPainter.hair(p.hairColor), hlC = SkinPainter.highlight(p.highlight), skinC = SkinPainter.skin(p.skin);

            ps.pushPose();
            getParentModel().head.translateAndRotate(ps);
            ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
            drawHair(ps, vc, light, p, sim, e, hairC, hlC, partial);
            drawFace(ps, buf, vc, light, p, e, skinC, hairC, partial);
            drawHat(ps, vc, light, p, sim, partial);
            drawMask(ps, vc, light, p);
            ps.popPose();

            ps.pushPose();
            getParentModel().body.translateAndRotate(ps);
            ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
            boolean pack = p.lanternBackpack || e.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST).is(com.Ken.frostveil.registry.ModItems.LANTERN_BACKPACK.get());
            drawClothes(ps, vc, light, p, sim, partial, pack);
            drawBodyExtras(ps, vc, light, p, sim, partial);
            ps.popPose();

            for (int side = 0; side < 2; side++) { // arms: gloves, straps, fur cuffs
                ps.pushPose();
                (side == 0 ? getParentModel().rightArm : getParentModel().leftArm).translateAndRotate(ps);
                ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
                drawArm(ps, vc, light, p, side == 1);
                ps.popPose();
                ps.pushPose();
                (side == 0 ? getParentModel().rightLeg : getParentModel().leftLeg).translateAndRotate(ps);
                ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
                drawLeg(ps, vc, light, p);
                ps.popPose();
            }
        }
    }

    private static void update(Sim s, LivingEntity e, float limbSwing, float limbAmt) {
        if (s.lastTick == e.tickCount) return;
        boolean first = s.lastTick < 0;
        s.lastTick = e.tickCount;
        double dx = first ? 0 : e.getX() - s.lx, dz = first ? 0 : e.getZ() - s.lz, dy = first ? 0 : e.getY() - s.ly;
        s.lx = e.getX(); s.ly = e.getY(); s.lz = e.getZ();
        float yaw = e.yBodyRot;
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        s.fwd = (float) Mth.clamp(dx * fx + dz * fz, -0.6, 0.6);
        s.side = (float) Mth.clamp(dx * Math.cos(rad) + dz * Math.sin(rad), -0.6, 0.6);
        s.dy = (float) Mth.clamp(dy, -1.0, 1.0);
        s.turn = first ? 0f : Mth.clamp(Mth.wrapDegrees(yaw - s.lyaw), -30f, 30f);
        s.lyaw = yaw;
        s.limb = limbSwing; s.limbAmt = limbAmt;
        float wind = (float) Math.sin(e.tickCount * 0.07 + e.getId()) * 0.05f + (float) Math.sin(e.tickCount * 0.19 + e.getId() * 2) * 0.025f;
        float tx = s.fwd * 3.4f + wind - (s.dy < -0.1f ? 0.35f : 0f) + (e.isCrouching() ? 0.15f : 0f);
        float tz = s.side * 3.4f - s.turn * 0.02f + wind * 0.6f;
        for (Map.Entry<String, Chain> en : s.chains.entrySet()) {
            String k = en.getKey();
            boolean cloth = k.startsWith("c");
            float swing = cloth ? (float) Math.sin(s.limb * 0.6662f + (k.endsWith("l") ? 0 : Math.PI)) * s.limbAmt * 0.55f : 0f;
            en.getValue().step(tx + swing, tz, cloth ? 0.2f : STIFF, cloth ? 0.26f : DAMP, cloth ? 0.55f : 0.45f);
        }
    }

    // ------------------------------------------------------------------ hair
    private static void row(PoseStack ps, VertexConsumer vc, int light, Sim sim, String key, int count, float x0, float x1, float y, float z, int n, float len, float w, float d,
                            int hair, int hl, int hlEvery, float bx, float pt) {
        for (int i = 0; i < count; i++) {
            float x = count == 1 ? (x0 + x1) / 2f : x0 + (x1 - x0) * i / (count - 1);
            boolean streak = hl >= 0 && hlEvery > 0 && i % hlEvery == 1;
            hang(ps, vc, light, sim.chain(key + i, n), x, y, z, len, w, d, streak ? hl : hair, SkinPainter.shade(hair, 0.82f), bx, 0f, pt);
        }
    }

    private static void drawHair(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, LivingEntity e, int hair, int hl, float pt) {
        if (p.hair.equals("bald")) return;
        int crown = SkinPainter.shade(hair, 1.2f), dark = SkinPainter.shade(hair, 0.8f);
        // scalp with a lighter crown highlight
        box(ps, vc, light, -4.55f, -8.75f, -4.55f, 4.55f, -6.7f, 4.55f, hair, 1f, 1f);
        box(ps, vc, light, -2.6f, -8.9f, -3.0f, 2.6f, -8.6f, 2.2f, crown, 1f, 1f);
        boolean longish = p.hair.equals("long_hanging") || p.hair.equals("ponytail") || p.hair.equals("three_ties");
        if (p.hair.equals("long_hanging")) box(ps, vc, light, -4.6f, -8.2f, 3.8f, 4.6f, -2.5f, 5.0f, hair, 1f, 1f);
        else if (longish || p.hair.equals("wolf_cut") || p.hair.equals("curly")) box(ps, vc, light, -4.6f, -8.2f, 3.8f, 4.6f, -4.8f, 4.9f, hair, 1f, 1f);
        // fringe, parted in the middle. It ends above the eyebrows (y = -6.4) so the eyes are never covered.
        if (!p.hair.equals("topknot")) {
            for (int i = 0; i < 7; i++) {
                float x = -3.75f + i * 1.25f;
                float side = x < 0 ? -1f : (x > 0 ? 1f : 0f);
                float len = 0.9f + Math.abs(x) / 3.75f * 0.45f; // two segments: total 1.8 .. 2.7 px (outer strands are a little longer)
                hang(ps, vc, light, sim.chain("fr" + i, 2), x, -8.6f, -4.4f, Math.min(len, 1.05f), 1.4f, 0.9f, (hl >= 0 && (i == 1 || i == 5)) ? hl : hair, dark, -0.12f, -side * 0.2f, pt);
            }
        }
        // locks in front of and behind the ears (frame the face without touching the eyes)
        for (int s = -1; s <= 1; s += 2) {
            hang(ps, vc, light, sim.chain("sl" + s, 4), 4.4f * s, -8.0f, -2.3f, 1.45f, 1.1f, 1.5f, hair, hl >= 0 ? hl : hair, 0f, -0.04f * s, pt);
            hang(ps, vc, light, sim.chain("sb" + s, 4), 4.4f * s, -7.6f, 1.2f, 1.4f, 1.1f, 2.0f, hair, dark, 0f, -0.05f * s, pt);
        }
        switch (p.hair) {
            case "long_hanging" -> {
                row(ps, vc, light, sim, "L1_", 11, -4.4f, 4.4f, -7.0f, 4.3f, 7, 2.2f, 1.25f, 1.3f, hair, hl, 3, 0.03f, pt);
                row(ps, vc, light, sim, "L2_", 8, -3.6f, 3.6f, -6.0f, 5.0f, 6, 2.1f, 1.4f, 1.1f, hair, hl, 4, 0.05f, pt);
            }
            case "ponytail" -> {
                box(ps, vc, light, -1.8f, -8.2f, 3.8f, 1.8f, -5.2f, 5.8f, hair, 1f, 1f);
                row(ps, vc, light, sim, "P_", 3, -1.1f, 1.1f, -7.2f, 5.4f, 7, 2.3f, 1.5f, 1.7f, hair, hl, 2, 0.45f, pt);
                box(ps, vc, light, -1.2f, -6.2f, 4.6f, 1.2f, -5.5f, 6.0f, 0xC03030, 1f, 1f);
            }
            case "three_ties" -> {
                for (int i = -1; i <= 1; i++) {
                    row(ps, vc, light, sim, "T" + (i + 1) + "_", 1, 2.9f * i, 2.9f * i, -7.0f, 4.5f, 7, 2.0f, 1.7f, 1.5f, hair, hl, 0, 0.1f, pt);
                    box(ps, vc, light, 2.9f * i - 1.0f, -5.4f, 3.9f, 2.9f * i + 1.0f, -4.6f, 5.5f, 0xC03030, 1f, 1f);
                }
            }
            case "topknot" -> {
                box(ps, vc, light, -2.4f, -12.0f, -1.8f, 2.4f, -8.4f, 3.0f, hair, 1f, 1f);
                box(ps, vc, light, -2.0f, -10.6f, -2.2f, 2.0f, -9.6f, 3.4f, 0xC03030, 1f, 1f);
                row(ps, vc, light, sim, "K_", 3, -1.0f, 1.0f, -11.4f, 3.0f, 3, 2.0f, 1.4f, 1.4f, hair, hl, 2, 0.3f, pt);
                row(ps, vc, light, sim, "KB_", 7, -3.9f, 3.9f, -6.9f, 4.2f, 3, 1.7f, 1.4f, 1.0f, hair, hl, 3, 0.04f, pt);
            }
            case "messy" -> {
                java.util.Random r = new java.util.Random(e.getId() * 977L + p.hairColor.hashCode());
                for (int i = 0; i < 14; i++) {
                    float x = -3.9f + r.nextFloat() * 7.8f, z = -3.4f + r.nextFloat() * 6.8f;
                    float bx = z < 0 ? 0.55f + r.nextFloat() * 0.5f : -0.5f - r.nextFloat() * 0.5f, bz = x > 0 ? -0.5f - r.nextFloat() * 0.4f : 0.5f + r.nextFloat() * 0.4f;
                    hang(ps, vc, light, sim.chain("m" + i, 2), x, -8.5f, z, 1.4f + r.nextFloat() * 0.9f, 1.5f, 1.5f, (hl >= 0 && i % 3 == 0) ? hl : hair, dark, bx, bz, pt);
                }
                row(ps, vc, light, sim, "MB_", 7, -3.9f, 3.9f, -6.8f, 4.3f, 3, 1.5f, 1.4f, 1.1f, hair, hl, 3, 0.04f, pt);
            }
            case "wolf_cut" -> {
                row(ps, vc, light, sim, "W1_", 9, -4.2f, 4.2f, -6.8f, 4.3f, 4, 1.9f, 1.4f, 1.2f, hair, hl, 3, 0.06f, pt);
                row(ps, vc, light, sim, "W2_", 6, -3.0f, 3.0f, -5.4f, 5.0f, 3, 1.8f, 1.5f, 1.0f, hair, hl, 2, 0.09f, pt);
                for (int s = -1; s <= 1; s += 2) row(ps, vc, light, sim, "WS" + s, 2, 4.7f * s, 4.7f * s, -6.0f, -0.4f, 3, 1.8f, 1.0f, 3.2f, hair, hl, 0, 0.02f, pt);
            }
            case "curly" -> {
                java.util.Random r = new java.util.Random(p.hairColor.hashCode() * 31L + e.getId());
                for (int i = 0; i < 18; i++) {
                    double a2 = i * Math.PI * 2 / 18.0;
                    float x = (float) Math.cos(a2) * 4.3f, z = (float) Math.sin(a2) * 4.3f;
                    hang(ps, vc, light, sim.chain("cu" + i, 3), x, -7.4f + r.nextFloat() * 1.8f, z, 1.4f, 2.2f, 2.2f, (hl >= 0 && i % 4 == 0) ? hl : hair, dark, 0.12f, 0f, pt);
                }
                box(ps, vc, light, -4.9f, -9.6f, -4.9f, 4.9f, -7.4f, 4.9f, hair, 1f, 1f);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ face
    private static void drawFace(PoseStack ps, MultiBufferSource buf, VertexConsumer vc, int light, CharacterProfile p, LivingEntity e, int skin, int hair, float pt) {
        int eye = SkinPainter.eye(p.eyeColor);
        boolean violet = p.eyeColor.equals("violet");
        boolean female = p.bodyType.equals("female");
        float W = p.eyeShape.equals("sharp") ? 2.9f : (p.eyeShape.equals("soft") ? 2.6f : 2.8f);
        float H = p.eyeShape.equals("sharp") ? 1.9f : (p.eyeShape.equals("soft") ? 2.3f : 2.6f);
        boolean blink = ((e.tickCount + e.getId() * 13) % 96) < 4 || e.isSleeping();
        float hh = blink ? 0.3f : H;
        float ey = -3.3f, ex = 2.25f;
        int lid = SkinPainter.shade(skin, 0.78f), lash = 0x16161C;
        for (int s = -1; s <= 1; s += 2) {
            float x = ex * s;
            // eyeball, iris (darker on top, brighter below), pupil and two sparkles
            box(ps, vc, light, x - W / 2, ey - hh / 2, -4.1f, x + W / 2, ey + hh / 2, -4.0f, 0xF6F6FA, 1f, 1f);
            if (!blink) {
                int lt = violet ? 15728880 : light;
                float iw = W * 0.62f, ih = hh * 0.92f, ix = x - 0.1f * s;
                box(ps, vc, lt, ix - iw / 2, ey - ih / 2, -4.18f, ix + iw / 2, ey + ih / 2, -4.1f, SkinPainter.shade(eye, 0.65f), 1f, violet ? 1.4f : 1f);
                box(ps, vc, lt, ix - iw / 2 + 0.1f, ey - ih * 0.05f, -4.2f, ix + iw / 2 - 0.1f, ey + ih / 2 - 0.05f, -4.18f, SkinPainter.shade(eye, 1.2f), 1f, violet ? 1.5f : 1f);
                box(ps, vc, light, ix - iw * 0.22f, ey - ih * 0.2f, -4.23f, ix + iw * 0.22f, ey + ih * 0.22f, -4.2f, 0x0C0C12, 1f, 1f);
                box(ps, vc, 15728880, ix + iw * 0.05f, ey - ih * 0.42f, -4.26f, ix + iw * 0.38f, ey - ih * 0.1f, -4.23f, 0xFFFFFF, 1f, 1f);
                box(ps, vc, 15728880, ix - iw * 0.35f, ey + ih * 0.22f, -4.25f, ix - iw * 0.18f, ey + ih * 0.38f, -4.23f, 0xE8F4FF, 1f, 1f);
            } else {
                box(ps, vc, light, x - W / 2, ey - 0.15f, -4.16f, x + W / 2, ey + 0.2f, -4.1f, lid, 1f, 1f);
            }
            // upper lid line / lashes
            float lt2 = female ? 0.6f : 0.4f;
            box(ps, vc, light, x - W / 2 - 0.15f, ey - hh / 2 - lt2, -4.18f, x + W / 2 + 0.15f, ey - hh / 2 + 0.05f, -4.08f, lash, 1f, 1f);
            if (female || p.eyeShape.equals("sharp")) box(ps, vc, light, x + (W / 2) * s, ey - hh / 2 - 0.9f, -4.18f, x + (W / 2 + 0.7f) * s, ey - hh / 2 - 0.1f, -4.08f, lash, 1f, 1f); // outer flick
            // eyebrow: tilts with eye shape, drops and frowns when hurt
            float tilt = (p.eyeShape.equals("sharp") ? 0.26f : (p.eyeShape.equals("soft") ? -0.14f : 0f)) * s;
            float drop = 0f;
            if (e.hurtTime > 0) { tilt = 0.42f * s; drop = 0.5f; }
            ps.pushPose();
            ps.translate(x, ey - H / 2 - 1.5f + drop, -4.15f);
            ps.mulPose(Axis.ZP.rotation(tilt));
            float bw = p.brows.equals("thick") ? 1.5f : (p.brows.equals("thin") ? 0.55f : 0.95f);
            box(ps, vc, light, -1.6f, -bw / 2, -0.1f, 1.6f, bw / 2, 0.1f, p.hair.equals("bald") ? SkinPainter.shade(skin, 0.55f) : SkinPainter.shade(hair, 0.85f), 1f, 1f);
            ps.popPose();
            // soft blush under each eye
            box(ps, vc, light, x - 1.2f, ey + H / 2 + 0.6f, -4.06f, x + 1.2f, ey + H / 2 + 1.5f, -4.0f, SkinPainter.shade(skin, 0.97f) | 0x0A0000, 1f, 1.0f);
        }
        box(ps, vc, light, -0.6f, -2.2f, -4.5f, 0.6f, -0.9f, -4.0f, SkinPainter.shade(skin, 0.9f), 1f, 1f);                       // nose
        box(ps, vc, light, -0.3f, -1.5f, -4.52f, 0.3f, -0.9f, -4.48f, SkinPainter.shade(skin, 1.1f), 1f, 1f);                     // nose tip light
        if (violet) box(ps, vc, light, -3.8f, -2.2f, -4.4f, 3.8f, 0.0f, -4.0f, 0x2B2B33, 1f, 1f);                                   // the Stranger's breathing mask
        else {
            box(ps, vc, light, -1.2f, -0.95f, -4.12f, 1.2f, -0.6f, -4.0f, 0x9A5555, 1f, 1f);                                      // mouth
            box(ps, vc, light, -1.35f, -1.2f, -4.1f, -1.0f, -0.9f, -4.0f, 0x9A5555, 1f, 1f);                                       // smile corners
            box(ps, vc, light, 1.0f, -1.2f, -4.1f, 1.35f, -0.9f, -4.0f, 0x9A5555, 1f, 1f);
        }
        if (violet) { // eerie glow around the eyes
            VertexConsumer g = buf.getBuffer(RenderType.entityTranslucent(WHITE));
            for (int s = -1; s <= 1; s += 2) box(ps, g, 15728880, ex * s - 1.8f, ey - 1.4f, -4.3f, ex * s + 1.8f, ey + 1.4f, -4.25f, 0xA060FF, 0.35f, 1f);
        }
    }

    // ------------------------------------------------------------------ clothes
    private static void drawClothes(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, float pt, boolean pack) {
        int coat = SkinPainter.cloth(p.coatColor), trim = SkinPainter.trim(p.trim);
        boolean fur = p.coat.equals("shimoro_coat");
        if (p.coat.equals("shimoro_coat") || p.coat.equals("long_coat")) {
            int end = fur ? trim : SkinPainter.shade(coat, 0.7f);
            hang(ps, vc, light, sim.chain("cfl", 3), 2.1f, 11.2f, -2.4f, 3.4f, 3.9f, 0.7f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfr", 3), -2.1f, 11.2f, -2.4f, 3.4f, 3.9f, 0.7f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cbl", 3), 0f, 11.2f, 2.4f, 3.7f, 8.4f, 0.7f, SkinPainter.shade(coat, 0.9f), end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("csl", 3), 4.35f, 11.0f, 0f, 3.0f, 0.7f, 3.8f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("csr", 3), -4.35f, 11.0f, 0f, 3.0f, 0.7f, 3.8f, coat, end, 0f, 0f, pt);
        } else if (p.coat.equals("cloak")) {
            box(ps, vc, light, -4.8f, -0.6f, -2.6f, 4.8f, 1.2f, 2.9f, coat, 1f, 1f);
            hang(ps, vc, light, sim.chain("cbl", 4), 0f, 1.0f, 2.9f, 3.4f, 9.6f, 0.7f, coat, SkinPainter.shade(coat, 0.7f), 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfl", 3), 4.9f, 1.0f, 0f, 3.6f, 0.7f, 5.2f, coat, coat, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfr", 3), -4.9f, 1.0f, 0f, 3.6f, 0.7f, 5.2f, coat, coat, 0f, 0f, pt);
        }
        if (fur) { // high fur collar
            box(ps, vc, light, -4.7f, -1.4f, -2.8f, 4.7f, 1.2f, 2.8f, trim, 1f, 1f);
            box(ps, vc, light, -4.7f, -2.6f, 1.5f, 4.7f, 0.2f, 2.9f, trim, 1f, 1f);
        }
        if (!p.scarf.equals("none")) {
            int sc = p.scarf.equals("white") ? 0xEDEDF2 : (p.scarf.equals("red") ? 0xB03030 : 0x3A63B8);
            box(ps, vc, light, -4.5f, -0.9f, -2.5f, 4.5f, 0.9f, 2.5f, sc, 1f, 1f);
            hang(ps, vc, light, sim.chain("cscarf", 4), 3.0f, 0.6f, 2.6f, 2.8f, 1.9f, 0.7f, sc, SkinPainter.shade(sc, 0.8f), 0.1f, 0f, pt);
        }
        if (p.waistBag) {
            box(ps, vc, light, -6.0f, 9.6f, -1.8f, -4.0f, 12.6f, 1.8f, 0x5A4126, 1f, 1f);
            box(ps, vc, light, -6.1f, 9.4f, -0.4f, -3.9f, 10.2f, 0.4f, 0xC9A24A, 1f, 1f);
        }
        if (pack) {
            box(ps, vc, light, -3.2f, 0.8f, 2.4f, 3.2f, 9.5f, 5.0f, 0x5A4126, 1f, 1f);
            hang(ps, vc, 15728880, sim.chain("clant", 1), 0f, 0.6f, 5.1f, 2.0f, 1.8f, 1.8f, 0xFFD36B, 0xFFD36B, 0.2f, 0f, pt);
        }
    }


    // ------------------------------------------------------------------ accessories
    private static void drawHat(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, float pt) {
        int a = SkinPainter.cloth(p.accent), t = SkinPainter.trim(p.trim);
        switch (p.hat) {
            case "beanie" -> {
                box(ps, vc, light, -4.85f, -9.6f, -4.85f, 4.85f, -7.2f, 4.85f, a, 1f, 1f);
                box(ps, vc, light, -3.9f, -10.4f, -3.9f, 3.9f, -9.5f, 3.9f, a, 1f, 1f);
                box(ps, vc, light, -5.05f, -8.3f, -5.05f, 5.05f, -7.0f, 5.05f, t, 1f, 1f);
                hang(ps, vc, light, sim.chain("hp", 2), 0f, -10.4f, 0f, 0.9f, 2.0f, 2.0f, t, t, 0.1f, 0f, pt);
            }
            case "fur_hat" -> {
                box(ps, vc, light, -5.5f, -10.8f, -5.5f, 5.5f, -7.0f, 5.5f, t, 1f, 1f);
                box(ps, vc, light, -4.5f, -11.6f, -4.5f, 4.5f, -10.8f, 4.5f, SkinPainter.shade(t, 0.95f), 1f, 1f);
                for (int s = -1; s <= 1; s += 2) hang(ps, vc, light, sim.chain("hf" + s, 2), 5.3f * s, -8.2f, 0f, 1.5f, 1.4f, 3.6f, t, SkinPainter.shade(t, 0.9f), 0f, -0.08f * s, pt);
            }
            case "headband" -> {
                box(ps, vc, light, -4.85f, -8.2f, -4.85f, 4.85f, -6.95f, 4.85f, a, 1f, 1f);
                for (int s = -1; s <= 1; s += 2) hang(ps, vc, light, sim.chain("hb" + s, 4), 1.6f * s, -7.7f, 5.0f, 1.8f, 1.2f, 0.5f, a, SkinPainter.shade(a, 0.8f), 0.15f, 0f, pt);
            }
            case "hood" -> {
                box(ps, vc, light, -5.3f, -9.9f, -5.3f, 5.3f, -8.0f, 5.3f, a, 1f, 1f);
                box(ps, vc, light, -5.3f, -9.9f, 3.9f, 5.3f, 0.8f, 5.5f, a, 1f, 1f);
                box(ps, vc, light, -5.7f, -9.2f, -5.1f, -4.7f, -0.4f, 4.2f, a, 1f, 1f);
                box(ps, vc, light, 4.7f, -9.2f, -5.1f, 5.7f, -0.4f, 4.2f, a, 1f, 1f);
                box(ps, vc, light, -5.3f, -8.5f, -5.5f, 5.3f, -8.0f, -5.1f, t, 1f, 1f);
            }
            case "earmuffs" -> {
                box(ps, vc, light, -5.6f, -9.4f, -0.6f, 5.6f, -8.6f, 0.6f, a, 1f, 1f);
                for (int s = -1; s <= 1; s += 2) {
                    box(ps, vc, light, s > 0 ? 4.5f : -6.4f, -6.3f, -1.9f, s > 0 ? 6.4f : -4.5f, -2.9f, 1.9f, t, 1f, 1f);
                    box(ps, vc, light, s > 0 ? 5.6f : -5.9f, -9.2f, -0.5f, s > 0 ? 5.9f : -5.6f, -6.3f, 0.5f, a, 1f, 1f);
                }
            }
            case "cap" -> {
                box(ps, vc, light, -4.85f, -9.7f, -4.85f, 4.85f, -7.6f, 4.85f, a, 1f, 1f);
                box(ps, vc, light, -4.5f, -8.1f, -7.4f, 4.5f, -7.5f, -4.6f, SkinPainter.shade(a, 0.85f), 1f, 1f);
            }
            default -> { }
        }
    }

    private static void drawMask(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p) {
        if (p.eyeColor.equals("violet")) return; // the Stranger already wears his
        int a = SkinPainter.cloth(p.accent);
        if (p.mask.equals("half_mask")) {
            box(ps, vc, light, -4.3f, -2.6f, -4.5f, 4.3f, 0.1f, -4.0f, a, 1f, 1f);
            box(ps, vc, light, -4.6f, -3.8f, -1.0f, -4.2f, -1.6f, 3.5f, a, 1f, 1f);
            box(ps, vc, light, 4.2f, -3.8f, -1.0f, 4.6f, -1.6f, 3.5f, a, 1f, 1f);
        } else if (p.mask.equals("breathing_mask")) {
            box(ps, vc, light, -4.3f, -2.5f, -4.7f, 4.3f, 0.1f, -4.0f, 0x2B2B33, 1f, 1f);
            for (int i = -2; i <= 2; i++) box(ps, vc, light, i * 1.3f - 0.3f, -1.8f, -4.85f, i * 1.3f + 0.3f, -0.5f, -4.7f, 0x55555F, 1f, 1f);
            box(ps, vc, light, -4.6f, -3.6f, -1.0f, -4.2f, -1.4f, 3.6f, 0x1D1D24, 1f, 1f);
            box(ps, vc, light, 4.2f, -3.6f, -1.0f, 4.6f, -1.4f, 3.6f, 0x1D1D24, 1f, 1f);
        }
    }

    private static void drawBodyExtras(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, float pt) {
        int a = SkinPainter.cloth(p.accent), t = SkinPainter.trim(p.trim);
        switch (p.mantle) {
            case "fur_mantle" -> {
                box(ps, vc, light, -6.5f, -1.7f, -3.3f, 6.5f, 1.9f, 3.3f, t, 1f, 1f);
                box(ps, vc, light, -5.1f, 1.7f, -3.5f, 5.1f, 2.7f, 3.5f, SkinPainter.shade(t, 0.93f), 1f, 1f);
                for (int i = 0; i < 5; i++) {
                    float x = -4.8f + i * 2.4f;
                    hang(ps, vc, light, sim.chain("mm" + i, 2), x, 2.3f, -3.4f, 1.1f, 2.1f, 1.0f, t, SkinPainter.shade(t, 0.9f), 0f, 0f, pt);
                    hang(ps, vc, light, sim.chain("mb" + i, 2), x, 2.3f, 3.4f, 1.1f, 2.1f, 1.0f, t, SkinPainter.shade(t, 0.9f), 0f, 0f, pt);
                }
            }
            case "pauldrons" -> {
                int metal = 0x7C8794;
                for (int s = -1; s <= 1; s += 2) {
                    box(ps, vc, light, s > 0 ? 2.4f : -6.8f, -2.0f, -3.1f, s > 0 ? 6.8f : -2.4f, 1.1f, 3.1f, metal, 1f, 1f);
                    box(ps, vc, light, s > 0 ? 2.4f : -6.8f, 1.0f, -3.2f, s > 0 ? 6.8f : -2.4f, 1.5f, 3.2f, t, 1f, 1f);
                }
            }
            case "shawl" -> {
                box(ps, vc, light, -5.3f, -1.3f, -3.3f, 5.3f, 1.5f, 3.3f, a, 1f, 1f);
                hang(ps, vc, light, sim.chain("sh", 3), 0f, 1.4f, -3.4f, 2.4f, 4.4f, 0.8f, a, SkinPainter.shade(a, 0.8f), 0f, 0f, pt);
                hang(ps, vc, light, sim.chain("shb", 3), 0f, 1.4f, 3.4f, 2.4f, 5.4f, 0.8f, a, SkinPainter.shade(a, 0.8f), 0f, 0f, pt);
            }
            default -> { }
        }
        if (p.cape.equals("short_cape") || p.cape.equals("long_cape")) {
            boolean lng = p.cape.equals("long_cape");
            box(ps, vc, light, -4.9f, -0.8f, 2.2f, 4.9f, 0.9f, 3.0f, a, 1f, 1f);
            hang(ps, vc, light, sim.chain("capeb", lng ? 5 : 4), 0f, 0.7f, 3.0f, lng ? 2.8f : 2.1f, lng ? 9.6f : 9.0f, 0.8f, a, SkinPainter.shade(a, 0.7f), 0f, 0f, pt);
            box(ps, vc, light, -1.0f, -1.2f, -2.8f, 1.0f, 0.5f, -2.3f, 0xD8B04A, 1f, 1f); // clasp
        }
        if (p.belt.equals("pouches")) {
            box(ps, vc, light, -4.5f, 10.0f, -2.5f, 4.5f, 11.1f, 2.5f, 0x3A2A1C, 1f, 1f);
            box(ps, vc, light, -0.8f, 9.9f, -2.7f, 0.8f, 11.2f, -2.5f, 0xC9A24A, 1f, 1f);
            for (int i = 0; i < 2; i++) hang(ps, vc, light, sim.chain("bp" + i, 1), i == 0 ? -3.2f : 2.9f, 11.0f, -2.8f, 1.9f, 1.8f, 1.2f, 0x5A4126, 0x5A4126, 0f, 0f, pt);
        } else if (p.belt.equals("sash")) {
            box(ps, vc, light, -4.65f, 9.8f, -2.65f, 4.65f, 11.4f, 2.65f, a, 1f, 1f);
            hang(ps, vc, light, sim.chain("csash", 3), 3.4f, 10.8f, -2.8f, 2.4f, 1.8f, 0.7f, a, SkinPainter.shade(a, 0.8f), 0f, 0f, pt);
        }
    }

    private static void drawArm(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, boolean left) {
        float cx = left ? 1f : -1f, x0 = cx - 2.25f, x1 = cx + 2.25f;
        int a = SkinPainter.cloth(p.accent), t = SkinPainter.trim(p.trim);
        switch (p.gloves) {
            case "fingerless" -> { box(ps, vc, light, x0, 8.0f, -2.25f, x1, 10.3f, 2.25f, a, 1f, 1f); box(ps, vc, light, x0, 7.6f, -2.3f, x1, 8.1f, 2.3f, SkinPainter.shade(a, 0.7f), 1f, 1f); }
            case "fur_gloves" -> { box(ps, vc, light, x0 - 0.15f, 6.4f, -2.4f, x1 + 0.15f, 8.6f, 2.4f, t, 1f, 1f); box(ps, vc, light, x0, 8.6f, -2.25f, x1, 10.4f, 2.25f, a, 1f, 1f); }
            case "wrist_straps" -> { box(ps, vc, light, x0 - 0.05f, 7.0f, -2.3f, x1 + 0.05f, 7.7f, 2.3f, 0x1B1410, 1f, 1f); box(ps, vc, light, x0 - 0.05f, 8.6f, -2.3f, x1 + 0.05f, 9.2f, 2.3f, 0x1B1410, 1f, 1f); }
            default -> { }
        }
        if (p.coat.equals("shimoro_coat")) box(ps, vc, light, x0 - 0.2f, 5.4f, -2.45f, x1 + 0.2f, 7.2f, 2.45f, t, 1f, 1f); // fur cuffs
    }

    private static void drawLeg(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p) {
        int t = SkinPainter.trim(p.trim);
        switch (p.boots) {
            case "fur" -> {
                box(ps, vc, light, -2.4f, 8.8f, -2.5f, 2.4f, 10.6f, 2.5f, t, 1f, 1f);
                box(ps, vc, light, -2.3f, 10.6f, -2.3f, 2.3f, 12f, 2.3f, 0x6B5A4A, 1f, 1f);
                box(ps, vc, light, -2.35f, 11.7f, -3.0f, 2.35f, 12.2f, 2.5f, 0x3A2A1C, 1f, 1f);
            }
            case "waterproof" -> {
                box(ps, vc, light, -2.3f, 9.0f, -2.35f, 2.3f, 12f, 2.35f, 0x23262E, 1f, 1f);
                box(ps, vc, light, -2.4f, 11.6f, -3.1f, 2.4f, 12.2f, 2.6f, 0x14161B, 1f, 1f);
                box(ps, vc, light, -2.1f, 10.6f, -3.0f, 2.1f, 11.7f, -2.2f, 0x2D3038, 1f, 1f);
                box(ps, vc, light, -2.4f, 8.8f, -2.45f, 2.4f, 9.3f, 2.45f, 0x3B3F4A, 1f, 1f);
            }
            default -> {
                box(ps, vc, light, -2.3f, 9.8f, -2.3f, 2.3f, 12f, 2.3f, 0x3A3026, 1f, 1f);
                box(ps, vc, light, -2.4f, 11.7f, -2.9f, 2.4f, 12.2f, 2.5f, 0x20180F, 1f, 1f);
            }
        }
    }

    /** Called by the creator preview so the character wiggles when you turn it. */
    public static void nudge(int entityId, float x, float z) {
        Sim s = SIMS.get(entityId);
        if (s == null) return;
        for (Chain c : s.chains.values()) { c.vx[0] += x; c.vz[0] += z; }
    }
}
