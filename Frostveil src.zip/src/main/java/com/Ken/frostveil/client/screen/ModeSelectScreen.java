package com.Ken.frostveil.client.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** First screen on a new character: Story (play as Shimoro) or Free World (create your own). */
public class ModeSelectScreen extends Screen {
    public ModeSelectScreen() { super(Component.literal("Frostveil")); }

    @Override
    protected void init() {
        int cx = width / 2;
        addRenderableWidget(Button.builder(Component.literal("Story Mode  -  play as Shimoro"), b -> minecraft.setScreen(new CreatorScreen(true))).bounds(cx - 120, height / 2 - 10, 240, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Free World  -  create your own character"), b -> minecraft.setScreen(new CreatorScreen(false))).bounds(cx - 120, height / 2 + 20, 240, 24).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fillGradient(0, 0, width, height, 0xFF0A1220, 0xFF1D3350);
        g.drawCenteredString(font, "F R O S T V E I L", width / 2, height / 2 - 70, 0xFFDDF1FF);
        g.drawCenteredString(font, "\"I don't know if what I'm doing is right. But I know I can't stop.\"", width / 2, height / 2 - 48, 0xFF8FB4D6);
        super.render(g, mx, my, pt);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
