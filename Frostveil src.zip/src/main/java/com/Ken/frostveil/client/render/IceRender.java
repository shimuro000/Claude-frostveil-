package com.Ken.frostveil.client.render;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.ice.IceMesh;
import com.Ken.frostveil.ice.ShapeSpec;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws a ShapeSpec's procedural mesh (IceMesh) with the ice texture. Used by projectiles, held weapons, halo shards and previews. */
public final class IceRender {
    public static final ResourceLocation TEX = Fv.id("textures/entity/ice.png");
    private static final Map<String, List<float[]>> CACHE = new HashMap<>();

    private IceRender() {}

    public static List<float[]> mesh(ShapeSpec s) {
        String key = s.prim + "|" + Math.round(s.length * 10) + "|" + Math.round(s.width * 10) + "|" + Math.round(s.curve * 20);
        return CACHE.computeIfAbsent(key, k -> IceMesh.build(s));
    }

    public static void draw(ShapeSpec s, PoseStack ps, MultiBufferSource buf, int light, float scale, float r, float g, float b, float a) {
        VertexConsumer vc = buf.getBuffer(RenderType.entityTranslucent(TEX));
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float[][] uv = {{0f, 0f}, {1f, 0f}, {1f, 1f}, {0f, 1f}};
        for (float[] q : mesh(s)) {
            float ax = q[3] - q[0], ay = q[4] - q[1], az = q[5] - q[2];
            float bx = q[9] - q[0], by = q[10] - q[1], bz = q[11] - q[2];
            float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
            float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1.0E-6f) { nx = 0; ny = 1; nz = 0; len = 1f; }
            nx /= len; ny /= len; nz /= len;
            for (int i = 0; i < 4; i++) {
                vc.vertex(m, q[i * 3] * scale, q[i * 3 + 1] * scale, q[i * 3 + 2] * scale).color(r, g, b, a).uv(uv[i][0], uv[i][1])
                        .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
            }
        }
    }
}
