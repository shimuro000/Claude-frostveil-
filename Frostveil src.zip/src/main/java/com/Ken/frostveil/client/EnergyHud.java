package com.Ken.frostveil.client;

import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.capability.PlayerEnergyData;
import com.Ken.frostveil.energy.ChannelState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * HUD (G4): Aura bar (element colour), Focus meter, active-state icons, Flow edge glow, low-aura warning.
 * PLACEHOLDER visuals: bars and text instead of final art; the Focus "ring" is a bar for now.
 * TODO(phase-4): technique icon and cooldown, objective tracker, colour-blind palette.
 */
@Mod.EventBusSubscriber(modid = Frostveil.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class EnergyHud {
    private EnergyHud() {}

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent e) { e.registerAboveAll("energy", EnergyHud::render); }

    private static int elementColor(PlayerEnergyData d) {
        return switch (d.element) {
            case ICE -> 0xFF4FC3F7; case FIRE -> 0xFFFF5722; case WIND -> 0xFFA5D6A7; case LIGHTNING -> 0xFFFFEB3B;
            case EARTH -> 0xFF8D6E63; case WATER -> 0xFF2196F3; default -> 0xFFBDBDBD;
        };
    }

    private static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) return;
        PlayerEnergyData d = ClientEnergyCache.get();
        if (!d.awakened) return; // nothing to show before the first feeling

        // Aura shows 0 in forced closure although the true energy is trapped (D2).
        double frac = d.channel == ChannelState.FORCED_CLOSURE ? 0 : Math.max(0, Math.min(1, d.aura / Math.max(1, d.quantity)));
        int x = 8, y = h - 16;
        g.fill(x - 1, y - 1, x + 101, y + 6, 0xAA000000);
        g.fill(x, y, x + (int) (100 * frac), y + 5, elementColor(d));
        g.fill(x - 1, h - 9, x + 101, h - 5, 0xAA000000);
        g.fill(x, h - 8, x + (int) (100 * Math.max(0, Math.min(1, d.focus / 100.0))), h - 6, 0xFFFFFFFF);

        int ty = h - 28;
        if (d.skinSense) { g.drawString(mc.font, Component.translatable("frostveil.hud.skin_sense"), x, ty, 0xFFFFFF); ty -= 10; }
        if (d.forgeActive) { g.drawString(mc.font, Component.translatable("frostveil.hud.forge", Component.translatable("frostveil.limb." + d.forgeLimb)), x, ty, 0xFFFFFF); ty -= 10; }
        if (d.shroud) { g.drawString(mc.font, Component.translatable("frostveil.hud.shroud"), x, ty, 0xFFFFFF); ty -= 10; }
        if (d.infuseHeld) { g.drawString(mc.font, Component.translatable("frostveil.hud.infuse"), x, ty, 0xFFFFFF); ty -= 10; }
        if (d.channel != ChannelState.NORMAL) { g.drawString(mc.font, Component.translatable("frostveil.hud.closed"), x, ty, 0xFF8888); }

        if (d.flowTicks > 0) border(g, w, h, 4, 0x55FFFFFF);               // Flow glow
        else if (frac < 0.15) border(g, w, h, 3, 0x33FF0000);               // low-aura warning (Law 2)
    }

    private static void border(GuiGraphics g, int w, int h, int t, int c) {
        g.fill(0, 0, w, t, c); g.fill(0, h - t, w, h, c); g.fill(0, 0, t, h, c); g.fill(w - t, 0, w, h, c);
    }
}
