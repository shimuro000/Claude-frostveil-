package com.Ken.frostveil.client;

import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

/**
 * Swaps a player's skin for the painted character skin. We find the private texture map and the skin-model string inside
 * PlayerInfo by type (no mapping names needed), and re-apply every few ticks because the real skin loads asynchronously.
 */
public final class ClientSkins {
    private static Field TEXTURES, MODEL;
    private static boolean searched = false;

    private ClientSkins() {}

    @SuppressWarnings("unchecked")
    public static void apply(Minecraft mc) {
        if (mc.level == null || mc.getConnection() == null) return;
        if (!searched) {
            searched = true;
            for (Field f : PlayerInfo.class.getDeclaredFields()) {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers())) continue;
                if (Map.class.isAssignableFrom(f.getType()) && f.getGenericType() instanceof ParameterizedType pt) {
                    Type[] a = pt.getActualTypeArguments();
                    if (a.length == 2 && a[1] == ResourceLocation.class) { f.setAccessible(true); TEXTURES = f; }
                } else if (f.getType() == String.class) { f.setAccessible(true); MODEL = f; }
            }
        }
        if (TEXTURES == null) return;
        for (Player pl : mc.level.players()) {
            UUID id = pl.getUUID();
            boolean local = mc.player != null && id.equals(mc.player.getUUID());
            CharacterProfile prof = local && ClientState.preview != null ? ClientState.preview : ClientState.PROFILES.get(id);
            int mode = local ? (ClientState.preview != null ? 1 : FvCap.CLIENT.mode) : ClientState.MODES.getOrDefault(id, 0);
            if (prof == null || mode == 0) continue;
            PlayerInfo info = mc.getConnection().getPlayerInfo(id);
            if (info == null) continue;
            try {
                ResourceLocation tex = SkinPainter.textureFor("player_" + id, prof);
                ((Map<MinecraftProfileTexture.Type, ResourceLocation>) TEXTURES.get(info)).put(MinecraftProfileTexture.Type.SKIN, tex);
                if (MODEL != null) MODEL.set(info, "default");
            } catch (ReflectiveOperationException | RuntimeException ignored) { }
        }
    }
}
