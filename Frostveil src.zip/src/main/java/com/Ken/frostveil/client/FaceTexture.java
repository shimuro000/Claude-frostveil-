package com.Ken.frostveil.client;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.CharacterProfile;
import com.mojang.blaze3d.platform.NativeImage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * The face, painted as a smooth 64x64 picture that is drawn as one plane in front of the head (8 texels per model pixel),
 * so big anime-style eyes (iris, pupil, two sparkles, lashes), brows, blush, nose and mouth are always visible and blink / frown.
 * Variants: 0 open, 1 blink, 2 hurt, 3 glow (only the glowing eyes, for the Stranger).
 */
public final class FaceTexture {
    private static final Map<String, ResourceLocation> CACHE = new HashMap<>();

    private FaceTexture() {}

    public static ResourceLocation get(CharacterProfile p, int variant) {
        String key = p.toTag().toString() + "#" + variant;
        ResourceLocation rl = CACHE.get(key);
        if (rl != null) return rl;
        int[] px = paint(p, variant);
        NativeImage img = new NativeImage(64, 64, true);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            int c = px[y * 64 + x];
            img.setPixelRGBA(x, y, (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF));
        }
        rl = Fv.id("dyn/face_" + Integer.toHexString(key.hashCode()) + "_" + variant);
        Minecraft.getInstance().getTextureManager().register(rl, new DynamicTexture(img));
        if (CACHE.size() > 300) CACHE.clear();
        CACHE.put(key, rl);
        return rl;
    }

    // ---- tiny anti-aliased painter ----
    private static void put(int[] px, int x, int y, int rgb, float a) {
        if (x < 0 || y < 0 || x >= 64 || y >= 64 || a <= 0f) return;
        int o = px[y * 64 + x];
        float oa = ((o >>> 24) & 255) / 255f;
        float na = a + oa * (1f - a);
        if (na <= 0f) return;
        float k = a / na;
        int r = Math.round(((o >> 16) & 255) * (1 - k) + ((rgb >> 16) & 255) * k), g = Math.round(((o >> 8) & 255) * (1 - k) + ((rgb >> 8) & 255) * k), b = Math.round((o & 255) * (1 - k) + (rgb & 255) * k);
        px[y * 64 + x] = (Math.round(na * 255) << 24) | (r << 16) | (g << 8) | b;
    }

    private static void ellipse(int[] px, float cx, float cy, float rx, float ry, int rgb, float alpha) {
        for (int y = (int) (cy - ry - 2); y <= cy + ry + 2; y++) for (int x = (int) (cx - rx - 2); x <= cx + rx + 2; x++) {
            float dx = (x + 0.5f - cx) / rx, dy = (y + 0.5f - cy) / ry;
            float d = (float) Math.sqrt(dx * dx + dy * dy);
            float cov = Math.max(0f, Math.min(1f, (1f - d) * Math.min(rx, ry) + 0.5f));
            put(px, x, y, rgb, cov * alpha);
        }
    }

    private static void line(int[] px, float x0, float y0, float x1, float y1, float w, int rgb, float alpha) {
        int n = (int) Math.max(4, Math.hypot(x1 - x0, y1 - y0) * 2);
        for (int i = 0; i <= n; i++) { float t = i / (float) n; ellipse(px, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, w / 2f, w / 2f, rgb, alpha); }
    }

    private static int[] paint(CharacterProfile p, int variant) {
        int[] px = new int[64 * 64];
        int skin = SkinPainter.skin(p.skin), hair = SkinPainter.hair(p.hairColor), eye = SkinPainter.eye(p.eyeColor);
        boolean violet = p.eyeColor.equals("violet"), female = p.bodyType.equals("female");
        boolean blink = variant == 1, hurt = variant == 2, glow = variant == 3;
        float W = p.eyeShape.equals("sharp") ? 11.5f : (p.eyeShape.equals("soft") ? 10.5f : 11f);
        float H = p.eyeShape.equals("sharp") ? 7.8f : (p.eyeShape.equals("soft") ? 9.4f : 10.6f);
        if (hurt) H *= 0.72f;
        float ey = 37.5f;
        for (int s = -1; s <= 1; s += 2) {
            float cx = 32 + 18f * s;
            if (glow) { // only the glowing iris, for the emissive pass
                if (violet) { ellipse(px, cx, ey, 7.5f, H * 0.95f, 0xD9A8FF, 1f); ellipse(px, cx, ey, 3.5f, H * 0.5f, 0xFFFFFF, 0.9f); }
                continue;
            }
            // blush
            ellipse(px, cx, ey + H + 8f, 11f, 4.6f, 0xE88A8A, 0.22f);
            if (blink) {
                line(px, cx - W, ey + 1f, cx, ey + 3.2f, 3.2f, 0x16161C, 1f);
                line(px, cx, ey + 3.2f, cx + W, ey + 1f, 3.2f, 0x16161C, 1f);
            } else {
                ellipse(px, cx, ey, W + 1.2f, H + 1.2f, SkinPainter.shade(skin, 0.7f), 0.55f);          // soft socket shadow
                ellipse(px, cx, ey, W, H, 0xF6F6FA, 1f);                                                    // eyeball
                ellipse(px, cx, ey - H * 0.55f, W * 0.95f, H * 0.5f, 0xB9BCCB, 0.35f);                        // shadow under the lid
                float ix = cx - 0.8f * s, ir = 7.4f;
                ellipse(px, ix, ey, ir + 1f, H * 0.97f, SkinPainter.shade(eye, 0.45f), 1f);                // iris rim
                ellipse(px, ix, ey, ir, H * 0.92f, SkinPainter.shade(eye, 0.75f), 1f);                     // iris top
                ellipse(px, ix, ey + H * 0.28f, ir * 0.85f, H * 0.62f, SkinPainter.shade(eye, 1.3f), 0.95f); // brighter lower iris
                ellipse(px, ix, ey, 3.4f, H * 0.5f, 0x0C0C12, 1f);                                         // pupil
                ellipse(px, ix + 2.6f, ey - H * 0.42f, 2.7f, 2.7f, 0xFFFFFF, 1f);                          // big sparkle
                ellipse(px, ix - 2.6f, ey + H * 0.4f, 1.5f, 1.5f, 0xEAF4FF, 0.95f);                        // small sparkle
                if (violet) ellipse(px, ix, ey, ir, H * 0.92f, 0x9A4DFF, 0.35f);
                // upper lid / lashes
                float lw = female ? 3.6f : 2.6f;
                for (int i = -10; i <= 10; i++) {
                    float t = i / 10f;
                    ellipse(px, cx + t * (W + 0.8f), ey - H * (0.93f - 0.16f * t * t) - 0.5f, lw / 2f, lw / 2f, 0x16161C, 1f);
                }
                if (female || p.eyeShape.equals("sharp")) line(px, cx + s * (W + 0.5f), ey - H * 0.8f, cx + s * (W + 6f), ey - H * 1.15f, 2.4f, 0x16161C, 1f); // outer flick
                line(px, cx - W * 0.8f, ey + H + 0.6f, cx + W * 0.8f, ey + H + 0.6f, 1.2f, SkinPainter.shade(skin, 0.6f), 0.5f); // lower lid
            }
            // eyebrow
            float tilt = (p.eyeShape.equals("sharp") ? 0.26f : (p.eyeShape.equals("soft") ? -0.14f : 0f)) * s;
            float by = ey - H - 11f;
            if (hurt) { tilt = 0.45f * s; by += 4f; }
            float bl = 13f, bt = p.brows.equals("thick") ? 4.6f : (p.brows.equals("thin") ? 1.9f : 3.2f);
            int bc = p.hair.equals("bald") ? SkinPainter.shade(skin, 0.55f) : SkinPainter.shade(hair, 0.85f);
            line(px, cx - bl * (float) Math.cos(tilt), by - (float) Math.sin(tilt) * bl, cx + bl * (float) Math.cos(tilt), by + (float) Math.sin(tilt) * bl, bt, bc, 1f);
        }
        if (glow) return px;
        // nose
        ellipse(px, 32, 49.5f, 3.4f, 5f, SkinPainter.shade(skin, 0.88f), 0.45f);
        ellipse(px, 32, 46.5f, 1.4f, 2.4f, 0xFFFFFF, 0.22f);
        // mouth
        int mc = 0x9A5555;
        if (violet) {
            for (int y = 44; y < 64; y++) for (int x = 6; x < 58; x++) { float edge = Math.min(Math.min(x - 6, 57 - x), (y - 44)); put(px, x, y, 0x2B2B33, Math.min(1f, 0.6f + edge * 0.1f)); }
            for (int i = -2; i <= 2; i++) line(px, 32 + i * 9f, 52f, 32 + i * 9f, 60f, 2.6f, 0x55555F, 1f);
        } else if (hurt) {
            line(px, 25, 60, 32, 57.5f, 2.4f, mc, 1f); line(px, 32, 57.5f, 39, 60, 2.4f, mc, 1f);
        } else {
            line(px, 25, 58, 32, 60.2f, 2.4f, mc, 1f); line(px, 32, 60.2f, 39, 58, 2.4f, mc, 1f);
            line(px, 23.5f, 56.5f, 25, 58, 1.8f, mc, 0.8f); line(px, 39, 58, 40.5f, 56.5f, 1.8f, mc, 0.8f);
        }
        return px;
    }
}
