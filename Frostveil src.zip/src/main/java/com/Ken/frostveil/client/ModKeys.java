package com.Ken.frostveil.client;

import com.Ken.frostveil.Frostveil;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** All keys of G3, rebindable under the "Frostveil" category. Keys marked TODO are registered but wired in later phases. */
@Mod.EventBusSubscriber(modid = Frostveil.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ModKeys {
    private static final String CAT = "key.categories.frostveil";
    public static final KeyMapping DODGE = new KeyMapping("key.frostveil.dodge", GLFW.GLFW_KEY_LEFT_ALT, CAT);
    public static final KeyMapping SKIN_SENSE = new KeyMapping("key.frostveil.skin_sense", GLFW.GLFW_KEY_Z, CAT);
    public static final KeyMapping FORGE = new KeyMapping("key.frostveil.forge", GLFW.GLFW_KEY_X, CAT);
    /** Temporary: cycles the Forge limb until the technique wheel exists (G7 says the limb is chosen in the wheel). */
    public static final KeyMapping FORGE_LIMB = new KeyMapping("key.frostveil.forge_limb", GLFW.GLFW_KEY_B, CAT);
    public static final KeyMapping CUTOFF = new KeyMapping("key.frostveil.cutoff", GLFW.GLFW_KEY_C, CAT);
    public static final KeyMapping INFUSE = new KeyMapping("key.frostveil.infuse", GLFW.GLFW_KEY_V, CAT);
    public static final KeyMapping FOCUS = new KeyMapping("key.frostveil.focus", GLFW.GLFW_KEY_G, CAT);
    // TODO(phase-2): wheel and cast belong to section H (techniques).
    public static final KeyMapping WHEEL = new KeyMapping("key.frostveil.wheel", GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping CAST = new KeyMapping("key.frostveil.cast", GLFW.GLFW_KEY_F, CAT);
    // TODO(phase-4): screens (character sheet, journal, map, codex, companions, bracelet).
    public static final KeyMapping SHEET = new KeyMapping("key.frostveil.sheet", GLFW.GLFW_KEY_K, CAT);
    public static final KeyMapping JOURNAL = new KeyMapping("key.frostveil.journal", GLFW.GLFW_KEY_J, CAT);
    public static final KeyMapping MAP = new KeyMapping("key.frostveil.map", GLFW.GLFW_KEY_M, CAT);
    public static final KeyMapping CODEX = new KeyMapping("key.frostveil.codex", GLFW.GLFW_KEY_H, CAT);
    public static final KeyMapping COMPANIONS = new KeyMapping("key.frostveil.companions", GLFW.GLFW_KEY_U, CAT);
    public static final KeyMapping BRACELET = new KeyMapping("key.frostveil.bracelet", GLFW.GLFW_KEY_Y, CAT);

    private static final KeyMapping[] ALL = { DODGE, SKIN_SENSE, FORGE, FORGE_LIMB, CUTOFF, INFUSE, FOCUS, WHEEL, CAST,
            SHEET, JOURNAL, MAP, CODEX, COMPANIONS, BRACELET };

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) { for (KeyMapping k : ALL) e.register(k); }

    private ModKeys() {}
}
