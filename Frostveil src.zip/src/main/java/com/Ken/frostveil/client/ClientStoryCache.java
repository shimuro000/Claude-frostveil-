package com.Ken.frostveil.client;

import com.Ken.frostveil.capability.PlayerStoryData;
import net.minecraft.nbt.CompoundTag;

/** Client-side read-only copy of the local player's story data. Never authoritative. */
public class ClientStoryCache {
    private static final PlayerStoryData DATA = new PlayerStoryData();

    public static void update(CompoundTag tag) { DATA.load(tag); }

    public static PlayerStoryData get() { return DATA; }
}
