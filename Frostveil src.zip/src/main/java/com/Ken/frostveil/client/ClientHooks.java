package com.Ken.frostveil.client;

import com.Ken.frostveil.client.fx.Juice;
import com.Ken.frostveil.client.screen.CreatorScreen;
import com.Ken.frostveil.client.screen.DialogueScreen;
import com.Ken.frostveil.client.screen.JournalScreen;
import com.Ken.frostveil.client.screen.ModeSelectScreen;
import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.network.FvNet;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

/** Entry points called by the network layer on the client. Keep this class free of server-only code. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void init() {
        FvCap.CLIENT_SCALE = ClientState::scaleOf;
    }

    public static void sync(CompoundTag tag) {
        FvCap.CLIENT.load(tag);
        FvCap.CLIENT.dirty = false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            ClientState.PROFILES.put(mc.player.getUUID(), FvCap.CLIENT.profile);
            ClientState.AGES.put(mc.player.getUUID(), FvCap.CLIENT.ageStage);
            ClientState.MODES.put(mc.player.getUUID(), FvCap.CLIENT.mode);
            ClientState.flowUntil = Math.max(ClientState.flowUntil, 0);
        }
    }

    public static void appearance(UUID id, CompoundTag profile, int age, int mode) {
        ClientState.PROFILES.put(id, CharacterProfile.fromTag(profile));
        ClientState.AGES.put(id, age);
        ClientState.MODES.put(id, mode);
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) {
            var p = mc.level.getPlayerByUUID(id);
            if (p != null) p.refreshDimensions();
        }
    }

    public static void publicState(UUID id, PublicState s) {
        ClientState.PUBLIC.put(id, s);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && id.equals(mc.player.getUUID()) && s.flow()) ClientState.flowUntil = mc.level.getGameTime() + 200;
    }

    public static void impact(FvNet.ImpactMsg m) { Juice.onImpact(m); }

    public static void caption(String text, int ticks, boolean black) {
        ClientState.caption = text;
        ClientState.captionTicks = ticks;
        ClientState.captionMax = ticks;
        ClientState.captionBlack = black;
    }

    public static void dialogue(int entityId, CompoundTag node) {
        Minecraft mc = Minecraft.getInstance();
        if (node.isEmpty()) {
            if (mc.screen instanceof DialogueScreen) mc.setScreen(null);
            return;
        }
        if (mc.screen instanceof DialogueScreen ds) ds.show(entityId, node);
        else mc.setScreen(new DialogueScreen(entityId, node));
    }

    public static void journal(CompoundTag tag) {
        ClientState.journal = tag;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof JournalScreen js) js.refresh();
        else mc.setScreen(new JournalScreen());
    }

    public static void openScreen(String name) {
        Minecraft mc = Minecraft.getInstance();
        switch (name) {
            case "mode_select" -> mc.setScreen(new ModeSelectScreen());
            case "creator" -> mc.setScreen(new CreatorScreen(FvCap.CLIENT.mode == 1));
            default -> { }
        }
    }
}
