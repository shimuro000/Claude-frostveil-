package com.Ken.frostveil.client.render;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.ClientSkins;
import com.Ken.frostveil.client.SkinPainter;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.eiu.Element;
import com.Ken.frostveil.entity.EiuBeastEntity;
import com.Ken.frostveil.entity.FargasEntity;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.entity.NpcDefs;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.ice.SnowFieldEntity;
import com.Ken.frostveil.registry.ModEntities;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.CowModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** All entity renderers and render layers (client only). */
@Mod.EventBusSubscriber(modid = Fv.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Renderers {
    private Renderers() {}

    @SubscribeEvent
    public static void register(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.ICE_CONSTRUCT.get(), IceConstructRenderer::new);
        e.registerEntityRenderer(ModEntities.SNOW_FIELD.get(), SnowRenderer::new);
        e.registerEntityRenderer(ModEntities.NPC.get(), NpcRenderer::new);
        e.registerEntityRenderer(ModEntities.FARGAS.get(), FargasRenderer::new);
        e.registerEntityRenderer(ModEntities.BEAST.get(), BeastRenderer::new);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.AddLayers e) {
        for (String skin : new String[]{"default", "slim"}) {
            PlayerRenderer pr = e.getSkin(skin);
            if (pr != null) pr.addLayer(new HaloLayer(pr));
        }
    }

    // ---------- ice constructs ----------
    static final class IceConstructRenderer extends EntityRenderer<IceConstructEntity> {
        IceConstructRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

        @Override
        public void render(IceConstructEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            ShapeSpec s = e.spec();
            float grow = e.grow(partial);
            int c = Element.color(e.element());
            float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
            if ("ice".equals(e.element())) { r = 0.85f; g = 0.95f; b = 1f; }
            ps.pushPose();
            ps.translate(0, e.getBbHeight() * 0.5, 0);
            ps.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partial, e.yRotO, e.getYRot())));
            ps.mulPose(Axis.XP.rotationDegrees(Mth.lerp(partial, e.xRotO, e.getXRot())));
            if (s.spin > 0) ps.mulPose(Axis.ZP.rotationDegrees((e.tickCount + partial) * s.spin * 22f));
            float sc = 0.25f + 0.75f * grow;
            boolean centred = s.prim == ShapeSpec.Prim.SPHERE || s.prim == ShapeSpec.Prim.DISC || s.prim == ShapeSpec.Prim.WALL;
            if (!centred) ps.translate(0, 0, -s.length * 0.4 * sc);
            if (e.state() == IceConstructEntity.FORMING) ps.translate((e.tickCount % 3 - 1) * 0.004, 0, 0); // trembling while it forms
            IceRender.draw(s, ps, buf, 15728880, sc, r, g, b, 0.55f + 0.4f * grow);
            ps.popPose();
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        public ResourceLocation getTextureLocation(IceConstructEntity e) { return IceRender.TEX; }
    }

    static final class SnowRenderer extends EntityRenderer<SnowFieldEntity> {
        SnowRenderer(EntityRendererProvider.Context ctx) { super(ctx); }
        @Override public ResourceLocation getTextureLocation(SnowFieldEntity e) { return IceRender.TEX; }
    }

    // ---------- NPCs ----------
    private static final Map<String, Boolean> HAS_PNG = new HashMap<>();

    static ResourceLocation npcTexture(String id) {
        ResourceLocation png = Fv.id("textures/entity/npc/" + id + ".png");
        boolean has = HAS_PNG.computeIfAbsent(id, k -> Minecraft.getInstance().getResourceManager().getResource(png).isPresent());
        return has ? png : SkinPainter.textureFor("npc_" + id, NpcDefs.get(id).look());
    }

    static final class NpcRenderer extends HumanoidMobRenderer<FvNpcEntity, PlayerModel<FvNpcEntity>> {
        NpcRenderer(EntityRendererProvider.Context ctx) { super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f); }
        @Override public ResourceLocation getTextureLocation(FvNpcEntity e) { return npcTexture(e.npcId()); }
        @Override protected void scale(FvNpcEntity e, PoseStack ps, float partial) { float s = e.def().scale(); ps.scale(s, s, s); }
    }

    static final class FargasRenderer extends HumanoidMobRenderer<FargasEntity, PlayerModel<FargasEntity>> {
        FargasRenderer(EntityRendererProvider.Context ctx) { super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f); }
        @Override public ResourceLocation getTextureLocation(FargasEntity e) { return npcTexture("fargas"); }
    }

    // ---------- beasts: vanilla cow / pig models, tinted ----------
    static final class TintCow extends CowModel<EiuBeastEntity> {
        float r = 1, g = 1, b = 1;
        TintCow(net.minecraft.client.model.geom.ModelPart p) { super(p); }
        @Override
        public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float rr, float gg, float bb, float aa) {
            super.renderToBuffer(ps, vc, light, overlay, rr * r, gg * g, bb * b, aa);
        }
    }

    static final class TintPig extends PigModel<EiuBeastEntity> {
        float r = 1, g = 1, b = 1;
        TintPig(net.minecraft.client.model.geom.ModelPart p) { super(p); }
        @Override
        public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float rr, float gg, float bb, float aa) {
            super.renderToBuffer(ps, vc, light, overlay, rr * r, gg * g, bb * b, aa);
        }
    }

    static final class BeastRenderer extends MobRenderer<EiuBeastEntity, EntityModel<EiuBeastEntity>> {
        private final TintCow cow;
        private final TintPig pig;
        private static final ResourceLocation COW = new ResourceLocation("textures/entity/cow/cow.png");
        private static final ResourceLocation PIG = new ResourceLocation("textures/entity/pig/pig.png");

        BeastRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new TintCow(ctx.bakeLayer(ModelLayers.COW)), 0.7f);
            this.cow = (TintCow) this.model;
            this.pig = new TintPig(ctx.bakeLayer(ModelLayers.PIG));
        }

        @Override
        public void render(EiuBeastEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            int k = e.kind();
            if (k <= 1) { this.model = cow; cow.r = k == 0 ? 0.95f : 0.8f; cow.g = k == 0 ? 0.7f : 0.55f; cow.b = k == 0 ? 0.7f : 0.55f; }
            else { this.model = pig; pig.r = k == 2 ? 0.55f : 1f; pig.g = k == 2 ? 0.45f : 0.5f; pig.b = k == 2 ? 0.45f : 0.2f; }
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        protected void scale(EiuBeastEntity e, PoseStack ps, float partial) {
            switch (e.kind()) {
                case 1 -> ps.scale(1.3f, 1.3f, 1.3f);
                case 2 -> ps.scale(1.25f, 1.25f, 1.25f);
                case 3 -> ps.scale(0.8f, 1.15f, 1.3f);
                default -> { }
            }
        }

        @Override public ResourceLocation getTextureLocation(EiuBeastEntity e) { return e.kind() <= 1 ? COW : PIG; }
    }

    // ---------- Ice Halo orbiting a player ----------
    static final class HaloLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
        private final ShapeSpec spec = new ShapeSpec();

        HaloLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); spec.prim = ShapeSpec.Prim.SHARD; }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limb, float limbAmt, float partial, float age, float headYaw, float headPitch) {
            PublicState st = com.Ken.frostveil.client.ClientState.pub(p.getUUID());
            if (!st.haloOn() || st.haloShards() <= 0) return;
            spec.length = Math.max(0.3f, st.haloLen()); spec.width = Math.max(0.2f, st.haloWid());
            int n = st.haloShards();
            float R = st.haloRadius();
            ps.pushPose();
            ps.translate(0.0, 1.501, 0.0);
            ps.scale(-1f, -1f, 1f); // back to world-oriented axes with the origin at the feet
            double t = (p.tickCount + partial) * (0.04 + st.haloSpin() * 0.08);
            for (int i = 0; i < n; i++) {
                double a = t + i * Math.PI * 2 / n;
                double x, y, z;
                switch (st.haloPattern()) {
                    case 1 -> { x = Math.cos(a) * R; z = Math.sin(a) * R; y = 0.5 + 1.4 * i / Math.max(1, n - 1); }            // spiral
                    case 2 -> { double u = Math.acos(1 - 2.0 * (i + 0.5) / n), v = Math.PI * (1 + Math.sqrt(5)) * i + t; x = Math.sin(u) * Math.cos(v) * R; y = 1.0 + Math.cos(u) * R * 0.8; z = Math.sin(u) * Math.sin(v) * R; } // shell
                    default -> { x = Math.cos(a) * R; z = Math.sin(a) * R; y = 1.1 + Math.sin(a * 2 + t) * 0.12; }                  // ring
                }
                ps.pushPose();
                ps.translate(x, y, z);
                ps.mulPose(Axis.YP.rotation((float) -a));
                IceRender.draw(spec, ps, buf, 15728880, 1f, 0.85f, 0.95f, 1f, 0.9f);
                ps.popPose();
            }
            ps.popPose();
        }
    }

    static boolean unused() { return ClientSkins.class != null; }
}
