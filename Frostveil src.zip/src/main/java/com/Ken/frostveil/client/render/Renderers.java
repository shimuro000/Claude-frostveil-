package com.Ken.frostveil.client.render;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.ClientSkins;
import com.Ken.frostveil.client.SkinPainter;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.eiu.Element;
import com.Ken.frostveil.entity.EiuBeastEntity;
import com.Ken.frostveil.entity.FargasEntity;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.entity.NpcDefs;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.ice.SnowFieldEntity;
import com.Ken.frostveil.registry.ModEntities;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.CowModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** All entity renderers and render layers (client only). */
@Mod.EventBusSubscriber(modid = Fv.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Renderers {
    private Renderers() {}

    @SubscribeEvent
    public static void register(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.ICE_CONSTRUCT.get(), IceConstructRenderer::new);
        e.registerEntityRenderer(ModEntities.SNOW_FIELD.get(), SnowRenderer::new);
        e.registerEntityRenderer(ModEntities.NPC.get(), NpcRenderer::new);
        e.registerEntityRenderer(ModEntities.FARGAS.get(), FargasRenderer::new);
        e.registerEntityRenderer(ModEntities.BEAST.get(), BeastRenderer::new);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.AddLayers e) {
        for (String skin : new String[]{"default", "slim"}) {
            PlayerRenderer pr = e.getSkin(skin);
            if (pr != null) { pr.addLayer(new HaloLayer(pr)); pr.addLayer(new Cosmetics.Layer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>>(pr, Renderers::playerProfile)); }
        }
    }

    // ---------- ice constructs ----------
    static final class IceConstructRenderer extends EntityRenderer<IceConstructEntity> {
        IceConstructRenderer(EntityRendererProvider.Context ctx) { super(ctx); }

        @Override
        public void render(IceConstructEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            ShapeSpec s = e.spec();
            float grow = e.grow(partial);
            int c = Element.color(e.element());
            float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
            if ("ice".equals(e.element())) { r = 0.85f; g = 0.95f; b = 1f; }
            ps.pushPose();
            ps.translate(0, e.getBbHeight() * 0.5, 0);
            ps.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partial, e.yRotO, e.getYRot())));
            ps.mulPose(Axis.XP.rotationDegrees(Mth.lerp(partial, e.xRotO, e.getXRot())));
            if (s.spin > 0) ps.mulPose(Axis.ZP.rotationDegrees((e.tickCount + partial) * s.spin * 22f));
            float sc = 0.25f + 0.75f * grow;
            boolean centred = s.prim == ShapeSpec.Prim.SPHERE || s.prim == ShapeSpec.Prim.DISC || s.prim == ShapeSpec.Prim.WALL;
            if (!centred) ps.translate(0, 0, -s.length * 0.4 * sc);
            if (e.state() == IceConstructEntity.FORMING) ps.translate((e.tickCount % 3 - 1) * 0.004, 0, 0); // trembling while it forms
            IceRender.draw(s, ps, buf, 15728880, sc, r, g, b, 0.55f + 0.4f * grow);
            ps.popPose();
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        public ResourceLocation getTextureLocation(IceConstructEntity e) { return IceRender.TEX; }
    }

    static final class SnowRenderer extends EntityRenderer<SnowFieldEntity> {
        SnowRenderer(EntityRendererProvider.Context ctx) { super(ctx); }
        @Override public ResourceLocation getTextureLocation(SnowFieldEntity e) { return IceRender.TEX; }
    }

    // ---------- NPCs ----------
    private static final Map<String, Boolean> HAS_PNG = new HashMap<>();

    static ResourceLocation npcTexture(FvNpcEntity e) {
        NpcDefs.Def d = e.def();
        if (d.randomLook()) return SkinPainter.textureFor("npc_" + d.id() + "_" + e.seed(), e.look());
        return npcTexture(d.id());
    }

    static com.Ken.frostveil.data.CharacterProfile playerProfile(AbstractClientPlayer pl) {
        Minecraft mc = Minecraft.getInstance();
        if (pl == mc.player && com.Ken.frostveil.client.ClientState.preview != null) return com.Ken.frostveil.client.ClientState.preview;
        if (com.Ken.frostveil.client.ClientState.MODES.getOrDefault(pl.getUUID(), 0) == 0) return null;
        return com.Ken.frostveil.client.ClientState.PROFILES.get(pl.getUUID());
    }

    static ResourceLocation npcTexture(String id) {
        ResourceLocation png = Fv.id("textures/entity/npc/" + id + ".png");
        boolean has = HAS_PNG.computeIfAbsent(id, k -> Minecraft.getInstance().getResourceManager().getResource(png).isPresent());
        return has ? png : SkinPainter.textureFor("npc_" + id, NpcDefs.get(id).look());
    }

    /** Player-style model with activity animations (hammering, stirring, training forms, eating, selling, farming, playing, guarding, talking, waving). */
    static final class NpcModel extends PlayerModel<FvNpcEntity> {
        NpcModel(net.minecraft.client.model.geom.ModelPart root) { super(root, false); }

        private static float seg(float s, float a, float b) { return Math.max(0f, Math.min(1f, (s - a) / (b - a))); }
        private static float sm(float x) { return x * x * (3f - 2f * x); }
        private static float mix(float a, float b, float x) { return a + (b - a) * x; }

        @Override
        public void setupAnim(FvNpcEntity e, float ls, float lsa, float age, float yaw, float pitch) {
            int act0 = e.act();
            this.rightArmPose = (act0 == 20 || act0 == 21) ? HumanoidModel.ArmPose.BOW_AND_ARROW : HumanoidModel.ArmPose.EMPTY;
            this.leftArmPose = HumanoidModel.ArmPose.EMPTY;
            super.setupAnim(e, ls, lsa, age, yaw, pitch);
            float t = age;
            float tt = Math.max(0f, age - e.actStart());
            rightArm.zRot += (float) Math.sin(t * 0.067f) * 0.03f + 0.04f; // breathing
            leftArm.zRot -= (float) Math.sin(t * 0.067f) * 0.03f + 0.04f;
            if (!e.isSleeping()) {
                switch (e.act()) {
                    case 1 -> { rightArm.xRot = -1.2f + (float) Math.sin(t * 0.5f) * 0.9f; leftArm.xRot = -0.6f; body.xRot = 0.12f; head.xRot += 0.2f; }
                    case 2 -> { rightArm.xRot = -0.9f; rightArm.yRot = (float) Math.sin(t * 0.3f) * 0.4f; leftArm.xRot = -0.3f; head.xRot += 0.25f; }
                    case 3 -> { rightArm.xRot = -1.4f + (float) Math.sin(t * 0.25f) * 0.5f; leftArm.xRot = -1.4f + (float) Math.cos(t * 0.25f) * 0.5f; rightArm.yRot = -0.3f; leftArm.yRot = 0.3f; body.yRot = (float) Math.sin(t * 0.125f) * 0.25f; }
                    case 4 -> { rightArm.xRot = -1.9f + (float) Math.sin(t * 0.2f) * 0.25f; rightArm.yRot = -0.3f; }
                    case 5 -> { rightArm.xRot = -2.5f + (float) Math.sin(t * 0.4f) * 0.3f; rightArm.zRot = -0.3f; }
                    case 6 -> { body.xRot = 0.5f + (float) Math.sin(t * 0.3f) * 0.1f; rightArm.xRot = -0.9f + (float) Math.sin(t * 0.3f) * 0.7f; head.xRot += 0.3f; }
                    case 7 -> { rightArm.xRot = (float) Math.sin(t * 0.9f) * 1.1f; leftArm.xRot = -(float) Math.sin(t * 0.9f) * 1.1f; }
                    case 8 -> { rightArm.xRot = -0.9f; rightArm.yRot = -0.7f; leftArm.xRot = -0.9f; leftArm.yRot = 0.7f; }
                    case 10 -> { rightArm.xRot = -0.9f + (float) Math.sin(t * 0.2f) * 0.4f; rightArm.zRot = -0.2f; leftArm.xRot = -0.5f + (float) Math.cos(t * 0.17f) * 0.3f; head.yRot += (float) Math.sin(t * 0.1f) * 0.1f; }
                    case 11 -> { rightArm.xRot = -2.8f; rightArm.zRot = -0.3f + (float) Math.sin(t * 0.6f) * 0.4f; }
                    case 20, 21 -> { // bow: draw the string back, then release with a small recoil
                        float pull = act0 == 20 ? Math.min(1f, tt / 10f) : 1f - Math.min(1f, tt / 6f);
                        leftArm.yRot += 0.35f * pull; leftArm.zRot -= 0.15f * pull; body.yRot = -0.22f;
                        if (act0 == 21) { head.xRot -= 0.06f * (1f - tt / 6f); rightArm.zRot += 0.2f * Math.max(0f, 1f - tt / 6f); }
                    }
                    case 22, 29 -> { // sword slash: wind up, cut across the body, recover (29 is the backhand)
                        float s = Math.min(1f, tt / 10f), dir = act0 == 22 ? 1f : -1f;
                        float wind = sm(seg(s, 0f, 0.35f)), cut = sm(seg(s, 0.35f, 0.7f)), back = sm(seg(s, 0.7f, 1f));
                        float arm = mix(mix(-0.5f, -2.4f, wind), 0.35f, cut);
                        arm = mix(arm, -0.6f, back);
                        rightArm.xRot = arm;
                        rightArm.yRot = dir * mix(mix(0f, -0.5f, wind), 0.7f, cut) * (1f - back);
                        rightArm.zRot += dir * 0.2f * cut;
                        leftArm.xRot = mix(-0.3f, 0.4f, cut) * (1f - back) - 0.3f * back; leftArm.yRot = 0.3f;
                        body.yRot = dir * mix(mix(0f, -0.4f, wind), 0.6f, cut) * (1f - back);
                        body.xRot = 0.25f * (float) Math.sin(Math.PI * s);
                        head.yRot += body.yRot * 0.3f;
                        rightLeg.xRot += -0.5f * (float) Math.sin(Math.PI * s); leftLeg.xRot += 0.4f * (float) Math.sin(Math.PI * s);
                    }
                    case 23 -> { // spear: pull back, thrust, recover
                        float s = Math.min(1f, tt / 14f);
                        float back = sm(seg(s, 0f, 0.4f)), thrust = sm(seg(s, 0.4f, 0.62f)), rec = sm(seg(s, 0.62f, 1f));
                        float r = mix(mix(-0.4f, 0.9f, back), -1.65f, thrust);
                        rightArm.xRot = mix(r, -0.6f, rec); rightArm.yRot = -0.15f - 0.2f * back;
                        leftArm.xRot = mix(-1.0f, -1.5f, thrust); leftArm.yRot = 0.55f;
                        body.yRot = -0.35f * back * (1f - thrust) + 0.15f * thrust * (1f - rec);
                        body.xRot = 0.3f * thrust * (1f - rec);
                        rightLeg.xRot = -0.7f * thrust * (1f - rec); leftLeg.xRot = 0.6f * thrust * (1f - rec);
                    }
                    case 24 -> { // dash lunge: low, leaning, arm swept back, then a stab
                        float s = Math.min(1f, tt / 14f);
                        float lean = sm(seg(s, 0f, 0.2f)) * (1f - sm(seg(s, 0.8f, 1f)));
                        body.xRot = 0.55f * lean; head.xRot -= 0.35f * lean;
                        rightArm.xRot = mix(0.9f * lean, -1.5f, sm(seg(s, 0.65f, 0.85f))); leftArm.xRot = 0.9f * lean; leftArm.zRot -= 0.3f * lean;
                        rightLeg.xRot = -1.0f * lean; leftLeg.xRot = 0.8f * lean;
                    }
                    case 25 -> { // two-handed overhead slam
                        float s = Math.min(1f, tt / 18f);
                        float up = sm(seg(s, 0f, 0.5f)), down = sm(seg(s, 0.5f, 0.66f)), rec = sm(seg(s, 0.66f, 1f));
                        float arm = mix(mix(0f, -3.0f, up), 0.15f, down);
                        arm = mix(arm, -0.2f, rec);
                        rightArm.xRot = arm; leftArm.xRot = arm; rightArm.zRot = -0.12f; leftArm.zRot = 0.12f;
                        body.xRot = mix(mix(0f, -0.28f, up), 0.65f, down) * (1f - rec);
                        head.xRot += 0.2f * down;
                        rightLeg.xRot = -0.5f * down * (1f - rec); leftLeg.xRot = 0.4f * down * (1f - rec);
                    }
                    case 26 -> { // Yu's frost burst: gather with open arms, then thrust the cold outward
                        float s = Math.min(1f, tt / 14f);
                        float gather = sm(seg(s, 0f, 0.5f)), burst = sm(seg(s, 0.5f, 0.62f)), rec = sm(seg(s, 0.62f, 1f));
                        float zr = mix(mix(0f, 1.3f, gather), 0.45f, burst) * (1f - rec * 0.8f);
                        float xr = mix(mix(-0.2f, -1.0f, gather), 0.1f, burst);
                        rightArm.zRot = zr; leftArm.zRot = -zr; rightArm.xRot = xr; leftArm.xRot = xr;
                        body.xRot = -0.15f * gather + 0.25f * burst * (1f - rec); head.xRot -= 0.25f * gather;
                    }
                    case 27 -> { rightArm.xRot = -1.1f; rightArm.yRot = -0.9f; leftArm.xRot = -1.1f; leftArm.yRot = 0.9f; body.xRot = 0.1f; }
                    case 28 -> { // stagger: thrown back by a hit
                        float k = 1f - sm(Math.min(1f, tt / 8f));
                        body.xRot = -0.4f * k; head.xRot -= 0.3f * k;
                        rightArm.zRot += 0.8f * k; leftArm.zRot -= 0.8f * k; rightArm.xRot = 0.5f * k; leftArm.xRot = 0.5f * k;
                        rightLeg.zRot -= 0.15f * k; leftLeg.zRot += 0.15f * k;
                    }
                    case 30 -> { // ready stance: weapon up, feet apart, a slight bob
                        float bob = (float) Math.sin(t * 0.12f) * 0.03f;
                        rightArm.xRot = -0.9f + bob; rightArm.yRot = -0.25f; leftArm.xRot = -0.35f - bob; leftArm.yRot = 0.25f;
                        body.xRot = 0.06f; rightLeg.zRot -= 0.06f; leftLeg.zRot += 0.06f;
                    }
                    default -> { }
                }
            }
            leftSleeve.copyFrom(leftArm); rightSleeve.copyFrom(rightArm); jacket.copyFrom(body); hat.copyFrom(head);
            leftPants.copyFrom(leftLeg); rightPants.copyFrom(rightLeg);
        }
    }

    static final class NpcRenderer extends HumanoidMobRenderer<FvNpcEntity, NpcModel> {
        NpcRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new NpcModel(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
            this.addLayer(new Cosmetics.Layer<FvNpcEntity, NpcModel>(this, FvNpcEntity::look));
        }
        @Override public ResourceLocation getTextureLocation(FvNpcEntity e) { return npcTexture(e); }

        @Override
        public void render(FvNpcEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
            super.render(e, yaw, pt, ps, buf, light);
            String b = e.bubble();
            if (b.isEmpty() || e.isSleeping()) return;
            ps.pushPose();
            ps.translate(0, e.getBbHeight() + 0.95, 0);
            ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
            ps.scale(-0.025f, -0.025f, 0.025f);
            net.minecraft.client.gui.Font font = this.getFont();
            font.drawInBatch(b, -font.width(b) / 2f, 0, 0xFFFFFFFF, false, ps.last().pose(), buf, net.minecraft.client.gui.Font.DisplayMode.NORMAL, 0xAA101820, light);
            ps.popPose();
        }
        @Override protected void scale(FvNpcEntity e, PoseStack ps, float partial) { float s = e.def().scale(); ps.scale(s, s, s); }
    }

    static final class FargasRenderer extends HumanoidMobRenderer<FargasEntity, PlayerModel<FargasEntity>> {
        FargasRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
            this.addLayer(new Cosmetics.Layer<FargasEntity, PlayerModel<FargasEntity>>(this, f -> NpcDefs.get("fargas").look()));
        }
        @Override public ResourceLocation getTextureLocation(FargasEntity e) { return npcTexture("fargas"); }
    }

    // ---------- beasts: vanilla cow / pig models, tinted ----------
    static final class TintCow extends CowModel<EiuBeastEntity> {
        float r = 1, g = 1, b = 1;
        TintCow(net.minecraft.client.model.geom.ModelPart p) { super(p); }
        @Override
        public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float rr, float gg, float bb, float aa) {
            super.renderToBuffer(ps, vc, light, overlay, rr * r, gg * g, bb * b, aa);
        }
    }

    static final class TintPig extends PigModel<EiuBeastEntity> {
        float r = 1, g = 1, b = 1;
        TintPig(net.minecraft.client.model.geom.ModelPart p) { super(p); }
        @Override
        public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float rr, float gg, float bb, float aa) {
            super.renderToBuffer(ps, vc, light, overlay, rr * r, gg * g, bb * b, aa);
        }
    }

    static final class BeastRenderer extends MobRenderer<EiuBeastEntity, EntityModel<EiuBeastEntity>> {
        private final TintCow cow;
        private final TintPig pig;
        private static final ResourceLocation COW = new ResourceLocation("textures/entity/cow/cow.png");
        private static final ResourceLocation PIG = new ResourceLocation("textures/entity/pig/pig.png");

        BeastRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new TintCow(ctx.bakeLayer(ModelLayers.COW)), 0.7f);
            this.cow = (TintCow) this.model;
            this.pig = new TintPig(ctx.bakeLayer(ModelLayers.PIG));
        }

        @Override
        public void render(EiuBeastEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            int k = e.kind();
            if (k <= 1) { this.model = cow; cow.r = k == 0 ? 0.95f : 0.8f; cow.g = k == 0 ? 0.7f : 0.55f; cow.b = k == 0 ? 0.7f : 0.55f; }
            else { this.model = pig; pig.r = k == 2 ? 0.55f : 1f; pig.g = k == 2 ? 0.45f : 0.5f; pig.b = k == 2 ? 0.45f : 0.2f; }
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        protected void scale(EiuBeastEntity e, PoseStack ps, float partial) {
            switch (e.kind()) {
                case 1 -> ps.scale(1.3f, 1.3f, 1.3f);
                case 2 -> ps.scale(1.25f, 1.25f, 1.25f);
                case 3 -> ps.scale(0.8f, 1.15f, 1.3f);
                default -> { }
            }
        }

        @Override public ResourceLocation getTextureLocation(EiuBeastEntity e) { return e.kind() <= 1 ? COW : PIG; }
    }

    // ---------- Ice Halo orbiting a player ----------
    static final class HaloLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
        private final ShapeSpec spec = new ShapeSpec();

        HaloLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) { super(parent); spec.prim = ShapeSpec.Prim.SHARD; }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer p, float limb, float limbAmt, float partial, float age, float headYaw, float headPitch) {
            PublicState st = com.Ken.frostveil.client.ClientState.pub(p.getUUID());
            if (!st.haloOn() || st.haloShards() <= 0) return;
            spec.length = Math.max(0.3f, st.haloLen()); spec.width = Math.max(0.2f, st.haloWid());
            int n = st.haloShards();
            float R = st.haloRadius();
            ps.pushPose();
            ps.translate(0.0, 1.501, 0.0);
            ps.scale(-1f, -1f, 1f); // back to world-oriented axes with the origin at the feet
            double t = (p.tickCount + partial) * (0.04 + st.haloSpin() * 0.08);
            for (int i = 0; i < n; i++) {
                double a = t + i * Math.PI * 2 / n;
                double x, y, z;
                switch (st.haloPattern()) {
                    case 1 -> { x = Math.cos(a) * R; z = Math.sin(a) * R; y = 0.5 + 1.4 * i / Math.max(1, n - 1); }            // spiral
                    case 2 -> { double u = Math.acos(1 - 2.0 * (i + 0.5) / n), v = Math.PI * (1 + Math.sqrt(5)) * i + t; x = Math.sin(u) * Math.cos(v) * R; y = 1.0 + Math.cos(u) * R * 0.8; z = Math.sin(u) * Math.sin(v) * R; } // shell
                    default -> { x = Math.cos(a) * R; z = Math.sin(a) * R; y = 1.1 + Math.sin(a * 2 + t) * 0.12; }                  // ring
                }
                ps.pushPose();
                ps.translate(x, y, z);
                ps.mulPose(Axis.YP.rotation((float) -a));
                IceRender.draw(spec, ps, buf, 15728880, 1f, 0.85f, 0.95f, 1f, 0.9f);
                ps.popPose();
            }
            ps.popPose();
        }
    }

    static boolean unused() { return ClientSkins.class != null; }
}
