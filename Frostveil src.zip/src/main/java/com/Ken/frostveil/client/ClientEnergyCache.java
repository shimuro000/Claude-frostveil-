package com.Ken.frostveil.client;

import com.Ken.frostveil.capability.PlayerEnergyData;
import net.minecraft.nbt.CompoundTag;

/** Client-side read-only copy of the local player's energy data. Never authoritative. */
public class ClientEnergyCache {
    private static final PlayerEnergyData DATA = new PlayerEnergyData();
    public static void update(CompoundTag t) { DATA.load(t); }
    public static PlayerEnergyData get() { return DATA; }
}
