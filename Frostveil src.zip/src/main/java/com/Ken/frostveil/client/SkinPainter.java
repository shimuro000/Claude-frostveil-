package com.Ken.frostveil.client;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.CharacterProfile;
import com.mojang.blaze3d.platform.NativeImage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Paints a 64x64 Minecraft skin from a CharacterProfile at runtime. This is what makes the character creator real:
 * skin tone, eyes, brows, scars, hair style/colour/highlight, coat (with fur trim), shirt, boots, scarf, bag, goggles...
 * Hair that hangs down is painted over the back of the coat. NPCs use the same painter.
 */
public final class SkinPainter {
    private static final Map<String, Integer> HASHES = new HashMap<>();
    private static final Map<String, ResourceLocation> LOCS = new HashMap<>();

    private SkinPainter() {}

    /** Returns a registered texture for this key, repainting only when the profile changed. */
    public static ResourceLocation textureFor(String key, CharacterProfile p) {
        int h = p.toTag().toString().hashCode();
        ResourceLocation rl = LOCS.get(key);
        if (rl != null && HASHES.getOrDefault(key, 0) == h) return rl;
        String safe = key.toLowerCase().replaceAll("[^a-z0-9/._-]", "_");
        ResourceLocation loc = Fv.id("dyn/" + safe);
        int[] px = paint(p);
        NativeImage img = new NativeImage(64, 64, true);
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            int c = px[y * 64 + x];
            int abgr = (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF);
            img.setPixelRGBA(x, y, abgr);
        }
        Minecraft mc = Minecraft.getInstance();
        if (rl != null) mc.getTextureManager().release(rl);
        mc.getTextureManager().register(loc, new DynamicTexture(img));
        LOCS.put(key, loc);
        HASHES.put(key, h);
        return loc;
    }

    // ---------- palettes ----------
    static int skin(String s) {
        return switch (s) { case "pale" -> 0xF3DDD1; case "fair" -> 0xEBC9AE; case "yellow" -> 0xE6BE7A; case "tan" -> 0xC99566; case "brown" -> 0x9A6B45; default -> 0x6B4429; };
    }
    static int hair(String s) {
        return switch (s) { case "black" -> 0x16161C; case "brown" -> 0x5A3A22; case "white" -> 0xEDEDF2; case "grey" -> 0x8C8E96; case "red" -> 0x9C2B26; case "blond" -> 0xD8C078; case "golden" -> 0xE0B13A; case "silver" -> 0xC9D2DC; default -> 0xD9792B; };
    }
    static int highlight(String s) {
        return switch (s) { case "blue" -> 0x4A8CFF; case "red" -> 0xD43A3A; case "green" -> 0x3FBF6A; case "silver" -> 0xDDE6F0; case "violet" -> 0x9A5CFF; default -> -1; };
    }
    static int eye(String s) {
        return switch (s) { case "blue" -> 0x3C74D6; case "green" -> 0x3FA85A; case "brown" -> 0x6B3E22; case "grey" -> 0x8A94A0; case "amber" -> 0xD79A2A; default -> 0x9A4DFF; };
    }
    static int cloth(String s) {
        return switch (s) {
            case "midnight" -> 0x14161E; case "charcoal" -> 0x2A2B31; case "ice" -> 0x7FA6C9; case "crimson" -> 0x8A1F2B; case "forest" -> 0x2F5A3D; case "sand" -> 0xB89B6A; case "violet" -> 0x5A3C86;
            case "white" -> 0xE8EAF0; case "navy" -> 0x1D2A4A; case "grey" -> 0x70737C; case "red" -> 0x9C2B26; case "green" -> 0x3B6B47; case "cream" -> 0xE2D8BC; default -> 0x2A2B31;
        };
    }
    static int trim(String s) {
        return switch (s) { case "white_fur" -> 0xF2F4F8; case "silver" -> 0xB9C3CF; case "gold" -> 0xD8B04A; case "cyan" -> 0x58C7D6; case "red" -> 0xC03A3A; default -> 0x1A1A1E; };
    }

    private static int shade(int c, float f) {
        int r = Math.min(255, Math.round(((c >> 16) & 255) * f)), g = Math.min(255, Math.round(((c >> 8) & 255) * f)), b = Math.min(255, Math.round((c & 255) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void fill(int[] px, int x0, int y0, int x1, int y1, int c) { // x1,y1 exclusive
        int col = 0xFF000000 | c;
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * 64 + x] = col;
    }

    private static void dot(int[] px, int x, int y, int c) { if (x >= 0 && x < 64 && y >= 0 && y < 64) px[y * 64 + x] = 0xFF000000 | c; }

    // ---------- the painter ----------
    public static int[] paint(CharacterProfile p) {
        int[] px = new int[64 * 64];
        int skin = skin(p.skin), hair = hair(p.hairColor), hl = highlight(p.highlight), eye = eye(p.eyeColor);
        int shirt = cloth(p.shirtColor), coat = cloth(p.coatColor), trim = trim(p.trim);
        boolean longHair = p.hair.equals("long_hanging") || p.hair.equals("ponytail") || p.hair.equals("three_ties");
        boolean bald = p.hair.equals("bald");

        // base body: skin everywhere, then clothes
        fill(px, 0, 0, 64, 16, skin);                    // head (all faces)
        fill(px, 16, 16, 40, 32, shirt);                 // torso
        fill(px, 40, 16, 56, 32, shirt);                 // right arm
        fill(px, 0, 16, 16, 32, shade(shirt, 0.55f));    // right leg (trousers)
        fill(px, 16, 48, 32, 64, shade(shirt, 0.55f));   // left leg
        fill(px, 32, 48, 48, 64, shirt);                 // left arm
        fill(px, 20, 16, 36, 20, shirt);                 // torso top/bottom
        for (int[] a : new int[][]{{40, 16}, {32, 48}}) { // hands: last 3 rows of the arms are skin
            fill(px, a[0], a[1] + 13 + (a[1] == 16 ? 0 : 0), a[0] + 16, a[1] + 16, skin);
        }
        fill(px, 44, 16, 52, 20, skin); fill(px, 36, 48, 44, 52, skin); // shoulders/ends caps
        // boots: last 3 rows of the legs
        int boot = p.boots.equals("fur") ? 0x6B5A4A : (p.boots.equals("plain") ? 0x3A3026 : 0x23262E);
        fill(px, 0, 29, 16, 32, boot); fill(px, 16, 61, 32, 64, boot);
        if (p.boots.equals("fur")) { fill(px, 0, 28, 16, 29, trim(p.trim)); fill(px, 16, 60, 32, 61, trim(p.trim)); }

        // ---- head ----
        if (!bald) {
            fill(px, 8, 0, 16, 8, hair);                       // top
            fill(px, 8, 8, 16, 10, hair);                      // fringe
            fill(px, 0, 8, 8, longHair ? 16 : 11, hair);       // sides
            fill(px, 16, 8, 24, longHair ? 16 : 11, hair);
            fill(px, 24, 8, 32, longHair ? 16 : 12, hair);     // back
            switch (p.hair) {
                case "messy", "curly" -> { dot(px, 8, 10, hair); dot(px, 10, 10, hair); dot(px, 13, 10, hair); dot(px, 15, 10, hair); dot(px, 9, 11, hair); dot(px, 14, 11, hair); }
                case "wolf_cut" -> { fill(px, 8, 10, 10, 12, hair); fill(px, 14, 10, 16, 12, hair); dot(px, 11, 10, hair); dot(px, 12, 10, hair); fill(px, 0, 8, 8, 13, hair); fill(px, 16, 8, 24, 13, hair); }
                case "topknot" -> { fill(px, 40, 0, 48, 8, hair); }
                default -> { dot(px, 11, 10, hair); dot(px, 12, 10, hair); }
            }
            // overlay layer: hair volume
            fill(px, 40, 0, 48, 2, hair); fill(px, 32, 8, 40, 10, hair); fill(px, 48, 8, 56, 10, hair); fill(px, 56, 8, 64, 12, hair);
            if (longHair) { fill(px, 56, 8, 64, 16, hair); fill(px, 32, 8, 40, 16, hair); fill(px, 48, 8, 56, 16, hair); }
            // sheen highlights
            if (hl >= 0) {
                for (int y = 0; y < 16; y++) for (int x = 0; x < 32; x++) {
                    if ((px[y * 64 + x] & 0xFFFFFF) == hair && ((x * 7 + y * 5) % 9 == 0)) dot(px, x, y, hl);
                }
            }
        }
        // face
        int dark = shade(skin, 0.78f);
        int brow = bald ? shade(skin, 0.5f) : shade(hair, 0.9f);
        dot(px, 9, 11, brow); dot(px, 10, 11, brow); dot(px, 13, 11, brow); dot(px, 14, 11, brow);
        if (p.brows.equals("thick")) { dot(px, 8, 11, brow); dot(px, 15, 11, brow); dot(px, 9, 10, brow); dot(px, 14, 10, brow); }
        if (p.brows.equals("thin")) { dot(px, 9, 11, shade(brow, 1.4f)); dot(px, 14, 11, shade(brow, 1.4f)); }
        switch (p.eyeShape) {
            case "sharp" -> { dot(px, 9, 12, 0xFFFFFF); dot(px, 10, 12, eye); dot(px, 13, 12, eye); dot(px, 14, 12, 0xFFFFFF); dot(px, 10, 13, shade(eye, 0.6f)); dot(px, 13, 13, shade(eye, 0.6f)); dot(px, 9, 11, brow); dot(px, 14, 11, brow); }
            case "soft" -> { dot(px, 9, 12, 0xFFFFFF); dot(px, 10, 12, eye); dot(px, 10, 13, shade(eye, 0.8f)); dot(px, 13, 12, eye); dot(px, 14, 12, 0xFFFFFF); dot(px, 13, 13, shade(eye, 0.8f)); }
            default -> { dot(px, 9, 12, 0xFFFFFF); dot(px, 10, 12, eye); dot(px, 9, 13, shade(eye, 0.7f)); dot(px, 10, 13, shade(eye, 0.7f)); dot(px, 13, 12, eye); dot(px, 14, 12, 0xFFFFFF); dot(px, 13, 13, shade(eye, 0.7f)); dot(px, 14, 13, shade(eye, 0.7f)); }
        }
        dot(px, 11, 14, dark); dot(px, 12, 14, dark);
        switch (p.scar) {
            case "cheek" -> { dot(px, 9, 13, 0xC86A6A); dot(px, 8, 14, 0xC86A6A); dot(px, 9, 14, 0xB45A5A); }
            case "brow" -> { dot(px, 13, 10, 0xC86A6A); dot(px, 13, 11, 0xB45A5A); }
            case "lip" -> { dot(px, 12, 14, 0xB45A5A); dot(px, 12, 15, 0xC86A6A); }
            default -> { }
        }
        if (p.mole.equals("cheek")) dot(px, 14, 14, shade(skin, 0.45f));
        if (p.mole.equals("chin")) dot(px, 12, 15, shade(skin, 0.45f));
        if (p.goggles) { fill(px, 40, 11, 56, 12, 0x2A2A30); fill(px, 41, 12, 47, 14, 0x9ED0E6); fill(px, 49, 12, 55, 14, 0x9ED0E6); fill(px, 40, 11, 48, 12, 0x2A2A30); }
        if (p.earring) { dot(px, 19, 13, 0xD8B04A); dot(px, 19, 14, 0xD8B04A); }

        // ---- coat / clothes on the overlay layers ----
        if (!p.coat.equals("none") && !p.coat.equals("wool_shirt")) {
            boolean cloak = p.coat.equals("cloak");
            fill(px, 16, 36, 40, 48, coat);                                    // jacket overlay (body)
            if (!cloak) { fill(px, 40, 32, 56, 45, coat); fill(px, 48, 48, 64, 61, coat); }  // sleeves overlay (hands stay bare)
            fill(px, 0, 36, 16, 44, coat); fill(px, 0, 52, 16, 60, coat);      // coat skirt over the legs
            fill(px, 0, 43, 16, 44, shade(coat, 0.7f)); fill(px, 0, 59, 16, 60, shade(coat, 0.7f));
            fill(px, 23, 36, 25, 48, shade(coat, 0.65f));                      // front opening line
            // trim: high collar + cuffs + hem
            boolean fur = p.coat.equals("shimoro_coat");
            fill(px, 16, 36, 40, 38, trim); fill(px, 20, 32, 36, 36, coat);
            fill(px, 40, 43, 56, 45, trim); fill(px, 48, 59, 64, 61, trim);     // cuffs
            if (fur) { fill(px, 16, 36, 40, 39, trim); fill(px, 0, 43, 16, 44, trim); fill(px, 0, 59, 16, 60, trim); fill(px, 40, 36, 48, 38, trim); fill(px, 48, 52, 56, 54, trim); }
            // belt + strap on sleeves (Shimoro's tied wrists)
            fill(px, 16, 44, 40, 45, 0x1B1410);
            fill(px, 40, 42, 56, 43, 0x1B1410); fill(px, 48, 58, 64, 59, 0x1B1410);
        }
        if (p.scarf.equals("white") || p.scarf.equals("red") || p.scarf.equals("blue")) {
            int sc = p.scarf.equals("white") ? 0xEDEDF2 : (p.scarf.equals("red") ? 0xB03030 : 0x3A63B8);
            fill(px, 16, 36, 40, 37, sc); fill(px, 20, 37, 24, 42, sc);
        }
        if (p.waistBag) { fill(px, 16, 44, 40, 45, 0x3A2A1C); fill(px, 28, 45, 32, 48, 0x5A4126); dot(px, 29, 45, 0xC9A24A); }
        if (p.lanternBackpack) { fill(px, 34, 38, 38, 46, 0x5A4126); fill(px, 35, 36, 37, 38, 0xFFD36B); }
        // long hair falls over the coat's back
        if (longHair && !bald) {
            switch (p.hair) {
                case "ponytail" -> fill(px, 35, 36, 37, 46, hair);
                case "three_ties" -> { fill(px, 34, 36, 35, 44, hair); fill(px, 36, 36, 37, 44, hair); fill(px, 38, 36, 39, 44, hair); fill(px, 34, 41, 39, 42, hair); }
                default -> fill(px, 34, 36, 39, 47, hair);
            }
            if (hl >= 0) for (int y = 36; y < 47; y += 2) dot(px, 35 + (y % 3), y, hl);
        }
        // transparent overlay padding: any unpainted pixel in the overlay areas is already 0 (transparent)
        return px;
    }

    private static void clearAlpha(int[] px, int x0, int y0, int x1, int y1) {
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * 64 + x] = 0;
    }
}
