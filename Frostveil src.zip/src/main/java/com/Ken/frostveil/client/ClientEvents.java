package com.Ken.frostveil.client;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.fx.Anims;
import com.Ken.frostveil.client.fx.Juice;
import com.Ken.frostveil.client.render.IceRender;
import com.Ken.frostveil.client.screen.SheetScreen;
import com.Ken.frostveil.client.screen.ShapeStudioScreen;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.ice.ShapeLimits;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.network.FvNet;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Key bindings, input, HUD, camera effects and world-space overlays. */
@Mod.EventBusSubscriber(modid = Fv.ID, value = Dist.CLIENT)
public final class ClientEvents {
    private static final String CAT = "key.categories.frostveil";
    public static final KeyMapping CAST = key("cast", InputConstants.KEY_F), STUDIO = key("studio", InputConstants.KEY_R), MEDITATE = key("meditate", InputConstants.KEY_G),
            SKIN = key("skin_sense", InputConstants.KEY_Z), FORGE = key("forge", InputConstants.KEY_X), LIMB = key("forge_limb", InputConstants.KEY_V),
            CUTOFF = key("cutoff", InputConstants.KEY_C), INFUSE = key("infuse", InputConstants.KEY_B), HALO = key("halo", InputConstants.KEY_H),
            RELEASE = key("halo_release", InputConstants.KEY_J), SHEET = key("sheet", InputConstants.KEY_K), JOURNAL = key("journal", InputConstants.KEY_L),
            DODGE = key("dodge", InputConstants.KEY_LALT), ORDER = key("order", InputConstants.KEY_U), SLOT = key("next_slot", InputConstants.KEY_N),
            FORM = key("next_form", InputConstants.KEY_T);

    private static KeyMapping key(String name, int code) {
        return new KeyMapping("key.frostveil." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, code, CAT);
    }

    // charge / stroke state
    private static boolean charging = false;
    private static int held = 0;
    private static final List<Vec3> stroke = new ArrayList<>();
    private static boolean meditating = false;
    private static int medTicks = 0;
    private static int cutoffHeld = 0;
    private static int forgeLimbSel = 1;
    private static int comboIdx = 0;
    private static long comboExpire = 0;
    private static boolean guardSent = false;
    private static int orderSel = 0;

    private ClientEvents() {}

    // ---------- mod-bus registration ----------
    @Mod.EventBusSubscriber(modid = Fv.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            for (KeyMapping k : new KeyMapping[]{CAST, STUDIO, MEDITATE, SKIN, FORGE, LIMB, CUTOFF, INFUSE, HALO, RELEASE, SHEET, JOURNAL, DODGE, ORDER, SLOT, FORM}) e.register(k);
        }

        @SubscribeEvent
        public static void overlay(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("hud", (gui, g, pt, w, h) -> Hud.render(g, w, h, pt));
        }

        @SubscribeEvent
        public static void setup(FMLClientSetupEvent e) {
            e.enqueueWork(() -> { Anims.registerFactory(); ClientHooks.init(); });
        }
    }

    // ---------- helpers ----------
    private static boolean live(Minecraft mc) { return mc.player != null && mc.level != null && FvCap.CLIENT.active() && FvCap.CLIENT.created; }
    private static void act(String a) { FvNet.toServer(new FvNet.ActionMsg(a)); }
    private static void act(String a, int v) { FvNet.toServer(new FvNet.ActionMsg(a, v)); }
    public static boolean isCharging() { return charging; }
    public static int heldTicks() { return held; }
    public static boolean isMeditating() { return meditating; }
    public static int meditationTicks() { return medTicks; }
    public static int forgeLimb() { return forgeLimbSel; }
    public static List<Vec3> strokePoints() { return stroke; }

    // ---------- client tick ----------
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        Juice.tick();
        if (mc.level == null || mc.player == null) return;
        if (mc.player.tickCount % 10 == 0) ClientSkins.apply(mc);
        for (net.minecraft.world.entity.player.Player pl : mc.level.players()) {
            if (pl instanceof net.minecraft.client.player.AbstractClientPlayer acp) {
                boolean local = pl == mc.player;
                Anims.update(acp, local, local && meditating, local && charging, local && charging && currentSpec().stroke);
            }
        }
        if (!live(mc) || mc.screen != null) {
            if (charging && mc.screen != null) { charging = false; stroke.clear(); }
            return;
        }
        FvData d = FvCap.CLIENT;
        LocalPlayer p = mc.player;

        while (STUDIO.consumeClick()) mc.setScreen(new ShapeStudioScreen());
        while (SHEET.consumeClick()) mc.setScreen(new SheetScreen());
        while (JOURNAL.consumeClick()) act("journal");
        while (SKIN.consumeClick()) act("skin_sense");
        while (INFUSE.consumeClick()) act("infuse");
        while (HALO.consumeClick()) act("halo");
        while (RELEASE.consumeClick()) act("halo_release");
        while (ORDER.consumeClick()) { orderSel = (orderSel + 1) % 4; act("order", orderSel); }
        while (SLOT.consumeClick()) act("slot", (d.selected + 1) % d.presets.length);
        while (FORM.consumeClick()) { for (int i = 1; i <= 3; i++) { int f = (d.form + i) % 3; if (d.formUnlocked(f)) { act("form", f); break; } } }
        while (LIMB.consumeClick()) { forgeLimbSel = forgeLimbSel % 4 + 1; p.displayClientMessage(Component.literal("Forge: " + new String[]{"", "right arm", "left arm", "legs", "torso"}[forgeLimbSel]), true); }
        while (DODGE.consumeClick()) dodge(p);

        // Forge: hold
        if (FORGE.isDown() && d.forgeLimb == 0) act("forge_limb", forgeLimbSel);
        if (!FORGE.isDown() && d.forgeLimb != 0) act("forge_limb", 0);

        // Cutoff (tap) / EIU Shroud (hold)
        if (CUTOFF.isDown()) { cutoffHeld++; if (cutoffHeld == 12) FvNet.toServer(new FvNet.ActionMsg("shroud", 1)); }
        else { if (cutoffHeld > 0 && cutoffHeld < 12) act("cutoff"); if (cutoffHeld >= 12) FvNet.toServer(new FvNet.ActionMsg("shroud", 0)); cutoffHeld = 0; }

        // Guard (hold right mouse with empty hand or a blade)
        boolean wantGuard = mc.options.keyUse.isDown() && (p.getMainHandItem().isEmpty() || p.getMainHandItem().getItem() instanceof SwordItem) && !(mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK);
        if (wantGuard != guardSent) { guardSent = wantGuard; d.guarding = wantGuard; FvNet.toServer(new FvNet.ActionMsg("guard", wantGuard ? 1 : 0)); }

        // Meditation / feel the core
        if (MEDITATE.isDown()) {
            if (!meditating) { meditating = true; medTicks = 0; act("meditate", 1); }
            medTicks++;
        } else if (meditating) {
            meditating = false;
            act("meditate", 0);
            if (medTicks >= 60) FvNet.toServer(new FvNet.ActionMsg("train_feel", Math.min(95, 55 + medTicks / 5)));
            medTicks = 0;
        }

        // Casting: hold F (mental), watch the ring (physical), release (external)
        ShapeSpec spec = currentSpec();
        if (CAST.isDown() && !meditating) {
            if (!charging) { charging = true; held = 0; stroke.clear(); }
            held++;
            if (spec.stroke && held % 2 == 0) {
                ShapeLimits lim = ShapeLimits.of(d);
                Vec3 eye = p.getEyePosition();
                BlockHitResult hit = mc.level.clip(new ClipContext(eye, eye.add(p.getLookAngle().scale(lim.reach() + 4)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
                if (hit.getType() != HitResult.Type.MISS) {
                    Vec3 pt = Vec3.atBottomCenterOf(hit.getBlockPos().relative(hit.getDirection()));
                    if (stroke.isEmpty() || stroke.get(stroke.size() - 1).distanceTo(pt) >= 0.55) { if (stroke.size() < 60) stroke.add(pt); }
                }
            }
        } else if (charging) {
            charging = false;
            if (held >= 5) {
                FvNet.toServer(new FvNet.CastMsg(spec.copy(), Math.min(held, 40), new ArrayList<>(stroke)));
                Anims.play(p, "cast_release", 10);
            }
            held = 0;
            stroke.clear();
        }
        if (d.dirty) d.dirty = false;
        if (p.tickCount > comboExpireTick()) comboIdx = 0;
    }

    private static long comboExpireTick() { return comboExpire; }

    static ShapeSpec currentSpec() {
        FvData d = FvCap.CLIENT;
        return d.presets[Mth.clamp(d.selected, 0, d.presets.length - 1)];
    }

    private static void dodge(LocalPlayer p) {
        Vec3 look = p.getLookAngle().multiply(1, 0, 1).normalize();
        Vec3 right = new Vec3(-look.z, 0, look.x);
        Minecraft mc = Minecraft.getInstance();
        double f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        double s = (mc.options.keyRight.isDown() ? 1 : 0) - (mc.options.keyLeft.isDown() ? 1 : 0);
        Vec3 dir = f == 0 && s == 0 ? look.scale(-1) : look.scale(f).add(right.scale(s)).normalize();
        p.setDeltaMovement(p.getDeltaMovement().add(dir.x * 0.95, p.onGround() ? 0.12 : 0.0, dir.z * 0.95));
        FvNet.toServer(new FvNet.ActionMsg("dodge"));
        Anims.play(p, "dodge", 12);
    }

    // ---------- attack input: the server resolves the hit ----------
    @SubscribeEvent
    public static void interact(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (!live(mc) || mc.screen != null) return;
        if (e.isAttack() && (mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK)) {
            e.setCanceled(true);
            e.setSwingHand(false);
            LocalPlayer p = mc.player;
            long now = p.level().getGameTime();
            if (now > comboExpire) comboIdx = 0;
            boolean heavy = p.isSprinting();
            FvNet.toServer(new FvNet.AttackMsg(heavy, 0));
            Anims.play(p, heavy ? "heavy" : "combo" + (comboIdx + 1), heavy ? 18 : (comboIdx == 2 ? 14 : 9));
            if (!heavy) comboIdx = (comboIdx + 1) % 3; else comboIdx = 0;
            comboExpire = now + 26;
        } else if (e.isUseItem() && guardSent) {
            e.setCanceled(true);
        }
    }

    // ---------- camera ----------
    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles e) {
        float s = Juice.shake;
        if (s > 0f) {
            float t = Juice.shakeSeed;
            e.setYaw(e.getYaw() + (float) Math.sin(t * 2.1) * s * 1.6f);
            e.setPitch(e.getPitch() + (float) Math.cos(t * 2.7) * s * 1.2f + Juice.kickPitch);
            e.setRoll(e.getRoll() + (float) Math.sin(t * 3.3) * s * 1.4f);
        } else if (Juice.kickPitch != 0f) e.setPitch(e.getPitch() + Juice.kickPitch);
    }

    @SubscribeEvent
    public static void fov(ViewportEvent.ComputeFov e) {
        double extra = Juice.fov;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null && mc.level.getGameTime() < ClientState.flowUntil) extra += 3.0;
        if (extra != 0) e.setFOV(e.getFOV() + extra);
    }

    // ---------- player scale from the creator (height / build) ----------
    @SubscribeEvent
    public static void playerPre(RenderPlayerEvent.Pre e) {
        java.util.UUID id = e.getEntity().getUUID();
        Minecraft mc = Minecraft.getInstance();
        CharacterProfile pr = e.getEntity() == mc.player && ClientState.preview != null ? ClientState.preview : ClientState.PROFILES.get(id);
        if (pr == null || (ClientState.MODES.getOrDefault(id, 0) == 0 && ClientState.preview == null)) return;
        float h = Mth.clamp(pr.height, 0.85f, 1.15f);
        int age = ClientState.AGES.getOrDefault(id, 15);
        h *= age <= 12 ? 0.8f : (age <= 15 ? 1f : 1.04f);
        float w = h * (pr.build.equals("slim") ? 0.95f : (pr.build.equals("heavy") ? 1.1f : 1f));
        e.getPoseStack().pushPose();
        e.getPoseStack().scale(w, h, w);
    }

    @SubscribeEvent
    public static void playerPost(RenderPlayerEvent.Post e) {
        java.util.UUID id = e.getEntity().getUUID();
        Minecraft mc = Minecraft.getInstance();
        CharacterProfile pr = e.getEntity() == mc.player && ClientState.preview != null ? ClientState.preview : ClientState.PROFILES.get(id);
        if (pr == null || (ClientState.MODES.getOrDefault(id, 0) == 0 && ClientState.preview == null)) return;
        e.getPoseStack().popPose();
    }

    // ---------- world overlays: stroke ghost, forming preview, damage numbers ----------
    @SubscribeEvent
    public static void world(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        PoseStack ps = e.getPoseStack();
        Camera cam = e.getCamera();
        Vec3 c = cam.getPosition();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        float pt = e.getPartialTick();

        if (charging && !stroke.isEmpty()) {
            ps.pushPose();
            ps.translate(-c.x, -c.y, -c.z);
            for (Vec3 v : stroke) LevelRenderer.renderLineBox(ps, buf.getBuffer(RenderType.lines()), new AABB(v.x - 0.5, v.y, v.z - 0.5, v.x + 0.5, v.y + 1, v.z + 0.5).deflate(0.35), 0.5f, 0.85f, 1f, 1f);
            ps.popPose();
            buf.endBatch(RenderType.lines());
        }
        if (charging && !currentSpec().stroke && currentSpec().behavior != ShapeSpec.Behavior.PLACE) { // the shape forms in front of the hands while you charge
            ShapeSpec s = currentSpec();
            float clarity = Mth.clamp(held / 16f, 0.2f, 1f);
            Vec3 look = mc.player.getLookAngle();
            Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
            Vec3 pos = mc.player.getEyePosition(pt).add(look.scale(1.1)).add(right.scale(0.35)).add(0, -0.45, 0);
            ps.pushPose();
            ps.translate(pos.x - c.x, pos.y - c.y, pos.z - c.z);
            ps.mulPose(Axis.YP.rotationDegrees(-mc.player.getViewYRot(pt)));
            ps.mulPose(Axis.XP.rotationDegrees(mc.player.getViewXRot(pt)));
            boolean centred = s.prim == ShapeSpec.Prim.SPHERE || s.prim == ShapeSpec.Prim.DISC || s.prim == ShapeSpec.Prim.WALL;
            if (!centred) ps.translate(0, 0, -s.length * 0.4 * clarity);
            IceRender.draw(s, ps, buf, 15728880, 0.25f + 0.75f * clarity, 0.8f, 0.93f, 1f, 0.25f + 0.4f * clarity);
            ps.popPose();
            buf.endBatch();
        }
        if (!ClientState.NUMBERS.isEmpty()) {
            for (ClientState.Number n : ClientState.NUMBERS) {
                float t = n.age + pt;
                ps.pushPose();
                ps.translate(n.x - c.x, n.y + t * 0.035 - c.y, n.z - c.z);
                ps.mulPose(cam.rotation());
                float sc = (n.big ? 0.05f : 0.035f) * (1f + Math.max(0, 6 - t) * 0.08f);
                ps.scale(-sc, -sc, sc);
                String txt = String.valueOf(Math.round(n.value));
                int alpha = (int) (255 * Mth.clamp(1.0 - (t - 16) / 10.0, 0.0, 1.0));
                mc.font.drawInBatch(txt, -mc.font.width(txt) / 2f, 0, (alpha << 24) | n.color, false, ps.last().pose(), buf, net.minecraft.client.gui.Font.DisplayMode.SEE_THROUGH, 0, 15728880);
                ps.popPose();
            }
            buf.endBatch();
        }
        RenderSystem.enableDepthTest();
    }

    static boolean unused(GuiGraphics g, BlockPos p) { return g == null; }
}
