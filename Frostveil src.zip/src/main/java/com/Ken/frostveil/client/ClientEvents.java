package com.Ken.frostveil.client;

import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.energy.EnergyAction;
import com.Ken.frostveil.network.ActionPacket;
import com.Ken.frostveil.network.FrostveilNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Turns key presses into intents for the server. Hold keys send on press and on release; C is tap (Cutoff) or hold (Shroud). */
@Mod.EventBusSubscriber(modid = Frostveil.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private static final int HOLD_TICKS = 10; // C held this long = Shroud, shorter = Cutoff
    private static boolean forge, infuse, focus, shroudSent;
    private static int cTicks;

    private ClientEvents() {}

    private static void send(EnergyAction a, boolean s) { FrostveilNetwork.sendToServer(new ActionPacket(a, s)); }

    private static boolean edge(boolean prev, boolean now, EnergyAction a) {
        if (now != prev) send(a, now);
        return now;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        boolean active = mc.player != null && mc.screen == null;

        if (active) {
            while (ModKeys.SKIN_SENSE.consumeClick()) send(EnergyAction.SKIN_SENSE_TOGGLE, true);
            while (ModKeys.DODGE.consumeClick()) send(EnergyAction.DODGE, true);
            while (ModKeys.FORGE_LIMB.consumeClick()) send(EnergyAction.FORGE_LIMB, true);
        }
        forge = edge(forge, active && ModKeys.FORGE.isDown(), EnergyAction.FORGE);
        infuse = edge(infuse, active && ModKeys.INFUSE.isDown(), EnergyAction.INFUSE);
        focus = edge(focus, active && ModKeys.FOCUS.isDown(), EnergyAction.FOCUS_HOLD);

        boolean c = active && ModKeys.CUTOFF.isDown();
        if (c) {
            if (++cTicks == HOLD_TICKS) { send(EnergyAction.SHROUD, true); shroudSent = true; }
        } else {
            if (shroudSent) send(EnergyAction.SHROUD, false);
            else if (cTicks > 0) send(EnergyAction.CUTOFF_TAP, true);
            cTicks = 0;
            shroudSent = false;
        }
    }
}
