package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.client.ClientState;
import com.Ken.frostveil.network.FvNet;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;

/** Mission journal. Scroll the list with the mouse wheel; the Skip button sits in its own spot so nothing overlaps it. */
public class JournalScreen extends Screen {
    private final List<CompoundTag> entries = new ArrayList<>();
    private final Scroller sc = new Scroller();
    private int selected = 0;

    public JournalScreen() { super(Component.literal("Journal")); load(); }

    private void load() {
        entries.clear();
        ListTag l = ClientState.journal.getList("list", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) entries.add(l.getCompound(i));
        entries.sort((a, b) -> Integer.compare(rank(a.getString("status")), rank(b.getString("status"))));
        if (selected >= entries.size()) selected = 0;
    }

    public void refresh() { load(); if (minecraft != null) rebuildWidgets(); }

    private static int rank(String s) { return switch (s) { case "active" -> 0; case "ready" -> 1; case "locked" -> 2; case "done" -> 4; default -> 3; }; }

    @Override
    protected void init() {
        sc.clear();
        for (int i = 0; i < entries.size(); i++) {
            final int sel = i;
            CompoundTag e = entries.get(i);
            String mark = switch (e.getString("status")) { case "active" -> "> "; case "done" -> "v "; case "locked" -> "x "; case "coming" -> "~ "; default -> "* "; };
            Button b = Button.builder(Component.literal(mark + e.getString("title")), x -> selected = sel).bounds(20, 40 + i * 22, 200, 20).build();
            sc.add(b, 40 + i * 22);
            addRenderableWidget(b);
        }
        sc.bounds(40, height - 46, 40 + entries.size() * 22);
        addRenderableWidget(Button.builder(Component.literal("Skip current objective (if stuck)"), b -> FvNet.toServer(new FvNet.ActionMsg("skip_obj"))).bounds(250, height - 30, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose()).bounds(20, height - 30, 80, 20).build());
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) { return sc.wheel(delta) || super.mouseScrolled(x, y, delta); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xE00A1220, 0xE018304A);
        g.drawString(font, "Journal  (mouse wheel scrolls)", 20, 14, 0xFFDDF1FF, false);
        sc.bar(g, 224);
        if (!entries.isEmpty()) {
            CompoundTag e = entries.get(selected);
            int x = 250, wd = width - x - 20;
            g.drawString(font, e.getString("title"), x, 40, 0xFFFFFFFF, false);
            String st = e.getString("status");
            g.drawString(font, "Arc " + e.getInt("arc") + "  -  " + st.toUpperCase(), x, 54, 0xFF8FB4D6, false);
            g.drawWordWrap(font, Component.literal(e.getString("desc")), x, 74, wd, 0xFFD8E6F2);
            int y = 74 + font.wordWrapHeight(e.getString("desc"), wd) + 10;
            if (st.equals("active")) g.drawWordWrap(font, Component.literal("Objective: " + e.getString("obj")), x, y, wd, 0xFF9ED0FF);
            if (st.equals("locked")) g.drawWordWrap(font, Component.literal("Requires: " + e.getString("hint")), x, y, wd, 0xFFFFC38A);
            if (st.equals("ready")) g.drawString(font, "Ready: it starts on its own.", x, y, 0xFF9AE0A8, false);
            if (st.equals("coming")) g.drawString(font, "Coming in a later version.", x, y, 0xFF9AA5B0, false);
        }
        super.render(g, mx, my, pt);
    }
}
