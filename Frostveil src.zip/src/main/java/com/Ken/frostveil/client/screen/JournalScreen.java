package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.client.ClientState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;

/** Mission journal: active, ready, locked (with a hint about what is required: place, mission, flag) and finished missions. */
public class JournalScreen extends Screen {
    private final List<CompoundTag> entries = new ArrayList<>();
    private int selected = 0, scroll = 0;

    public JournalScreen() { super(Component.literal("Journal")); refresh(); }

    public void refresh() {
        entries.clear();
        ListTag l = ClientState.journal.getList("list", Tag.TAG_COMPOUND);
        for (int i = 0; i < l.size(); i++) entries.add(l.getCompound(i));
        entries.sort((a, b) -> Integer.compare(rank(a.getString("status")), rank(b.getString("status"))));
        if (selected >= entries.size()) selected = 0;
        if (minecraft != null) rebuildWidgets();
    }

    private static int rank(String s) { return switch (s) { case "active" -> 0; case "ready" -> 1; case "locked" -> 2; case "done" -> 4; default -> 3; }; }

    @Override
    protected void init() {
        for (int i = 0; i < 12; i++) {
            int idx = scroll + i;
            if (idx >= entries.size()) break;
            final int sel = idx;
            CompoundTag e = entries.get(idx);
            String mark = switch (e.getString("status")) { case "active" -> "> "; case "done" -> "v "; case "locked" -> "x "; case "coming" -> "~ "; default -> "* "; };
            Button b = Button.builder(Component.literal(mark + e.getString("title")), x -> selected = sel).bounds(20, 40 + i * 22, 190, 20).build();
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("^"), b -> { scroll = Math.max(0, scroll - 4); rebuildWidgets(); }).bounds(212, 40, 18, 20).build());
        addRenderableWidget(Button.builder(Component.literal("v"), b -> { scroll = Math.min(Math.max(0, entries.size() - 12), scroll + 4); rebuildWidgets(); }).bounds(212, 62, 18, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xE00A1220, 0xE018304A);
        g.drawString(font, "Journal", 20, 14, 0xFFDDF1FF, false);
        if (!entries.isEmpty()) {
            CompoundTag e = entries.get(selected);
            int x = 250;
            g.drawString(font, e.getString("title"), x, 40, 0xFFFFFFFF, false);
            String st = e.getString("status");
            g.drawString(font, "Arc " + e.getInt("arc") + "  -  " + st.toUpperCase(), x, 54, 0xFF8FB4D6, false);
            g.drawWordWrap(font, Component.literal(e.getString("desc")), x, 74, width - x - 20, 0xFFD8E6F2);
            int y = 74 + font.wordWrapHeight(e.getString("desc"), width - x - 20) + 10;
            if (st.equals("active")) g.drawWordWrap(font, Component.literal("Objective: " + e.getString("obj")), x, y, width - x - 20, 0xFF9ED0FF);
            if (st.equals("locked")) g.drawWordWrap(font, Component.literal("Requires: " + e.getString("hint")), x, y, width - x - 20, 0xFFFFC38A);
            if (st.equals("ready")) g.drawString(font, "Ready: it starts on its own when you are near.", x, y, 0xFF9AE0A8, false);
            if (st.equals("coming")) g.drawString(font, "Coming in a later version.", x, y, 0xFF9AA5B0, false);
        }
        super.render(g, mx, my, pt);
    }
}
