package com.Ken.frostveil.eiu;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;

/** Visual identity of each EIU element: tint colour and a signature particle. Ice is the story element. */
public final class Element {
    private Element() {}

    public static int color(String element) {
        return switch (element) {
            case "fire" -> 0xFF8A3D;
            case "wind" -> 0xBFE8D8;
            case "lightning" -> 0xFFE45C;
            case "earth" -> 0xA8845A;
            case "water" -> 0x4F9BFF;
            default -> 0xA8D8FF;
        };
    }

    public static ParticleOptions particle(String element) {
        return switch (element) {
            case "fire" -> ParticleTypes.FLAME;
            case "wind" -> ParticleTypes.CLOUD;
            case "lightning" -> ParticleTypes.ELECTRIC_SPARK;
            case "earth" -> ParticleTypes.CRIT;
            case "water" -> ParticleTypes.SPLASH;
            default -> ParticleTypes.SNOWFLAKE;
        };
    }

    public static boolean valid(String e) {
        return switch (e) {
            case "ice", "fire", "wind", "lightning", "earth", "water" -> true;
            default -> false;
        };
    }
}
