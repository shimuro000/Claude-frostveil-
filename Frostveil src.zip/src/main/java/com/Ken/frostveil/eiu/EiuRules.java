package com.Ken.frostveil.eiu;

import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;

/** The lore laws as small pure functions: element interactions (D7), environment (Law 4), cost (Law 3). */
public final class EiuRules {
    public enum Relation { NEUTRAL, BOOST, CONFLICT, PIERCES, DANGEROUS_BOOST, PARTIAL_CONFLICT }

    private static final Map<String, Map<String, Relation>> RELATIONS = Map.of(
            "ice", Map.of("fire", Relation.CONFLICT, "wind", Relation.BOOST, "lightning", Relation.NEUTRAL, "earth", Relation.NEUTRAL, "water", Relation.BOOST),
            "fire", Map.of("ice", Relation.CONFLICT, "wind", Relation.BOOST, "lightning", Relation.BOOST, "earth", Relation.NEUTRAL, "water", Relation.CONFLICT),
            "wind", Map.of("ice", Relation.BOOST, "fire", Relation.BOOST, "lightning", Relation.BOOST, "earth", Relation.NEUTRAL, "water", Relation.BOOST),
            "lightning", Map.of("ice", Relation.NEUTRAL, "fire", Relation.BOOST, "wind", Relation.BOOST, "earth", Relation.PIERCES, "water", Relation.DANGEROUS_BOOST),
            "earth", Map.of("ice", Relation.NEUTRAL, "fire", Relation.NEUTRAL, "wind", Relation.NEUTRAL, "lightning", Relation.PIERCES, "water", Relation.PARTIAL_CONFLICT),
            "water", Map.of("ice", Relation.BOOST, "fire", Relation.CONFLICT, "wind", Relation.BOOST, "lightning", Relation.DANGEROUS_BOOST, "earth", Relation.PARTIAL_CONFLICT));

    private EiuRules() {}

    public static Relation relation(String a, String b) {
        if (a == null || b == null || a.equals(b)) return Relation.NEUTRAL;
        return RELATIONS.getOrDefault(a, Map.of()).getOrDefault(b, Relation.NEUTRAL);
    }

    /** Law 3: cost = base x density x environment x (1 - efficiency). */
    public static float cost(float base, float density, float environment, float efficiency) {
        if (!Float.isFinite(base) || base <= 0) return 0;
        float waste = 1f - Mth.clamp(efficiency, 0f, 0.8f);
        return Math.max(0.1f, base * Mth.clamp(density, 0.5f, 3f) * Mth.clamp(environment, 0.5f, 2.5f) * waste);
    }

    /** Law 4: ice is cheaper in snow, cold, water and rain; dearer in heat. */
    public static float environmentCost(String element, Level level, BlockPos pos) {
        Biome biome = level.getBiome(pos).value();
        float temp = biome.getBaseTemperature();
        boolean wet = level.isRainingAt(pos);
        boolean water = level.getFluidState(pos).is(FluidTags.WATER) || level.getFluidState(pos.below()).is(FluidTags.WATER);
        boolean snowGround = level.getBlockState(pos.below()).is(BlockTags.SNOW) || level.getBlockState(pos).is(Blocks.SNOW)
                || level.getBlockState(pos.below()).is(Blocks.ICE) || level.getBlockState(pos.below()).is(Blocks.PACKED_ICE);
        if ("ice".equals(element)) {
            if (temp <= 0.15f || snowGround) return 0.65f;
            if (water || wet) return 0.78f;
            if (temp >= 1.2f) return 1.45f;
        } else if ("fire".equals(element)) {
            if (temp >= 1.2f) return 0.8f;
            if (water || wet) return 1.3f;
        }
        return 1f;
    }

    /** Wind loses range indoors; lightning reaches further over water. */
    public static float rangeFactor(String element, Level level, BlockPos pos) {
        if ("wind".equals(element) && !level.canSeeSky(pos)) return 0.65f;
        if ("lightning".equals(element) && level.getFluidState(pos).is(FluidTags.WATER)) return 2f;
        return 1f;
    }

    /** Technique clash: density x level x element relation (D7). Higher wins. */
    public static float clashScore(String attacker, String defender, float density, float environment, int control) {
        float rel = switch (relation(attacker, defender)) {
            case BOOST, PIERCES -> 1.15f;
            case DANGEROUS_BOOST -> 1.35f;
            case CONFLICT, PARTIAL_CONFLICT -> 0.9f;
            default -> 1f;
        };
        return Mth.clamp(density, 0.5f, 3f) * Mth.clamp(environment, 0.5f, 2.5f) * (1f + Mth.clamp(control, 0, 10) * 0.04f) * rel;
    }
}
