package com.Ken.frostveil.eiu;

import com.Ken.frostveil.data.FvData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/**
 * Learn by doing. Every activity has a counter; when it reaches its threshold you gain a small permanent boost
 * (e.g. 10 ice techniques: +1 EIU Power and +1 EIU Pool). Each gain in the same activity needs a bit more than the last.
 */
public final class Training {
    private record Rule(String key, int base, String[] gains, String label) {}

    private static final Rule[] RULES = {
            new Rule("cast", 10, new String[]{"output", "quantity"}, "+1 EIU Power, +1 EIU Pool"),
            new Rule("stroke", 15, new String[]{"ctrlExternal"}, "+1 External Control (longer reach)"),
            new Rule("hits", 25, new String[]{"strength"}, "+1 Strength"),
            new Rule("dodge", 12, new String[]{"speed"}, "+1 Speed"),
            new Rule("parry", 8, new String[]{"perception"}, "+1 Perception"),
            new Rule("sense", 90, new String[]{"perception"}, "+1 Perception"),
            new Rule("forge", 80, new String[]{"bodyLimit"}, "+1 Body Limit"),
            new Rule("sprint", 200, new String[]{"endurance"}, "+1 Endurance"),
            new Rule("med", 100, new String[]{"ctrlMental"}, "+1 Mental Control")};

    private Training() {}

    public static void add(ServerPlayer p, FvData d, String key, int n) {
        for (Rule r : RULES) {
            if (!r.key().equals(key)) continue;
            int c = d.train.merge(key, n, Integer::sum);
            int gains = d.train.getOrDefault("g_" + key, 0);
            int need = r.base() + gains * r.base() / 2;
            if (c < need) return;
            d.train.put(key, 0);
            d.train.put("g_" + key, gains + 1);
            for (String g : r.gains()) {
                switch (g) {
                    case "output" -> d.output += 1;
                    case "quantity" -> { d.quantity += 1; d.aura += 1; }
                    case "strength" -> d.strength += 1;
                    case "speed" -> d.speed += 1;
                    case "perception" -> d.perception += 1;
                    case "bodyLimit" -> d.bodyLimit += 1;
                    case "endurance" -> d.endurance += 1;
                    case "ctrlMental" -> d.ctrlMental = Math.min(10, d.ctrlMental + 1);
                    case "ctrlExternal" -> d.ctrlExternal = Math.min(10, d.ctrlExternal + 1);
                    default -> { }
                }
            }
            ServerActions.msg(p, "Training: " + r.label());
            com.Ken.frostveil.network.FvNet.toPlayer(p, new com.Ken.frostveil.network.FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY(), (float) p.getZ(), 0.5f, "ice", 8, 0f));
            p.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.5f, 1.3f);
            d.mark();
            return;
        }
    }
}
