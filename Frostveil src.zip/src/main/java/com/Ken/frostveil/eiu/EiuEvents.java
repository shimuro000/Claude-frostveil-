package com.Ken.frostveil.eiu;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.IceShaping;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModEffects;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The per-tick EIU engine: regeneration, sustained drains (Law 7), exhaustion (Law 2), Focus (Law 5), Flow, Forge strain, sync. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class EiuEvents {
    private static final Map<UUID, PublicState> LAST = new java.util.HashMap<>();

    private EiuEvents() {}

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        float eff = 1f - d.efficiency;

        double mdx = p.getX() - d.lastX, mdz = p.getZ() - d.lastZ;
        d.lastX = p.getX(); d.lastZ = p.getZ();
        boolean still = mdx * mdx + mdz * mdz < 0.0009;
        boolean meditating = p.getPersistentData().getBoolean("fv_meditating");
        if (meditating && !still) p.getPersistentData().putBoolean("fv_meditating", false);

        // --- sustained drains (ending a technique stops its drain at once) ---
        float drain = 0f;
        if (d.skinSenseOn) drain += 0.012f;
        if (d.forgeLimb != 0) drain += 0.06f;
        if (d.shroudOn) drain += 0.01f;
        if (d.heldConstruct >= 0) {
            Entity held = level.getEntity(d.heldConstruct);
            if (held instanceof IceConstructEntity) drain += 0.02f; else d.heldConstruct = -1;
        }
        if (d.infuseTicks > 0) {
            d.infuseTicks--;
            if (p.tickCount % 12 == 0) level.sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1.1, p.getZ(), 2, 0.3, 0.3, 0.3, 0.01);
            if (d.infuseTicks == 0) { ServerActions.msg(p, "The frost fades from your hands."); d.mark(); }
        }
        d.aura = Math.max(0f, d.aura - drain * eff);
        if (d.aura <= 0f && drain > 0f) { d.skinSenseOn = false; d.forgeLimb = 0; d.shroudOn = false; d.mark(); }

        // --- regeneration (Law 8) ---
        if (now - d.lastCast > 40 && d.aura < d.quantity) {
            float regen = d.quantity * 0.0007f;
            if (still) regen *= 1.8f;
            if (meditating) regen *= 3f;
            if (p.isSleeping()) regen *= 6f;
            d.aura = Math.min(d.quantity, d.aura + regen);
        }
        // --- Focus ---
        if (now - d.lastHurt > 60 && d.focus < 100) d.focus = Math.min(100f, d.focus + (meditating ? 0.8f : 0.25f));

        // --- Law 2: low aura weakens the body ---
        if (d.aura < d.quantity * 0.1f && p.tickCount % 20 == 0) {
            p.addEffect(new MobEffectInstance(ModEffects.EXHAUSTION.get(), 80, 0, false, false, true));
            if (d.aura < 1f) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0, false, false));
        }

        // --- Flow: triggered by the game, never by a key ---
        if (now >= d.flowUntil && d.flow >= 100f && d.focus >= 60f) {
            d.flowUntil = now + 200;
            d.flow = 0f;
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0, false, false));
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), t -> t != p && !(t instanceof Player))) {
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1, false, false)); // time seems slower for you
            }
            FvNet.toPlayer(p, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY(), (float) p.getZ(), 1f, d.element, 6, 0));
            ServerActions.msg(p, "Everything slows. You feel the shape before you make it.");
            com.Ken.frostveil.story.MissionManager.event(p, "flow", "");
            d.mark();
        } else if (d.flow > 0f && now - d.lastHurt > 100 && p.tickCount % 10 == 0) {
            d.flow = Math.max(0f, d.flow - 0.5f);
        }
        if (d.flowUntil == now) { // the moment Flow ends
            if (d.forgeLimb != 0) p.addEffect(new MobEffectInstance(ModEffects.EXHAUSTION.get(), 200, 0));
        }

        IceShaping.tickHalo(p, d);
        if (p.tickCount % 20 == 0) { // learning by doing
            if (d.skinSenseOn) Training.add(p, d, "sense", 1);
            if (d.forgeLimb != 0) Training.add(p, d, "forge", 1);
            if (p.isSprinting()) Training.add(p, d, "sprint", 1);
            if (meditating) Training.add(p, d, "med", 1);
        }
        if (p.tickCount % 40 == 0) applyStats(p, d);
        if (p.tickCount % 20 == 0) { // the Ash Knights' armor is cursed
            int worn = 0;
            for (net.minecraft.world.entity.EquipmentSlot sl : new net.minecraft.world.entity.EquipmentSlot[]{net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.entity.EquipmentSlot.CHEST, net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET})
                if (p.getItemBySlot(sl).getItem() instanceof com.Ken.frostveil.item.AshArmorItem) worn++;
            if (worn > 0) {
                if (!p.hasEffect(ModEffects.ASH_CURSE.get())) ServerActions.msg(p, "The ash clings to your core. The armor is cursed.");
                p.addEffect(new MobEffectInstance(ModEffects.ASH_CURSE.get(), 100, worn - 1, true, true));
                d.aura = Math.max(0f, d.aura - 0.6f * worn);
                level.sendParticles(ParticleTypes.ASH, p.getX(), p.getY() + 1.2, p.getZ(), 4, 0.3, 0.5, 0.3, 0.01);
            }
        }
        lantern(p, level);
        if (p.tickCount % 6000 == 3000) com.Ken.frostveil.world.Population.ensure(level);

        // --- sync ---
        if (p.tickCount % 5 == 0) {
            PublicState ps = PublicState.of(d, now);
            PublicState old = LAST.get(p.getUUID());
            if (!ps.equals(old)) {
                LAST.put(p.getUUID(), ps);
                FvNet.toTracking(p, new FvNet.PublicStateMsg(p.getUUID(), ps));
            }
        }
        if (d.dirty && p.tickCount % 2 == 0) FvNet.syncData(p);
    }

    private static final java.util.UUID SPEED_ID = java.util.UUID.fromString("7d1b2a40-0c11-4f6d-9a71-3c0d5e9b0a01");
    private static final java.util.UUID HP_ID = java.util.UUID.fromString("7d1b2a40-0c11-4f6d-9a71-3c0d5e9b0a02");

    /** Speed and Endurance are real: they change walking speed and maximum health. */
    private static void applyStats(ServerPlayer p, FvData d) {
        var sp = p.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED);
        if (sp != null) { sp.removeModifier(SPEED_ID); sp.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(SPEED_ID, "fv_speed", Math.max(0, d.speed - 6) * 0.012, net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.MULTIPLY_TOTAL)); }
        var hp = p.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH);
        if (hp != null) {
            double bonus = Math.max(0, d.endurance - 6);
            hp.removeModifier(HP_ID);
            if (bonus > 0) hp.addTransientModifier(new net.minecraft.world.entity.ai.attributes.AttributeModifier(HP_ID, "fv_endurance", bonus, net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation.ADDITION));
        }
    }

    /** A worn Lantern Backpack lights the way: an invisible light block follows your head (toggle with Y). */
    private static void lantern(ServerPlayer p, ServerLevel level) {
        if (p.tickCount % 4 != 0) return;
        boolean worn = p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST).is(com.Ken.frostveil.registry.ModItems.LANTERN_BACKPACK.get()) && !p.getPersistentData().getBoolean("fv_lantern_off");
        long prev = p.getPersistentData().getLong("fv_light");
        net.minecraft.core.BlockPos now = worn ? net.minecraft.core.BlockPos.containing(p.getX(), p.getEyeY() + 0.6, p.getZ()) : null;
        if (prev != 0 && (now == null || now.asLong() != prev)) {
            net.minecraft.core.BlockPos old = net.minecraft.core.BlockPos.of(prev);
            if (level.getBlockState(old).is(net.minecraft.world.level.block.Blocks.LIGHT)) level.setBlock(old, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
            p.getPersistentData().putLong("fv_light", 0);
        }
        if (now != null && level.getBlockState(now).isAir()) {
            level.setBlock(now, net.minecraft.world.level.block.Blocks.LIGHT.defaultBlockState().setValue(net.minecraft.world.level.block.LightBlock.LEVEL, 13), 3);
            p.getPersistentData().putLong("fv_light", now.asLong());
        }
    }

    @SubscribeEvent
    public static void logout(net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && p.level() instanceof ServerLevel level) {
            long prev = p.getPersistentData().getLong("fv_light");
            if (prev != 0 && level.getBlockState(net.minecraft.core.BlockPos.of(prev)).is(net.minecraft.world.level.block.Blocks.LIGHT)) level.setBlock(net.minecraft.core.BlockPos.of(prev), net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), 3);
            p.getPersistentData().putLong("fv_light", 0);
        }
    }

    @SubscribeEvent
    public static void wake(PlayerWakeUpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        d.fatigue = 0f; // sleeping in a bed resets daily training fatigue (Law 8)
        d.aura = d.quantity;
        d.focus = 100f;
        d.mark();
    }

    /** Height from the character creator and age stage (12 y.o. is about 0.8 of the adult model). */
    @SubscribeEvent
    public static void size(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof Player p)) return;
        float s = p.level().isClientSide ? FvCap.CLIENT_SCALE.apply(p.getUUID()) : FvCap.get(p).profile.effectiveScale(FvCap.get(p).ageStage);
        if (!FvCap.get(p).active() && !p.level().isClientSide) return;
        if (Math.abs(s - 1f) < 0.001f) return;
        EntityDimensions old = e.getNewSize();
        e.setNewSize(old.scale(s));
        e.setNewEyeHeight(e.getNewEyeHeight() * s);
    }
}
