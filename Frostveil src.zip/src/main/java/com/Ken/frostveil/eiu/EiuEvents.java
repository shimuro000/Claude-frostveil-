package com.Ken.frostveil.eiu;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.IceShaping;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModEffects;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The per-tick EIU engine: regeneration, sustained drains (Law 7), exhaustion (Law 2), Focus (Law 5), Flow, Forge strain, sync. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class EiuEvents {
    private static final Map<UUID, PublicState> LAST = new java.util.HashMap<>();

    private EiuEvents() {}

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        float eff = 1f - d.efficiency;

        boolean still = p.getDeltaMovement().horizontalDistanceSqr() < 0.0004;
        boolean meditating = p.getPersistentData().getBoolean("fv_meditating");
        if (meditating && !still) p.getPersistentData().putBoolean("fv_meditating", false);

        // --- sustained drains (ending a technique stops its drain at once) ---
        float drain = 0f;
        if (d.skinSenseOn) drain += 0.012f;
        if (d.forgeLimb != 0) drain += 0.06f;
        if (d.shroudOn) drain += 0.01f;
        if (d.heldConstruct >= 0) {
            Entity held = level.getEntity(d.heldConstruct);
            if (held instanceof IceConstructEntity) drain += 0.02f; else d.heldConstruct = -1;
        }
        if (d.infuseTicks > 0) {
            d.infuseTicks--;
            if (p.tickCount % 12 == 0) level.sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1.1, p.getZ(), 2, 0.3, 0.3, 0.3, 0.01);
            if (d.infuseTicks == 0) { ServerActions.msg(p, "The frost fades from your hands."); d.mark(); }
        }
        d.aura = Math.max(0f, d.aura - drain * eff);
        if (d.aura <= 0f && drain > 0f) { d.skinSenseOn = false; d.forgeLimb = 0; d.shroudOn = false; d.mark(); }

        // --- regeneration (Law 8) ---
        if (now - d.lastCast > 40 && d.aura < d.quantity) {
            float regen = d.quantity * 0.0007f;
            if (still) regen *= 1.8f;
            if (meditating) regen *= 3f;
            if (p.isSleeping()) regen *= 6f;
            d.aura = Math.min(d.quantity, d.aura + regen);
        }
        // --- Focus ---
        if (now - d.lastHurt > 60 && d.focus < 100) d.focus = Math.min(100f, d.focus + (meditating ? 0.8f : 0.25f));

        // --- Law 2: low aura weakens the body ---
        if (d.aura < d.quantity * 0.1f && p.tickCount % 20 == 0) {
            p.addEffect(new MobEffectInstance(ModEffects.EXHAUSTION.get(), 80, 0, false, false, true));
            if (d.aura < 1f) p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 0, false, false));
        }

        // --- Flow: triggered by the game, never by a key ---
        if (now >= d.flowUntil && d.flow >= 100f && d.focus >= 60f) {
            d.flowUntil = now + 200;
            d.flow = 0f;
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0, false, false));
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14), t -> t != p && !(t instanceof Player))) {
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1, false, false)); // time seems slower for you
            }
            FvNet.toPlayer(p, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY(), (float) p.getZ(), 1f, d.element, 6, 0));
            ServerActions.msg(p, "Everything slows. You feel the shape before you make it.");
            com.Ken.frostveil.story.MissionManager.event(p, "flow", "");
            d.mark();
        } else if (d.flow > 0f && now - d.lastHurt > 100 && p.tickCount % 10 == 0) {
            d.flow = Math.max(0f, d.flow - 0.5f);
        }
        if (d.flowUntil == now) { // the moment Flow ends
            if (d.forgeLimb != 0) p.addEffect(new MobEffectInstance(ModEffects.EXHAUSTION.get(), 200, 0));
        }

        IceShaping.tickHalo(p, d);

        // --- sync ---
        if (p.tickCount % 5 == 0) {
            PublicState ps = PublicState.of(d, now);
            PublicState old = LAST.get(p.getUUID());
            if (!ps.equals(old)) {
                LAST.put(p.getUUID(), ps);
                FvNet.toTracking(p, new FvNet.PublicStateMsg(p.getUUID(), ps));
            }
        }
        if (d.dirty && p.tickCount % 2 == 0) FvNet.syncData(p);
    }

    @SubscribeEvent
    public static void wake(PlayerWakeUpEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        d.fatigue = 0f; // sleeping in a bed resets daily training fatigue (Law 8)
        d.aura = d.quantity;
        d.focus = 100f;
        d.mark();
    }

    /** Height from the character creator and age stage (12 y.o. is about 0.8 of the adult model). */
    @SubscribeEvent
    public static void size(EntityEvent.Size e) {
        if (!(e.getEntity() instanceof Player p)) return;
        float s = p.level().isClientSide ? FvCap.CLIENT_SCALE.apply(p.getUUID()) : FvCap.get(p).profile.effectiveScale(FvCap.get(p).ageStage);
        if (!FvCap.get(p).active() && !p.level().isClientSide) return;
        if (Math.abs(s - 1f) < 0.001f) return;
        EntityDimensions old = e.getNewSize();
        e.setNewSize(old.scale(s));
        e.setNewEyeHeight(e.getNewEyeHeight() * s);
    }
}
