package com.Ken.frostveil.eiu;

import com.Ken.frostveil.ice.ShapeSpec;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

/** What each element is called and how it behaves in the studio: names of forms and shapes, damage / speed / cost, effects, sounds. */
public final class ElementInfo {
    private ElementInfo() {}

    public static int index(String el) {
        return switch (el) { case "fire" -> 1; case "earth" -> 2; case "wind" -> 3; case "water" -> 4; case "lightning" -> 5; default -> 0; };
    }

    public static String title(String el) {
        return switch (el) { case "fire" -> "Fire Studio"; case "earth" -> "Earth Studio"; case "wind" -> "Wind Studio"; case "water" -> "Water Studio"; case "lightning" -> "Lightning Studio"; default -> "Ice Studio"; };
    }

    /** form 0 = the shaper, 1 = the field, 2 = the halo */
    public static String form(String el, int f) {
        String[][] n = {
                {"Solid Shaper", "Snowmaker", "Ice Halo"},
                {"Ember Shaper", "Wildfire", "Flame Halo"},
                {"Stone Shaper", "Quake Field", "Pebble Halo"},
                {"Gale Shaper", "Storm Field", "Wind Halo"},
                {"Water Shaper", "Rain Field", "Bubble Halo"},
                {"Bolt Shaper", "Thunder Field", "Spark Halo"}};
        return n[index(el)][Math.max(0, Math.min(2, f))];
    }

    public static String prim(String el, ShapeSpec.Prim p) {
        String[][] n = {
                {"Sphere", "Wall", "Spike", "Shard", "Blade", "Disc", "Lance", "Cluster"},
                {"Fireball", "Flame Wall", "Fire Spike", "Ember", "Flame Blade", "Fire Ring", "Fire Lance", "Meteor Cluster"},
                {"Boulder", "Stone Wall", "Stalagmite", "Pebble", "Stone Blade", "Slab", "Earth Lance", "Rock Cluster"},
                {"Air Orb", "Wind Wall", "Gust Spike", "Cutter", "Wind Blade", "Whirl Ring", "Wind Lance", "Gust Cluster"},
                {"Water Orb", "Wave", "Water Spike", "Droplet", "Water Whip", "Water Ring", "Water Lance", "Bubble Cluster"},
                {"Spark Orb", "Arc Wall", "Bolt Spike", "Spark", "Arc Blade", "Static Ring", "Lightning Lance", "Chain Cluster"}};
        return n[index(el)][p.ordinal()];
    }

    public static String fieldHelp(String el) {
        return switch (el) {
            case "fire" -> "Wildfire: burns enemies standing in it.";
            case "earth" -> "Quake Field: slows enemies and cracks the ground.";
            case "wind" -> "Storm Field: throws enemies up and away.";
            case "water" -> "Rain Field: heals you and allies, slows enemies.";
            case "lightning" -> "Thunder Field: strikes enemies inside it.";
            default -> "Snowmaker: slows enemies, cheaper ice, Skin Sense bonus.";
        };
    }

    public static float damageMul(String el) { return switch (el) { case "fire" -> 1.15f; case "lightning" -> 1.2f; case "earth" -> 1.1f; case "wind" -> 0.85f; case "water" -> 0.9f; default -> 1f; }; }
    public static float speedMul(String el) { return switch (el) { case "lightning" -> 1.5f; case "wind" -> 1.25f; case "earth" -> 0.8f; case "water" -> 0.95f; default -> 1f; }; }
    public static float costMul(String el) { return switch (el) { case "fire" -> 1.1f; case "wind" -> 0.85f; case "lightning" -> 1.15f; default -> 1f; }; }

    public static SoundEvent castSound(String el) {
        return switch (el) {
            case "fire" -> SoundEvents.BLAZE_SHOOT; case "earth" -> SoundEvents.ROOTED_DIRT_BREAK; case "wind" -> SoundEvents.PHANTOM_FLAP;
            case "water" -> SoundEvents.GENERIC_SPLASH; case "lightning" -> SoundEvents.LIGHTNING_BOLT_IMPACT; default -> SoundEvents.AMETHYST_CLUSTER_PLACE;
        };
    }
}
