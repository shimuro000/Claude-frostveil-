package com.Ken.frostveil.energy;

/** Inputs the client may send. The client only sends intent; the server decides (server authoritative). */
public enum EnergyAction {
    SKIN_SENSE_TOGGLE, FORGE, FORGE_LIMB, CUTOFF_TAP, SHROUD, INFUSE, FOCUS_HOLD, DODGE
}
