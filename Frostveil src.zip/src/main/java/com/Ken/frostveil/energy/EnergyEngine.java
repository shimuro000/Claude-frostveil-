package com.Ken.frostveil.energy;

import com.Ken.frostveil.capability.EnergyCapabilityEvents;
import com.Ken.frostveil.capability.PlayerEnergyData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Server-side EIU engine (G7). Enforces: cost = base x density x environment x (1 - efficiency) (Law 3/4),
 * sustained drain that stops the moment a technique ends (Law 7), full-drain penalties (Law 2),
 * Forge body limit (Law 6), focus loss when hit (Law 5), regeneration with sleep bonus (Law 8).
 * The client never decides anything; it sends EnergyAction intents that are validated in handleAction.
 */
public final class EnergyEngine {
    private static final String TAG_UNTIL = "FrostveilInfuseUntil", TAG_STR = "FrostveilInfuse", TAG_ELEM = "FrostveilInfuseElement";

    private EnergyEngine() {}

    public static PlayerEnergyData data(Player p) { return p.getCapability(EnergyCapabilityEvents.ENERGY).orElse(null); }

    private static void msg(ServerPlayer p, String key) { p.displayClientMessage(Component.translatable(key), true); }

    /** Environment factor (Law 4, G7): ice is cheaper in cold, wet places and dearer in heat; fire is the mirror. */
    public static double envFactor(ServerPlayer p, PlayerEnergyData d) {
        Biome biome = p.level().getBiome(p.blockPosition()).value();
        float t = biome.getBaseTemperature();
        boolean wet = p.isInWaterOrRain();
        double f = 1.0;
        if (d.element == Element.ICE) {
            if (t <= 0.15f) f *= 0.8; else if (t >= 1.5f) f *= 1.4;
            if (wet) f *= 0.9;
        } else if (d.element == Element.FIRE) {
            if (t >= 1.5f) f *= 0.8; else if (t <= 0.15f) f *= 1.3;
            if (wet) f *= 1.3;
        }
        // TODO(phase-2): wind indoors loses range, lightning hits water-connected targets harder.
        return f;
    }

    /** Actual aura cost. Flow (G7) drops consumption to a minimum. */
    public static double cost(ServerPlayer p, PlayerEnergyData d, double base, double density) {
        double eff = Math.max(0.0, Math.min(0.9, d.efficiency));
        double flow = d.flowTicks > 0 ? 0.25 : 1.0;
        return base * density * envFactor(p, d) * (1.0 - eff) * flow;
    }

    public static void sync(ServerPlayer p) { EnergyCapabilityEvents.sync(p); }

    private static void shutAll(PlayerEnergyData d) { d.skinSense = d.shroud = d.forgeActive = d.infuseHeld = false; }

    /* ---------------- scripted hooks (story / commands) ---------------- */

    /** First feeling (D5, G8). Story: Shimoro gets it after the Fargas attack. */
    public static void awaken(ServerPlayer p) {
        PlayerEnergyData d = data(p);
        if (d == null || d.awakened) return;
        d.awakened = true;
        msg(p, "frostveil.msg.awakened");
        sync(p);
    }

    /** Flow (G7): scripted/earned only, never selectable. Story: first time in Scarlet's fight. */
    public static void startFlow(ServerPlayer p) {
        PlayerEnergyData d = data(p);
        if (d == null || d.channel != ChannelState.NORMAL) return;
        d.flowTicks = EnergyConfig.FLOW_TICKS.get();
        d.flowCounter = 0;
        sync(p);
    }

    /** Channel state change (Survival Stasis, locks). While not NORMAL no technique works. */
    public static void setChannelState(ServerPlayer p, ChannelState s) {
        PlayerEnergyData d = data(p);
        if (d == null) return;
        d.channel = s;
        if (s != ChannelState.NORMAL) { shutAll(d); d.flowTicks = 0; }
        sync(p);
    }

    /* ---------------- client inputs ---------------- */

    public static void handleAction(ServerPlayer p, EnergyAction a, boolean state) {
        PlayerEnergyData d = data(p);
        if (d == null) return;
        long gt = p.level().getGameTime();

        // Dodge: a short invulnerable step. Aura is only spent if Skin Sense is off and the player is awakened.
        if (a == EnergyAction.DODGE) {
            if (gt < d.dodgeCooldownUntil) return;
            if (d.awakened && d.channel == ChannelState.NORMAL && !d.skinSense) {
                double c = cost(p, d, EnergyConfig.DODGE_COST.get(), 1.0);
                if (d.aura < c) { msg(p, "frostveil.msg.low_aura"); return; }
                d.aura -= c;
            }
            d.dodgeUntil = gt + EnergyConfig.DODGE_INVULN_TICKS.get();
            d.dodgeCooldownUntil = gt + EnergyConfig.DODGE_COOLDOWN_TICKS.get();
            Vec3 look = p.getLookAngle();
            Vec3 back = new Vec3(-look.x, 0, -look.z).normalize().scale(0.8);
            p.setDeltaMovement(p.getDeltaMovement().add(back.x, 0.1, back.z));
            p.hurtMarked = true;
            sync(p);
            return;
        }

        if (a == EnergyAction.FOCUS_HOLD) { d.focusHold = state; return; } // G: meditation / focus steadying

        if (EnergyConfig.REQUIRE_AWAKENING.get() && !d.awakened) { if (state) msg(p, "frostveil.msg.not_awakened"); return; }
        if (d.channel != ChannelState.NORMAL) { if (state) msg(p, "frostveil.msg.channels_closed"); return; }

        switch (a) {
            case SKIN_SENSE_TOGGLE -> {
                if (d.skinSenseStage < 1) { msg(p, "frostveil.msg.unknown_skill"); return; }
                d.skinSense = !d.skinSense;
            }
            case FORGE -> {
                if (d.forgeStage < 1) { if (state) msg(p, "frostveil.msg.unknown_skill"); return; }
                if (state && d.fracturedHandTicks > 0) { msg(p, "frostveil.msg.fractured"); return; }
                d.forgeActive = state;
                if (state) d.shroud = false; // Forge breaks Shroud (D10)
            }
            case FORGE_LIMB -> { if (state) d.forgeLimb = (d.forgeLimb + 1) % 4; }
            case CUTOFF_TAP -> {
                if (d.cutoffStage < 1) { msg(p, "frostveil.msg.unknown_skill"); return; }
                // Cancels every active technique at once. Law 7: released energy is spent, so nothing is refunded yet.
                // TODO(phase-2): refund the share still held by an active technique once techniques exist (section H).
                d.skinSense = d.forgeActive = d.infuseHeld = false;
            }
            case SHROUD -> {
                if (d.cutoffStage < EnergyConfig.SHROUD_MIN_STAGE.get()) { if (state) msg(p, "frostveil.msg.unknown_skill"); return; }
                d.shroud = state;
                if (state) d.forgeActive = d.infuseHeld = false; // any technique breaks Shroud
            }
            case INFUSE -> {
                if (d.infuseStage < 1) { if (state) msg(p, "frostveil.msg.unknown_skill"); return; }
                d.infuseHeld = state && !p.getMainHandItem().isEmpty();
                if (d.infuseHeld) d.shroud = false;
            }
            default -> { }
        }
        sync(p);
    }

    /* ---------------- per-tick server logic ---------------- */

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        PlayerEnergyData d = data(p);
        if (d == null) return;
        boolean changed = false;

        if (d.fracturedHandTicks > 0) d.fracturedHandTicks--;

        if (d.flowTicks > 0 && --d.flowTicks == 0) { // Flow ends with sudden exhaustion
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 0));
            changed = true;
        }

        if (d.channel != ChannelState.NORMAL) {
            if (d.skinSense || d.shroud || d.forgeActive || d.infuseHeld) { shutAll(d); changed = true; }
        } else {
            // Sustained drain (Law 7): per second values, applied per tick.
            double perSec = 0;
            if (d.skinSense) perSec += EnergyConfig.SKIN_SENSE_DRAIN.get();
            if (d.shroud) perSec += EnergyConfig.SHROUD_DRAIN.get();
            if (d.forgeActive) perSec += EnergyConfig.FORGE_DRAIN.get() * (d.forgeLimb == 3 ? 1.5 : 1.0);
            if (d.infuseHeld) perSec += EnergyConfig.INFUSE_DRAIN.get();

            if (perSec > 0) {
                double c = cost(p, d, perSec, 1.0) / 20.0;
                if (c >= d.aura) { // full drain (Law 2): everything stops, the body weakens
                    d.aura = 0;
                    shutAll(d);
                    p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                    msg(p, "frostveil.msg.drained");
                    changed = true;
                } else {
                    d.aura -= c;
                }
            } else if (d.aura < d.quantity) {
                double regen = EnergyConfig.BASE_REGEN.get() * (p.isSleeping() ? 3.0 : 1.0) / 20.0; // Law 8
                d.aura = Math.min(d.quantity, d.aura + regen);
            }

            // Infuse: saturate the held item (D10). Only ice is implemented; TODO(phase-2) other elements.
            if (d.infuseHeld) {
                ItemStack s = p.getMainHandItem();
                if (s.isEmpty()) { d.infuseHeld = false; changed = true; }
                else {
                    long gt = p.level().getGameTime();
                    CompoundTag t = s.getOrCreateTag();
                    float cur = t.getLong(TAG_UNTIL) > gt ? t.getFloat(TAG_STR) : 0f;
                    t.putFloat(TAG_STR, Math.min(1f, cur + 1f / 60f));
                    t.putLong(TAG_UNTIL, gt + 600 + 200L * d.infuseStage); // leaks away after this
                    t.putString(TAG_ELEM, d.element.name());
                }
            }

            // Forge strain vs Body Limit (Law 6): overuse breaks the hand.
            if (d.forgeActive) {
                if (++d.forgeStrain > d.bodyLimit) {
                    d.forgeActive = false;
                    d.forgeStrain = 0;
                    d.fracturedHandTicks = EnergyConfig.FRACTURE_TICKS.get();
                    p.hurt(p.damageSources().generic(), 2.0F);
                    msg(p, "frostveil.msg.forge_overload");
                    changed = true;
                }
            } else if (d.forgeStrain > 0) {
                d.forgeStrain = Math.max(0, d.forgeStrain - 2);
            }
        }

        // Focus (Law 5): regenerates, faster while steadying it standing still (G).
        boolean still = p.onGround() && p.getDeltaMovement().horizontalDistanceSqr() < 1.0E-4;
        boolean meditating = d.focusHold && still;
        if (d.focus < 100) d.focus = Math.min(100, d.focus + EnergyConfig.FOCUS_REGEN.get() * (meditating ? 3.0 : 1.0) / 20.0);

        // First feeling by meditation (D5/G8).
        if (meditating && !d.awakened) {
            if (++d.meditationTicks >= EnergyConfig.MEDITATION_TICKS.get()) { d.awakened = true; msg(p, "frostveil.msg.awakened"); changed = true; }
        } else if (!d.focusHold) {
            d.meditationTicks = 0;
        }

        if (changed || p.tickCount % 10 == 0) sync(p);
    }

    /* ---------------- combat hooks ---------------- */

    /** Victim loses Focus when hit (Law 5, except in Flow). Attacker gains Forge / Infuse effects. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ServerPlayer victim) {
            PlayerEnergyData d = data(victim);
            if (d != null && d.flowTicks <= 0) d.focus = Math.max(0, d.focus - EnergyConfig.FOCUS_HIT_LOSS.get());
        }
        if (e.getSource().getDirectEntity() instanceof ServerPlayer atk && e.getSource().getEntity() == atk) {
            PlayerEnergyData d = data(atk);
            if (d == null || d.channel != ChannelState.NORMAL) return;
            float amount = e.getAmount();
            if (d.forgeActive && d.forgeLimb <= 1 && d.fracturedHandTicks <= 0) {
                amount *= 1.0f + (float) (EnergyConfig.FORGE_BONUS_PER_STAGE.get() * d.forgeStage);
                // TODO(phase-3): legs (speed) and torso (endurance) Forge effects.
            }
            ItemStack held = atk.getMainHandItem();
            CompoundTag t = held.getTag();
            if (t != null && t.getLong(TAG_UNTIL) > atk.level().getGameTime()) {
                float str = t.getFloat(TAG_STR);
                amount += 2.0f * str; // element damage inside the target
                if (Element.byName(t.getString(TAG_ELEM)) == Element.ICE) {
                    e.getEntity().addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, str > 0.5f ? 1 : 0));
                }
            }
            e.setAmount(amount);
        }
    }

    /** Dodge i-frames. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            PlayerEnergyData d = data(p);
            if (d != null && p.level().getGameTime() < d.dodgeUntil) e.setCanceled(true);
        }
    }

    /** A fractured hand cannot punch. */
    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent e) {
        PlayerEnergyData d = data(e.getEntity());
        if (d != null && d.fracturedHandTicks > 0 && e.getEntity().getMainHandItem().isEmpty()) {
            e.setCanceled(true);
            if (e.getEntity() instanceof ServerPlayer sp) msg(sp, "frostveil.msg.fractured");
        }
    }

    /** EIU Shroud: monsters notice the player later (G7). */
    @SubscribeEvent
    public static void onVisibility(LivingEvent.LivingVisibilityEvent e) {
        if (e.getEntity() instanceof Player p) {
            PlayerEnergyData d = data(p);
            if (d != null && d.shroud) e.modifyVisibility(0.35);
        }
    }
}
