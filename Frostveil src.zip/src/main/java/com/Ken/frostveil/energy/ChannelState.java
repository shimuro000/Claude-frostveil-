package com.Ken.frostveil.energy;

/** Channel state (G7): NORMAL, LOCKED (D11) or FORCED_CLOSURE (Survival Stasis, D2). Anything but NORMAL blocks all aura use. */
public enum ChannelState {
    NORMAL, LOCKED, FORCED_CLOSURE;

    public static ChannelState byName(String s) {
        try { return valueOf(s); } catch (IllegalArgumentException e) { return NORMAL; }
    }
}
