package com.Ken.frostveil.energy;

import net.minecraftforge.common.ForgeConfigSpec;

/** [DESIGN] tuning values (G: "defaults stored in a config so the author can tune"). All per second unless noted. */
public final class EnergyConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_AWAKENING;
    public static final ForgeConfigSpec.DoubleValue SKIN_SENSE_DRAIN, SHROUD_DRAIN, FORGE_DRAIN, INFUSE_DRAIN, DODGE_COST;
    public static final ForgeConfigSpec.DoubleValue BASE_REGEN, FOCUS_REGEN, FOCUS_HIT_LOSS, FORGE_BONUS_PER_STAGE;
    public static final ForgeConfigSpec.IntValue FRACTURE_TICKS, FLOW_TICKS, MEDITATION_TICKS, SHROUD_MIN_STAGE, DODGE_INVULN_TICKS, DODGE_COOLDOWN_TICKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("energy");
        REQUIRE_AWAKENING = b.comment("Aura techniques need the first feeling (D5/G8) before they work").define("requireAwakening", true);
        SKIN_SENSE_DRAIN = b.defineInRange("skinSenseDrain", 1.0, 0, 100);
        SHROUD_DRAIN = b.defineInRange("shroudDrain", 1.0, 0, 100);
        FORGE_DRAIN = b.defineInRange("forgeDrain", 3.0, 0, 100);
        INFUSE_DRAIN = b.defineInRange("infuseDrain", 2.0, 0, 100);
        DODGE_COST = b.comment("Aura cost per dodge; free while Skin Sense is on").defineInRange("dodgeCost", 5.0, 0, 100);
        BASE_REGEN = b.comment("Aura regeneration per second (x3 while sleeping, Law 8)").defineInRange("baseRegen", 1.0, 0, 100);
        FOCUS_REGEN = b.defineInRange("focusRegen", 5.0, 0, 100);
        FOCUS_HIT_LOSS = b.comment("Focus lost per hit taken (Law 5)").defineInRange("focusHitLoss", 15.0, 0, 100);
        FORGE_BONUS_PER_STAGE = b.comment("Melee damage bonus per Forge stage while Forge is on an arm").defineInRange("forgeBonusPerStage", 0.4, 0, 10);
        FRACTURE_TICKS = b.comment("How long a fractured hand lasts (ticks)").defineInRange("fractureTicks", 6000, 20, 1000000);
        FLOW_TICKS = b.defineInRange("flowTicks", 600, 20, 100000);
        MEDITATION_TICKS = b.comment("Ticks of still meditation (hold G) for the first feeling").defineInRange("meditationTicks", 200, 20, 100000);
        SHROUD_MIN_STAGE = b.comment("Cutoff stage needed for EIU Shroud (D10: stage 4 hides the outer aura)").defineInRange("shroudMinStage", 4, 1, 5);
        DODGE_INVULN_TICKS = b.defineInRange("dodgeInvulnTicks", 8, 1, 40);
        DODGE_COOLDOWN_TICKS = b.defineInRange("dodgeCooldownTicks", 20, 1, 200);
        b.pop();
        SPEC = b.build();
    }

    private EnergyConfig() {}
}
