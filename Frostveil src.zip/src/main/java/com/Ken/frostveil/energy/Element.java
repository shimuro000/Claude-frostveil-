package com.Ken.frostveil.energy;

/** The six main elements (D6). NONE = not yet decided (Free World before First Training). */
public enum Element {
    NONE, ICE, FIRE, WIND, LIGHTNING, EARTH, WATER;

    public static Element byName(String s) {
        try { return valueOf(s); } catch (IllegalArgumentException e) { return NONE; }
    }
}
