package com.Ken.frostveil.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/**
 * The Lantern Backpack: 27 slots of storage. Shift + right click equips it on your back (chest slot), where it glows and lights the way (Y toggles the lantern).
 * Right click (or the Backpack key, I) opens it. Put the pop-up tent, food, anything in it.
 */
public class BackpackItem extends Item {
    public BackpackItem(Properties p) { super(p); }

    @Override
    public EquipmentSlot getEquipmentSlot(ItemStack stack) { return EquipmentSlot.CHEST; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack st = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && player.getItemBySlot(EquipmentSlot.CHEST).isEmpty()) {
            if (!level.isClientSide) { player.setItemSlot(EquipmentSlot.CHEST, st.copy()); st.setCount(0); player.displayClientMessage(Component.literal("Backpack on your back. Y toggles the lantern, I opens it."), true); }
            return InteractionResultHolder.sidedSuccess(ItemStack.EMPTY, level.isClientSide);
        }
        if (!level.isClientSide && player instanceof ServerPlayer sp) open(sp, st);
        return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
    }

    public static void open(ServerPlayer sp, ItemStack stack) {
        Container c = new Bag(stack);
        NetworkHooks.openScreen(sp, new SimpleMenuProvider((id, inv, pl) -> new ChestMenu(MenuType.GENERIC_9x3, id, inv, c, 3), Component.translatable("item.frostveil.lantern_backpack")));
    }

    private static final class Bag extends SimpleContainer {
        private final ItemStack stack;

        Bag(ItemStack stack) {
            super(27);
            this.stack = stack;
            CompoundTag t = stack.getTag();
            if (t != null && t.contains("Items")) {
                NonNullList<ItemStack> list = NonNullList.withSize(27, ItemStack.EMPTY);
                ContainerHelper.loadAllItems(t, list);
                for (int i = 0; i < 27; i++) setItem(i, list.get(i));
            }
        }

        @Override
        public void stopOpen(Player p) {
            super.stopOpen(p);
            NonNullList<ItemStack> list = NonNullList.withSize(27, ItemStack.EMPTY);
            for (int i = 0; i < 27; i++) list.set(i, getItem(i));
            ContainerHelper.saveAllItems(stack.getOrCreateTag(), list);
        }
    }
}
