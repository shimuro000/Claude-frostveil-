package com.Ken.frostveil.item;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;

/** A katana: faster and longer than a sword, with a quick-draw first strike (see CombatService). Ryo carries one. */
public class KatanaItem extends SwordItem {
    public KatanaItem(Properties p) { super(Tiers.IRON, 2, -1.6f, p); }
}
