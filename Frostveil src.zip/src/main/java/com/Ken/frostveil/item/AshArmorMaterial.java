package com.Ken.frostveil.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Armor of the Ash Knights. Texture: assets/frostveil/textures/models/armor/ash_layer_1.png (+ _2 for legs). */
public enum AshArmorMaterial implements ArmorMaterial {
    INSTANCE;

    @Override public int getDurabilityForType(ArmorItem.Type t) { return switch (t) { case HELMET -> 165; case CHESTPLATE -> 240; case LEGGINGS -> 225; case BOOTS -> 195; }; }
    @Override public int getDefenseForType(ArmorItem.Type t) { return switch (t) { case HELMET -> 2; case CHESTPLATE -> 6; case LEGGINGS -> 5; case BOOTS -> 2; }; }
    @Override public int getEnchantmentValue() { return 9; }
    @Override public SoundEvent getEquipSound() { return SoundEvents.ARMOR_EQUIP_IRON; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.EMPTY; }
    @Override public String getName() { return "frostveil:ash"; }
    @Override public float getToughness() { return 1.0f; }
    @Override public float getKnockbackResistance() { return 0.1f; }
}
