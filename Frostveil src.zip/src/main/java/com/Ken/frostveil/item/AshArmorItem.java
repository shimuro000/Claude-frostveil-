package com.Ken.frostveil.item;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Ash Knight armor. Strong, but cursed: wearing it makes the ash cling to your core (Ash Curse). */
public class AshArmorItem extends ArmorItem {
    public AshArmorItem(ArmorItem.Type type, Properties p) { super(AshArmorMaterial.INSTANCE, type, p); }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal("Cursed: the ash clings to your core.").withStyle(ChatFormatting.DARK_RED));
        tips.add(Component.literal("Slows you, weakens your blows and drains your aura.").withStyle(ChatFormatting.GRAY));
    }
}
