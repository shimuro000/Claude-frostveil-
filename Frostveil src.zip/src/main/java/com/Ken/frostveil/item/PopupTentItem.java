package com.Ken.frostveil.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;

/** Pop-up Tent: right click the ground and a small tent with a bed and a campfire unfolds. It becomes your respawn point. */
public class PopupTentItem extends Item {
    public PopupTentItem(Properties p) { super(p); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level l = ctx.getLevel();
        if (l.isClientSide) return InteractionResult.SUCCESS;
        BlockPos base = ctx.getClickedPos().relative(ctx.getClickedFace());
        List<BlockPos> shell = new ArrayList<>();
        for (int k = 0; k < 3; k++) {
            for (int x = -2 + k; x <= 2 - k; x++) {
                for (int z = -2 + k; z <= 2 - k; z++) {
                    boolean edge = Math.abs(x) == 2 - k || Math.abs(z) == 2 - k;
                    if (edge) shell.add(base.offset(x, k, z));
                }
            }
        }
        for (BlockPos b : shell) {
            BlockState bs = l.getBlockState(b);
            boolean free = bs.isAir() || bs.is(Blocks.SNOW) || bs.is(Blocks.GRASS) || bs.is(Blocks.TALL_GRASS) || bs.is(Blocks.FERN);
            if (!free) {
                if (ctx.getPlayer() != null) ctx.getPlayer().displayClientMessage(Component.literal("Not enough room for the tent here."), true);
                return InteractionResult.FAIL;
            }
        }
        for (BlockPos b : shell) {
            l.setBlock(b, (b.getY() - base.getY() == 2 ? Blocks.LIGHT_GRAY_WOOL : Blocks.WHITE_WOOL).defaultBlockState(), 3);
        }
        l.setBlock(base.offset(0, 0, 2), Blocks.AIR.defaultBlockState(), 3);   // doorway
        l.setBlock(base.offset(0, 1, 2), Blocks.AIR.defaultBlockState(), 3);
        BlockState foot = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.EAST).setValue(BedBlock.PART, BedPart.FOOT);
        l.setBlock(base.offset(-1, 0, -1), foot, 3);
        l.setBlock(base.offset(0, 0, -1), foot.setValue(BedBlock.PART, BedPart.HEAD), 3);
        l.setBlock(base.offset(1, 0, 1), Blocks.CAMPFIRE.defaultBlockState(), 3);
        l.playSound(null, base, SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 1f, 0.9f);
        if (ctx.getPlayer() instanceof ServerPlayer sp) {
            sp.setRespawnPosition(l.dimension(), base.offset(0, 0, 1), 0f, true, true);
            sp.displayClientMessage(Component.literal("The tent unfolds. It is your respawn point now."), true);
            if (!sp.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
