package com.Ken.frostveil.entity;

import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Saga 1 EIU animals turned monsters. kind: 0 small cow (E), 1 large cow (D), 2 boar (tier 2, weak point: neck), 3 lava-skin wolf. */
public class EiuBeastEntity extends Monster {
    private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(EiuBeastEntity.class, EntityDataSerializers.INT);
    private int fireCooldown = 60;

    public EiuBeastEntity(EntityType<? extends EiuBeastEntity> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 20).add(Attributes.MOVEMENT_SPEED, 0.26).add(Attributes.ATTACK_DAMAGE, 3).add(Attributes.FOLLOW_RANGE, 20);
    }

    public static EiuBeastEntity spawn(ServerLevel level, int kind, BlockPos pos) {
        EiuBeastEntity e = new EiuBeastEntity(ModEntities.BEAST.get(), level);
        e.setKind(kind);
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360f, 0);
        level.addFreshEntity(e);
        return e;
    }

    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(KIND, 0); }
    public int kind() { return entityData.get(KIND); }

    public void setKind(int k) {
        entityData.set(KIND, k);
        double hp = switch (k) { case 1 -> 40; case 2 -> 45; case 3 -> 70; default -> 18; };
        double dmg = switch (k) { case 1 -> 5; case 2 -> 6; case 3 -> 7; default -> 3; };
        double spd = switch (k) { case 3 -> 0.36; case 2 -> 0.3; default -> 0.25; };
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(hp);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(dmg);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(spd);
        setHealth((float) hp);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.35, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<Player>(this, Player.class, true) {
            @Override public boolean canUse() { return kind() >= 2 && super.canUse(); } // cows only defend; boars and wolves hunt
        });
    }

    @Override
    public void tick() {
        super.tick();
        if (kind() == 3) {
            if (level().isClientSide) {
                if (random.nextInt(3) == 0) level().addParticle(ParticleTypes.SMOKE, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0.03, 0);
                if (random.nextInt(8) == 0) level().addParticle(ParticleTypes.FLAME, getRandomX(0.5), getY() + 0.8, getRandomZ(0.5), 0, 0.01, 0);
            } else if (getTarget() != null && --fireCooldown <= 0) {
                fireCooldown = 70;
                LivingEntity t = getTarget();
                double dx = t.getX() - getX(), dy = t.getY(0.5) - getY(0.5), dz = t.getZ() - getZ();
                SmallFireball f = new SmallFireball(level(), this, dx, dy, dz);
                f.setPos(getX(), getY(0.6), getZ());
                level().addFreshEntity(f);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // weak point: neck of boar-type monsters (hits from above the shoulder line)
        if (kind() == 2 && source.getDirectEntity() instanceof IceConstructEntity ic && ic.getY() > getY() + getBbHeight() * 0.55) amount *= 1.6f;
        return super.hurt(source, amount);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recent) {
        super.dropCustomDeathLoot(source, looting, recent);
        spawnAtLocation(new ItemStack(ModItems.MONSTER_MEAT.get(), 1 + random.nextInt(2)));
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putInt("kind", kind()); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); setKind(t.getInt("kind")); }
}
