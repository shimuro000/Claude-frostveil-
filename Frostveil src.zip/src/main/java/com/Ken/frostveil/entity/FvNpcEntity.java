package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.story.DialogueService;
import com.Ken.frostveil.world.FrostveilWorld;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * A person of Tatsuma (or an enemy). Behaviour is driven by NpcDefs: role, home, daily schedule (LifeGoal), special ability (AbilityGoal),
 * danger reaction, speech bubbles. Companions (owner set) follow the player and obey orders. Right click = talk.
 */
public class FvNpcEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> NPC_ID = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.STRING);
    /** 0 idle, 1 training, 2 cleaning blade, 3 mourning, 4 arms crossed (poses are cosmetic hints for the renderer). */
    private static final EntityDataAccessor<Integer> POSE = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> BUBBLE = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.STRING);
    /** Activity pose for the renderer: 0 idle, 1 hammer, 2 stir, 3 train forms, 4 eat, 5 sell, 6 farm, 7 play, 8 guard, 10 talk, 11 wave. */
    private static final EntityDataAccessor<Integer> ACT = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SEED = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.INT);

    private UUID ownerId;
    private int order = 0; // 0 follow, 1 stay, 2 focus, 3 retreat
    private String homeName = "", workName = "";
    private boolean hostileOverride = false;
    private int shotCooldown = 0, abilityCd = 0, bubbleUntil = 0;
    private long holdUntil = 0;
    private int talkUntil = 0, chatUntil = 0, pendingAt = 0, lastGreet = -4000;
    private UUID chatPartner;
    private int combatUntil = 0, actStart = 0;
    private boolean slashParity = false;
    private String pendingSay = "";

    public FvNpcEntity(EntityType<? extends FvNpcEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 30).add(Attributes.MOVEMENT_SPEED, 0.28).add(Attributes.ATTACK_DAMAGE, 4)
                .add(Attributes.FOLLOW_RANGE, 24).add(Attributes.KNOCKBACK_RESISTANCE, 0.3);
    }

    public static FvNpcEntity spawn(ServerLevel level, String id, BlockPos pos) {
        FvNpcEntity e = new FvNpcEntity(ModEntities.NPC.get(), level);
        e.entityData.set(SEED, level.random.nextInt());
        e.setNpcId(id);
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        level.addFreshEntity(e);
        return e;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(NPC_ID, "villager");
        entityData.define(POSE, 0);
        entityData.define(BUBBLE, "");
        entityData.define(SEED, 0);
        entityData.define(ACT, 0);
    }

    public String npcId() { return entityData.get(NPC_ID); }
    public int npcPose() { return entityData.get(POSE); }
    public int act() { return entityData.get(ACT); }
    public void setAct(int a) { if (entityData.get(ACT) != a) entityData.set(ACT, a); }
    public int actStart() { return actStart; }

    /** Combat acts: 20 bow aim, 21 bow release, 22/29 slash (right / left), 23 spear thrust, 24 dash lunge, 25 overhead slam, 26 frost burst, 28 stagger, 30 ready stance. */
    public void playCombat(int code, int ticks) {
        setAct(code);
        combatUntil = tickCount + ticks;
        actStart = tickCount;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (ACT.equals(key)) actStart = tickCount; // client: animations start counting from the moment the pose changes
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        String ab = def().ability();
        if (ab.equals("spear")) playCombat(23, 14);
        else if (ab.equals("slam")) playCombat(25, 18);
        else if (def().ranged()) playCombat(21, 8);
        else { slashParity = !slashParity; playCombat(slashParity ? 22 : 29, 10); }
        return super.doHurtTarget(target);
    }
    public void setNpcPose(int p) { entityData.set(POSE, p); }
    public String bubble() { return entityData.get(BUBBLE); }
    public int seed() { return entityData.get(SEED); }
    public NpcDefs.Def def() { return NpcDefs.get(npcId()); }
    public UUID getOwnerId() { return ownerId; }
    public void setOwner(UUID id) { ownerId = id; }
    public void setHostile(boolean h) { hostileOverride = h; }
    public String homeName() { return homeName.isEmpty() ? def().home() : homeName; }
    public String workName() { return workName; }
    public void setPlaces(String home, String work) { homeName = home; workName = work; }

    public CharacterProfile look() {
        NpcDefs.Def d = def();
        return d.randomLook() ? NpcDefs.randomLook(d, seed()) : d.look();
    }

    public void setNpcId(String id) {
        entityData.set(NPC_ID, id);
        NpcDefs.Def d = def();
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(d.health());
        setHealth(d.health());
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(Math.max(0.1, d.damage()));
        setCustomName(Component.translatable("npc.frostveil." + id));
        setCustomNameVisible(true);
        if (!d.weapon().isEmpty()) {
            var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(d.weapon()));
            if (item != null && item != Items.AIR) setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(item));
        }
        refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) { return super.getDimensions(pose).scale(NpcDefs.get(npcId()).scale()); }

    /** Hostile to the PLAYER (raiders, or a friend during a scripted spar). */
    public boolean isHostileTo(Player p) { return hostileOverride || !def().friendly(); }

    /** An enemy of the village (Ash Knights). Sparring friends are NOT raiders, so nobody ever attacks them. */
    public boolean isRaider() { return !def().friendly(); }

    public boolean isScripted() { return level().getGameTime() < holdUntil; }
    public void hold(long ticks) { holdUntil = ticks <= 0 ? 0 : level().getGameTime() + ticks; if (ticks > 0) getNavigation().stop(); }

    /** Two people stop, face each other and exchange a line each. */
    public void startChat(FvNpcEntity o) {
        if (o == this || chatUntil > tickCount || o.chatUntil > o.tickCount || isRaider() || o.isRaider()) return;
        chatUntil = tickCount + 120; o.chatUntil = o.tickCount + 120;
        chatPartner = o.getUUID(); o.chatPartner = getUUID();
        String[] a = NpcDefs.phrases(def().role()), b = NpcDefs.phrases(o.def().role());
        say(a[random.nextInt(a.length)]);
        o.pendingSay = b[o.random.nextInt(b.length)]; o.pendingAt = o.tickCount + 45;
        getNavigation().stop(); o.getNavigation().stop();
    }

    /** Speech bubble above the head for ~4 seconds. */
    public void say(String text) {
        entityData.set(BUBBLE, text);
        bubbleUntil = tickCount + 90;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        if (def().civilian()) {
            goalSelector.addGoal(1, new AvoidEntityGoal<LivingEntity>(this, LivingEntity.class,
                    e -> e instanceof Monster || (e instanceof FvNpcEntity f && f.isHostileTo(null)), 11f, 1.0, 1.45, EntitySelector.NO_CREATIVE_OR_SPECTATOR::test));
        }
        goalSelector.addGoal(1, new IceBowGoal(this));
        goalSelector.addGoal(2, new AbilityGoal(this));
        goalSelector.addGoal(2, new ShelterGoal(this));
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15, true) {
            @Override public boolean canUse() { return (def().damage() > 0 && (isHostileTo(null) || getTarget() != null)) && super.canUse(); }
        });
        goalSelector.addGoal(4, new FollowOwnerGoal(this));
        goalSelector.addGoal(5, new RaiderAdvanceGoal(this));
        goalSelector.addGoal(5, new LifeGoal(this));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this) {
            @Override public boolean canUse() { // never retaliate against a friend: only against enemies of the village
                LivingEntity last = mob.getLastHurtByMob();
                if (last instanceof FvNpcEntity f && !f.isRaider()) return false;
                if (last instanceof Player && def().civilian()) return false;
                return super.canUse();
            }
        });
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true, p -> isHostileTo(null)));
        if (def().friendly() && def().damage() >= 3.5f) { // fighters of the village defend it
            targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 5, true, false,
                    m -> m instanceof Monster || m instanceof FargasEntity || (m instanceof FvNpcEntity f && f.isRaider())));
        }
        if (!def().friendly()) { // raiders go for the player and the people of the village
            targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 5, true, false,
                    m -> m instanceof Player || (m instanceof FvNpcEntity f && !f.isRaider() && f.ownerId == null)));
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp && !isHostileTo(player)) {
            if (isSleeping()) { stopSleeping(); }
            getNavigation().stop();
            lookAt(player, 30f, 30f);
            setAct(10); talkUntil = tickCount + 80;
            DialogueService.open(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof Player pl && !isHostileTo(pl)) return false; // friendly villagers cannot be hit by the player
        if (source.getDirectEntity() instanceof Snowball) return false;               // snowball games are harmless
        if (source.getEntity() instanceof FvNpcEntity f && !f.isRaider() && !isRaider()) return false; // no friendly fire
        if (isSleeping()) stopSleeping();
        if (def().unique() && def().friendly() && getHealth() - amount < 4f) { // story characters are never killed by random fights
            amount = Math.max(0f, getHealth() - 4f);
            if (amount <= 0f) return false;
        }
        boolean r = super.hurt(source, amount);
        if (r && !level().isClientSide && amount >= 1.5f && !isSleeping()) playCombat(28, 8);
        if (r && !level().isClientSide && random.nextInt(3) == 0 && def().friendly()) say(NpcDefs.phrases("alarm")[random.nextInt(NpcDefs.phrases("alarm").length)]);
        return r;
    }

    public void setOrder(int o, ServerPlayer by) {
        order = o;
        by.displayClientMessage(Component.translatable("order.frostveil." + o, getCustomName()), true);
        if (o == 3) setTarget(null);
    }

    public int order() { return order; }

    @Override
    public void tick() {
        super.tick();
        if (shotCooldown > 0) shotCooldown--;
        if (abilityCd > 0) abilityCd--;
        if (level().isClientSide) {
            // quest marker: sparkles above whoever the compass points at
            if (tickCount % 8 == 0 && npcId().equals(FvCap.CLIENT.trackedNpc)) level().addParticle(ParticleTypes.END_ROD, getX(), getY() + getBbHeight() + 0.9, getZ(), 0, 0.04, 0);
            return;
        }
        if (!bubble().isEmpty() && tickCount > bubbleUntil) entityData.set(BUBBLE, "");
        if (combatUntil != 0 && tickCount > combatUntil) { combatUntil = 0; setAct(getTarget() != null ? 30 : 0); }
        else if (combatUntil == 0) {
            if (getTarget() != null && act() == 0) { setAct(30); actStart = tickCount; }
            else if (getTarget() == null && act() == 30) setAct(0);
        }
        if (talkUntil > 0 && tickCount > talkUntil) { talkUntil = 0; setAct(0); }
        if (pendingAt > 0 && tickCount >= pendingAt) { if (!pendingSay.isEmpty()) say(pendingSay); pendingSay = ""; pendingAt = 0; }
        if (chatUntil > tickCount && chatPartner != null && level() instanceof ServerLevel csl) {
            net.minecraft.world.entity.Entity pe = csl.getEntity(chatPartner);
            if (pe != null) getLookControl().setLookAt(pe, 30f, 30f);
            setAct(10);
        } else if (chatUntil != 0 && tickCount > chatUntil) { chatUntil = 0; chatPartner = null; setAct(0); }
        if (tickCount % 40 == 11 && ownerId == null && def().friendly() && !isSleeping() && !isScripted() && tickCount - lastGreet > 1600 && bubble().isEmpty()) {
            Player gp = level().getNearestPlayer(this, 6);
            if (gp instanceof ServerPlayer gsp && FvCap.get(gsp).active()) {
                lastGreet = tickCount;
                int hour = (int) (((level().getDayTime() / 1000L) + 6L) % 24L);
                String who = FvCap.get(gsp).inStory() ? "Shimoro" : gsp.getName().getString();
                String t = hour >= 5 && hour < 11 ? "Good morning, " + who + "!" : (hour < 17 && hour >= 11 ? "Hello, " + who + "!" : (hour < 21 && hour >= 17 ? "Good evening, " + who + "." : "Shouldn't you be asleep, " + who + "?"));
                if (FvCap.get(gsp).trustOf(npcId()) >= 2) t = who + "! Over here!";
                say(t);
                lookAt(gsp, 30f, 30f);
                setAct(11); talkUntil = tickCount + 50;
            }
        }
        if (tickCount % 60 == 5 && def().role().equals("child") && bubble().isEmpty()) { // kids love watching ice
            Player cp = level().getNearestPlayer(this, 10);
            if (cp != null && level().getGameTime() - cp.getPersistentData().getLong("fv_cast_tick") < 60) { say(random.nextBoolean() ? "Whoa! Ice!" : "Do it again!"); setAct(11); talkUntil = tickCount + 50; }
        }
        if (tickCount % 20 == 3 && def().friendly() && def().damage() >= 3.5f && ownerId == null && getTarget() == null && level() instanceof ServerLevel sl && FrostveilWorld.data(sl).raid) {
            FvNpcEntity best = null; double bd = 3600;
            for (FvNpcEntity r : sl.getEntitiesOfClass(FvNpcEntity.class, getBoundingBox().inflate(60), q -> q.isRaider() && q.isAlive())) { double dd = r.distanceToSqr(this); if (dd < bd) { bd = dd; best = r; } }
            if (best != null) { setTarget(best); if (isSleeping()) stopSleeping(); }
        }
        // spoken lines: people talk when you are around
        if (tickCount % 120 == 7 && ownerId == null && !isSleeping() && random.nextInt(3) == 0) {
            Player near = level().getNearestPlayer(this, 9);
            if (near != null && bubble().isEmpty()) {
                String key = def().role();
                boolean danger = !level().getEntitiesOfClass(Monster.class, getBoundingBox().inflate(14)).isEmpty() || level().getEntitiesOfClass(FvNpcEntity.class, getBoundingBox().inflate(14), f -> f.isHostileTo(null)).size() > 0;
                if (danger && def().friendly()) key = "alarm";
                String[] ph = NpcDefs.phrases(key);
                say(ph[random.nextInt(ph.length)]);
            }
        }
        if (hostileOverride && getTarget() instanceof ServerPlayer sp && (npcId().equals("fang") || npcId().equals("ryo"))
                && (sp.getHealth() < sp.getMaxHealth() * 0.4f || getHealth() < getMaxHealth() * 0.35f)) {
            hostileOverride = false; // scripted spar: it ends when either side is clearly beaten
            setTarget(null);
            setHealth(getMaxHealth());
            com.Ken.frostveil.story.MissionManager.event(sp, "spar_end", npcId());
        }
        if (ownerId != null && tickCount % 40 == 0 && getHealth() < getMaxHealth()) heal(0.5f);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("npc", npcId());
        tag.putInt("seed", seed());
        if (ownerId != null) tag.putUUID("owner", ownerId);
        tag.putInt("order", order);
        tag.putInt("pose", npcPose());
        tag.putString("homeName", homeName);
        tag.putString("workName", workName);
        tag.putBoolean("hostile", hostileOverride);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(SEED, tag.getInt("seed"));
        if (tag.contains("npc")) setNpcId(tag.getString("npc"));
        if (tag.hasUUID("owner")) ownerId = tag.getUUID("owner");
        order = tag.getInt("order");
        setNpcPose(tag.getInt("pose"));
        homeName = tag.getString("homeName");
        workName = tag.getString("workName");
        hostileOverride = tag.getBoolean("hostile");
    }

    @Override
    public boolean removeWhenFarAway(double dist) { return false; }

    // ---------------------------------------------------------------- goals

    private static final class FollowOwnerGoal extends Goal {
        private final FvNpcEntity npc;
        FollowOwnerGoal(FvNpcEntity npc) { this.npc = npc; setFlags(EnumSet.of(Flag.MOVE)); }
        private ServerPlayer owner() {
            return npc.ownerId == null || !(npc.level() instanceof ServerLevel sl) ? null : (sl.getPlayerByUUID(npc.ownerId) instanceof ServerPlayer sp ? sp : null);
        }
        @Override public boolean canUse() { ServerPlayer o = owner(); return o != null && npc.order == 0 && npc.distanceToSqr(o) > 25 && npc.getTarget() == null; }
        @Override public boolean canContinueToUse() { ServerPlayer o = owner(); return o != null && npc.order == 0 && npc.distanceToSqr(o) > 9 && npc.getTarget() == null; }
        @Override public void tick() {
            ServerPlayer o = owner();
            if (o == null) return;
            npc.getNavigation().moveTo(o, 1.15);
            if (npc.distanceToSqr(o) > 900) npc.teleportTo(o.getX() + 1, o.getY(), o.getZ() + 1);
        }
    }

    /** Ranged NPCs shoot frost-tipped arrows and keep their distance. */
    private static final class IceBowGoal extends Goal {
        private final FvNpcEntity npc;
        IceBowGoal(FvNpcEntity npc) { this.npc = npc; setFlags(EnumSet.of(Flag.LOOK)); }
        @Override public boolean canUse() { LivingEntity t = npc.getTarget(); return npc.def().ranged() && t != null && t.isAlive() && npc.distanceToSqr(t) > 9 && npc.hasLineOfSight(t); }
        @Override public void tick() {
            LivingEntity t = npc.getTarget();
            if (t == null) return;
            npc.getLookControl().setLookAt(t, 30, 30);
            if (npc.shotCooldown > 0) { if (npc.shotCooldown <= 12 && npc.combatUntil < npc.tickCount) npc.playCombat(20, 14); return; } // drawing the bow
            npc.shotCooldown = 22;
            npc.playCombat(21, 8); // release
            Arrow a = new Arrow(npc.level(), npc);
            double dx = t.getX() - npc.getX(), dy = t.getY(0.33) - a.getY(), dz = t.getZ() - npc.getZ();
            a.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.1, dz, 2.0f, 1.5f);
            a.setBaseDamage(4.0);
            npc.level().addFreshEntity(a);
            if (npc.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SNOWFLAKE, a.getX(), a.getY(), a.getZ(), 8, 0.1, 0.1, 0.1, 0.02);
                sl.playSound(null, npc.getX(), npc.getY(), npc.getZ(), SoundEvents.CROSSBOW_SHOOT, SoundSource.NEUTRAL, 0.8f, 1.2f);
            }
        }
    }

    /** During a raid civilians run home and stay inside. */
    private static final class ShelterGoal extends Goal {
        private final FvNpcEntity n;
        ShelterGoal(FvNpcEntity n) { this.n = n; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return n.def().civilian() && n.ownerId == null && n.getTarget() == null && n.level() instanceof ServerLevel sl && FrostveilWorld.data(sl).raid; }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void tick() {
            ServerLevel sl = (ServerLevel) n.level();
            if (n.isSleeping()) n.stopSleeping();
            BlockPos h = FrostveilWorld.poi(sl, n.homeName());
            if (h == null) return;
            if (n.tickCount % 20 == 0 && n.distanceToSqr(h.getX() + 0.5, h.getY(), h.getZ() + 0.5) > 6) n.getNavigation().moveTo(h.getX() + 0.5, h.getY(), h.getZ() + 0.5, 1.35);
            if (n.tickCount % 140 == 0 && n.bubble().isEmpty()) n.say(NpcDefs.phrases("alarm")[n.random.nextInt(NpcDefs.phrases("alarm").length)]);
        }
        @Override public void stop() { n.setAct(0); }
    }

    /** Raiders do not stand at the gate: with no target they march into the village. */
    private static final class RaiderAdvanceGoal extends Goal {
        private final FvNpcEntity n;
        RaiderAdvanceGoal(FvNpcEntity n) { this.n = n; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return n.isRaider() && n.getTarget() == null && n.level() instanceof ServerLevel && n.tickCount % 30 == 0; }
        @Override public void start() {
            ServerLevel sl = (ServerLevel) n.level();
            BlockPos c = FrostveilWorld.poi(sl, n.random.nextBoolean() ? "center" : "council");
            if (c != null) n.getNavigation().moveTo(c.getX() + n.random.nextInt(9) - 4, c.getY(), c.getZ() + n.random.nextInt(9) - 4, 1.1);
        }
    }

    /** Each fighter has a signature move: Awi and Ryo dash, Yu freezes the ground around him, Fang slams. */
    private static final class AbilityGoal extends Goal {
        private final FvNpcEntity n;
        AbilityGoal(FvNpcEntity n) { this.n = n; }
        @Override public boolean canUse() {
            LivingEntity t = n.getTarget();
            String a = n.def().ability();
            if (a.isEmpty() || t == null || !t.isAlive() || n.abilityCd > 0) return false;
            double d = n.distanceToSqr(t);
            return switch (a) { case "spear", "wind_dash" -> d > 16 && d < 100; case "frost_burst" -> d < 25; case "slam" -> d < 20; default -> false; };
        }
        @Override public boolean canContinueToUse() { return false; }
        @Override public void start() {
            LivingEntity t = n.getTarget();
            if (t == null || !(n.level() instanceof ServerLevel sl)) return;
            switch (n.def().ability()) {
                case "spear", "wind_dash" -> {
                    Vec3 d = t.position().subtract(n.position()).multiply(1, 0, 1).normalize();
                    n.setDeltaMovement(d.x * 1.15, 0.28, d.z * 1.15);
                    n.abilityCd = 90;
                    n.playCombat(24, 14);
                    sl.sendParticles(ParticleTypes.SWEEP_ATTACK, n.getX(), n.getY() + 1, n.getZ(), 1, 0, 0, 0, 0);
                    sl.sendParticles(ParticleTypes.CLOUD, n.getX(), n.getY() + 0.2, n.getZ(), 10, 0.3, 0.1, 0.3, 0.05);
                    sl.playSound(null, n.getX(), n.getY(), n.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.NEUTRAL, 1f, 1.2f);
                }
                case "frost_burst", "slam" -> {
                    boolean slam = n.def().ability().equals("slam");
                    n.abilityCd = slam ? 140 : 110;
                    n.playCombat(slam ? 25 : 26, slam ? 18 : 14);
                    double r = slam ? 4.5 : 4.0;
                    for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, n.getBoundingBox().inflate(r), q -> q != n && !(q instanceof Player) && (q instanceof Monster || q instanceof FargasEntity || (q instanceof FvNpcEntity f && f.isRaider())))) {
                        e.hurt(n.damageSources().mobAttack(n), slam ? 7f : 5f);
                        e.knockback(slam ? 1.2 : 0.8, n.getX() - e.getX(), n.getZ() - e.getZ());
                        if (slam) e.setDeltaMovement(e.getDeltaMovement().add(0, 0.35, 0)); else e.setTicksFrozen(e.getTicksRequiredToFreeze() + 40);
                    }
                    for (int i = 0; i < 36; i++) {
                        double a = Math.PI * 2 * i / 36;
                        sl.sendParticles(slam ? ParticleTypes.CLOUD : ParticleTypes.SNOWFLAKE, n.getX() + Math.cos(a) * 1.2, n.getY() + 0.2, n.getZ() + Math.sin(a) * 1.2, 0, Math.cos(a) * 0.5, 0.05, Math.sin(a) * 0.5, 1.0);
                    }
                    sl.playSound(null, n.getX(), n.getY(), n.getZ(), slam ? SoundEvents.ANVIL_LAND : SoundEvents.GLASS_BREAK, SoundSource.NEUTRAL, 1f, slam ? 0.6f : 1.4f);
                }
                default -> { }
            }
        }
    }

    /** The daily life: where to be, what to do and when (see NpcDefs schedules). */
    private static final class LifeGoal extends Goal {
        private final FvNpcEntity n;
        private String cur = "";
        private BlockPos dest;
        private int wait = 0, tickAt = 0, patrolIdx = 0;
        private FvNpcEntity visitFriend;

        @Override public void stop() { n.setAct(0); }

        private static int actCode(String act, String poi) {
            return switch (act) {
                case "work" -> switch (poi) { case "forge" -> 1; case "market" -> 5; case "farm" -> 6; default -> 0; };
                case "cook", "feed" -> 2; case "train" -> 3; case "eat" -> 4; case "play" -> 7; case "guard" -> 8; default -> 0;
            };
        }

        LifeGoal(FvNpcEntity n) { this.n = n; setFlags(EnumSet.of(Flag.MOVE)); }

        @Override public boolean canUse() { return n.ownerId == null && n.getTarget() == null && !n.isScripted() && !n.def().sched().isEmpty() && n.level() instanceof ServerLevel && !FrostveilWorld.data((ServerLevel) n.level()).raid; }
        @Override public boolean canContinueToUse() { return canUse(); }

        private String place(String token) {
            return token.equals("$home") ? n.homeName() : (token.equals("$work") ? (n.workName().isEmpty() ? "center" : n.workName()) : token);
        }

        @Override
        public void tick() {
            ServerLevel sl = (ServerLevel) n.level();
            int hour = (int) (((sl.getDayTime() / 1000L) + 6L) % 24L);
            NpcDefs.Entry e = n.def().at(hour);
            if (e == null) return;
            if (sl.isRaining() && n.def().civilian() && !e.act().equals("sleep")) e = new NpcDefs.Entry(e.from(), e.to(), "shelter", "$home"); // storms send people home
            String poiName = place(e.poi());
            String key = e.act() + "@" + poiName;
            if (!key.equals(cur)) {
                cur = key; dest = null; wait = 0;
                if (n.isSleeping()) n.stopSleeping();
            }
            if (n.isSleeping()) return;
            boolean sleep = e.act().equals("sleep");
            if (dest == null || (wait <= 0 && !sleep && n.getNavigation().isDone() && needNewDest(e.act()))) dest = pick(sl, e.act(), poiName);
            if (dest == null) return;
            double dx = dest.getX() + 0.5 - n.getX(), dz = dest.getZ() + 0.5 - n.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            boolean play = e.act().equals("play");
            if (visitFriend != null && dist <= 3.2) { // arrived at a friend: greet and chat
                n.startChat(visitFriend);
                visitFriend = null; dest = null; wait = 60;
                return;
            }
            if (dist > (sleep ? 1.4 : 2.4)) {
                n.setAct(0);
                if (n.tickCount % 25 == tickAt % 25 || n.getNavigation().isDone()) n.getNavigation().moveTo(dest.getX() + 0.5, dest.getY(), dest.getZ() + 0.5, play ? 1.3 : 0.85);
                return;
            }
            n.getNavigation().stop();
            if (sleep) { trySleep(sl, poiName); return; }
            wait--;
            if (wait < -200) wait = 0;
            work(sl, e.act(), poiName);
        }

        private boolean needNewDest(String act) { return act.equals("wander") || act.equals("play") || act.equals("patrol") || act.equals("gather") || act.equals("work") && n.tickCount % 400 == 0; }

        private BlockPos pick(ServerLevel sl, String act, String poiName) {
            BlockPos base = FrostveilWorld.poi(sl, poiName);
            if (base == null) return null;
            tickAt = n.getUUID().hashCode() & 31;
            switch (act) {
                case "sleep" -> {
                    String bed = poiName + "_bed" + (1 + Math.floorMod(n.seed(), bedCount(poiName)));
                    BlockPos b = FrostveilWorld.poi(sl, bed);
                    return b == null ? base : b;
                }
                case "patrol" -> {
                    patrolIdx = (patrolIdx + 1) % 12;
                    double a = patrolIdx * Math.PI / 6.0 + (n.seed() & 3);
                    BlockPos c = FrostveilWorld.poi(sl, "center");
                    int x = c.getX() + (int) Math.round(Math.cos(a) * 33), z = c.getZ() + (int) Math.round(Math.sin(a) * 33);
                    wait = 40;
                    return new BlockPos(x, c.getY(), z);
                }
                case "wander", "gather", "play" -> {
                    String fr = NpcDefs.friend(n.npcId());
                    if (!fr.isEmpty() && !act.equals("play") && n.random.nextInt(4) == 0) { // sometimes walk over to a friend
                        for (FvNpcEntity o : sl.getEntitiesOfClass(FvNpcEntity.class, n.getBoundingBox().inflate(70), q -> q.npcId().equals(fr) && q.isAlive() && !q.isSleeping())) { visitFriend = o; wait = 80; return o.blockPosition(); }
                    }
                    int r = act.equals("play") ? 12 : 7;
                    wait = 40 + n.random.nextInt(120);
                    return base.offset(n.random.nextInt(r * 2 + 1) - r, 0, n.random.nextInt(r * 2 + 1) - r);
                }
                default -> {
                    int h = n.seed();
                    wait = 20;
                    return base.offset((h & 3) - 1, 0, ((h >> 2) & 3) - 1);
                }
            }
        }

        private static int bedCount(String home) { return home.equals("kaina_house") ? 3 : 2; }

        private void trySleep(ServerLevel sl, String home) {
            BlockPos foot = dest;
            if (foot == null) return;
            BlockPos head = foot.east();
            if (sl.getBlockState(head).getBlock() instanceof BedBlock) n.startSleeping(head);
        }

        private void work(ServerLevel sl, String act, String poi) {
            int t = n.tickCount;
            if (n.chatUntil <= t) n.setAct(actCode(act, poi));
            if (act.equals("shelter") && t % 300 == tickAt && n.bubble().isEmpty()) n.say("What a storm!");
            if ((act.equals("wander") || act.equals("gather") || act.equals("eat")) && t % 20 == tickAt % 20 && n.random.nextInt(25) == 0) {
                for (FvNpcEntity o : sl.getEntitiesOfClass(FvNpcEntity.class, n.getBoundingBox().inflate(3.5), q -> q != n && q.ownerId == null && !q.isRaider())) { n.startChat(o); break; }
            }
            switch (act) {
                case "work" -> {
                    switch (poi) {
                        case "forge" -> { if (t % 24 == 0) { n.swing(InteractionHand.MAIN_HAND); sl.playSound(null, n.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.NEUTRAL, 0.35f, 1.1f + n.random.nextFloat() * 0.5f); sl.sendParticles(ParticleTypes.CRIT, n.getX(), n.getY() + 1.0, n.getZ() - 0.4, 6, 0.2, 0.1, 0.2, 0.2); sl.sendParticles(ParticleTypes.FLAME, n.getX(), n.getY() + 0.9, n.getZ() - 0.4, 2, 0.1, 0.05, 0.1, 0.01); } }
                        case "market" -> { if (t % 150 == 0 && n.bubble().isEmpty()) { String[] ph = NpcDefs.phrases("merchant"); n.say(ph[n.random.nextInt(ph.length)]); } if (t % 60 == 0) n.swing(InteractionHand.MAIN_HAND); }
                        case "farm" -> { if (t % 30 == 0) { n.swing(InteractionHand.MAIN_HAND); sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, n.getX(), n.getY() + 0.4, n.getZ() + 0.5, 3, 0.3, 0.1, 0.3, 0); } }
                        case "council" -> { if (t % 90 == 0) n.swing(InteractionHand.MAIN_HAND); }
                        default -> { if (t % 60 == 0) n.swing(InteractionHand.MAIN_HAND); }
                    }
                }
                case "cook" -> { if (t % 20 == 0) { n.swing(InteractionHand.MAIN_HAND); sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, n.getX() + 0.3, n.getY() + 1.4, n.getZ() + 0.3, 1, 0.1, 0.1, 0.1, 0.01); } }
                case "feed" -> { if (t % 50 == 0) { n.swing(InteractionHand.MAIN_HAND); sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, n.getX(), n.getY() + 1.2, n.getZ(), 2, 0.3, 0.2, 0.3, 0); if (n.bubble().isEmpty() && n.random.nextInt(3) == 0) n.say("Eat up!"); } }
                case "train" -> {
                    if (t % 16 == 0) {
                        n.swing(InteractionHand.MAIN_HAND);
                        boolean heavy = n.npcId().equals("fang");
                        for (int i = 0; i < 10; i++) { double a = Math.PI * 2 * i / 10; sl.sendParticles(ParticleTypes.SNOWFLAKE, n.getX() + Math.cos(a) * 0.7, n.getY() + 1.1, n.getZ() + Math.sin(a) * 0.7, 0, 0, 0.02, 0, 1); }
                        if (t % 64 == 0) sl.playSound(null, n.blockPosition(), heavy ? SoundEvents.PLAYER_ATTACK_STRONG : SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.NEUTRAL, 0.6f, 1.3f);
                    }
                }
                case "eat" -> { if (t % 80 == 0 && n.bubble().isEmpty() && n.random.nextInt(3) == 0) n.say("Mmm."); }
                case "play" -> {
                    if (t % 70 == tickAt) {
                        List<FvNpcEntity> mates = sl.getEntitiesOfClass(FvNpcEntity.class, n.getBoundingBox().inflate(11), m -> m != n && m.def().role().equals("child"));
                        if (!mates.isEmpty()) {
                            FvNpcEntity m = mates.get(n.random.nextInt(mates.size()));
                            Snowball sb = new Snowball(sl, n);
                            double dx = m.getX() - n.getX(), dy = m.getY(0.5) - sb.getY(), dz = m.getZ() - n.getZ();
                            sb.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.2, dz, 1.1f, 4f);
                            sl.addFreshEntity(sb);
                            n.swing(InteractionHand.MAIN_HAND);
                            if (n.bubble().isEmpty()) n.say(n.random.nextBoolean() ? "Haha!" : "Take that!");
                        }
                    }
                }
                case "guard" -> { if (t % 200 == 0) n.setYRot(n.getYRot() + 40f); }
                default -> { }
            }
        }
    }
}
