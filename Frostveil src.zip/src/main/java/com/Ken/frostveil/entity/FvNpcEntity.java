package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.story.DialogueService;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.resources.ResourceLocation;

/**
 * Story NPC: villagers, trainers, companions and Ash Knights share this class.
 * Behaviour comes from NpcDefs + a few synced flags. Talk = right click. Companions follow their owner and obey orders (U).
 * Replace the renderer with a GeckoLib model later without touching the logic.
 */
public class FvNpcEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> NPC_ID = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.STRING);
    /** 0 idle, 1 training (Awi), 2 cleaning blade (Ryo), 3 mourning/kneel, 4 arms crossed */
    private static final EntityDataAccessor<Integer> POSE = SynchedEntityData.defineId(FvNpcEntity.class, EntityDataSerializers.INT);

    private UUID ownerId;
    private int order = 0; // 0 follow, 1 stay, 2 focus, 3 retreat
    private BlockPos home;
    private boolean hostileOverride = false;
    private int shotCooldown = 0;

    public FvNpcEntity(EntityType<? extends FvNpcEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 30).add(Attributes.MOVEMENT_SPEED, 0.28).add(Attributes.ATTACK_DAMAGE, 4)
                .add(Attributes.FOLLOW_RANGE, 24).add(Attributes.KNOCKBACK_RESISTANCE, 0.3);
    }

    public static FvNpcEntity spawn(ServerLevel level, String id, BlockPos pos) {
        FvNpcEntity e = new FvNpcEntity(ModEntities.NPC.get(), level);
        e.setNpcId(id);
        e.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, level.random.nextFloat() * 360f, 0f);
        e.home = pos;
        level.addFreshEntity(e);
        return e;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(NPC_ID, "villager");
        entityData.define(POSE, 0);
    }

    public String npcId() { return entityData.get(NPC_ID); }
    public int npcPose() { return entityData.get(POSE); }
    public void setNpcPose(int p) { entityData.set(POSE, p); }
    public NpcDefs.Def def() { return NpcDefs.get(npcId()); }
    public UUID getOwnerId() { return ownerId; }
    public void setOwner(UUID id) { ownerId = id; }
    public void setHome(BlockPos p) { home = p; }
    public void setHostile(boolean h) { hostileOverride = h; }

    public void setNpcId(String id) {
        entityData.set(NPC_ID, id);
        NpcDefs.Def d = def();
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(d.health());
        setHealth(d.health());
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(Math.max(0.1, d.damage()));
        setCustomName(Component.translatable("npc.frostveil." + id));
        setCustomNameVisible(true);
        if (!d.weapon().isEmpty() && !d.weapon().contains("placeholder")) {
            var item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(d.weapon()));
            if (item != null && item != Items.AIR) setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(item));
        }
        refreshDimensions();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return super.getDimensions(pose).scale(NpcDefs.get(npcId()).scale());
    }

    public boolean isHostileTo(Player p) { return hostileOverride || !def().friendly(); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new IceBowGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, true) {
            @Override public boolean canUse() { return (def().damage() > 0 && (isHostileTo(null) || getTarget() != null)) && super.canUse(); }
        });
        goalSelector.addGoal(3, new FollowOwnerGoal(this));
        goalSelector.addGoal(4, new GoHomeGoal(this));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true, p -> isHostileTo(null)));
        targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Monster.class, 5, true, false, m -> def().friendly() && def().damage() > 0));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp && !isHostileTo(player)) {
            getNavigation().stop();
            lookAt(player, 30f, 30f);
            DialogueService.open(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof Player && !isHostileTo((Player) source.getEntity())) return false; // friendly villagers cannot be hit by the player
        return super.hurt(source, amount);
    }

    public void setOrder(int o, ServerPlayer by) {
        order = o;
        by.displayClientMessage(Component.translatable("order.frostveil." + o, getCustomName()), true);
        if (o == 3) setTarget(null);
    }

    public int order() { return order; }

    @Override
    public void tick() {
        super.tick();
        if (shotCooldown > 0) shotCooldown--;
        if (level().isClientSide) return;
        if (hostileOverride && getTarget() instanceof ServerPlayer sp && (npcId().equals("fang") || npcId().equals("ryo"))
                && (sp.getHealth() < sp.getMaxHealth() * 0.4f || getHealth() < getMaxHealth() * 0.3f)) {
            // scripted spar: it ends when either side is clearly beaten
            hostileOverride = false;
            setTarget(null);
            setHealth(getMaxHealth());
            com.Ken.frostveil.story.MissionManager.event(sp, "spar_end", npcId());
        }
        if (ownerId != null && tickCount % 40 == 0) { // companions regain composure slowly
            if (getHealth() < getMaxHealth()) heal(0.5f);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("npc", npcId());
        if (ownerId != null) tag.putUUID("owner", ownerId);
        tag.putInt("order", order);
        tag.putInt("pose", npcPose());
        if (home != null) tag.putLong("home", home.asLong());
        tag.putBoolean("hostile", hostileOverride);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("npc")) setNpcId(tag.getString("npc"));
        if (tag.hasUUID("owner")) ownerId = tag.getUUID("owner");
        order = tag.getInt("order");
        setNpcPose(tag.getInt("pose"));
        if (tag.contains("home")) home = BlockPos.of(tag.getLong("home"));
        hostileOverride = tag.getBoolean("hostile");
    }

    @Override
    public boolean removeWhenFarAway(double dist) { return false; }

    // ---------------- goals ----------------

    private static final class FollowOwnerGoal extends Goal {
        private final FvNpcEntity npc;
        FollowOwnerGoal(FvNpcEntity npc) { this.npc = npc; setFlags(EnumSet.of(Flag.MOVE)); }
        private ServerPlayer owner() {
            return npc.ownerId == null || !(npc.level() instanceof ServerLevel sl) ? null : (sl.getPlayerByUUID(npc.ownerId) instanceof ServerPlayer sp ? sp : null);
        }
        @Override public boolean canUse() { ServerPlayer o = owner(); return o != null && npc.order == 0 && npc.distanceToSqr(o) > 25 && npc.getTarget() == null; }
        @Override public boolean canContinueToUse() { ServerPlayer o = owner(); return o != null && npc.order == 0 && npc.distanceToSqr(o) > 9 && npc.getTarget() == null; }
        @Override public void tick() {
            ServerPlayer o = owner();
            if (o == null) return;
            npc.getNavigation().moveTo(o, 1.15);
            if (npc.distanceToSqr(o) > 900) npc.teleportTo(o.getX() + 1, o.getY(), o.getZ() + 1);
        }
    }

    private static final class GoHomeGoal extends Goal {
        private final FvNpcEntity npc;
        GoHomeGoal(FvNpcEntity npc) { this.npc = npc; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return npc.home != null && npc.ownerId == null && npc.getTarget() == null && npc.distanceToSqr(Vec3.atCenterOf(npc.home)) > 36 && npc.getRandom().nextInt(40) == 0; }
        @Override public void start() { npc.getNavigation().moveTo(npc.home.getX() + 0.5, npc.home.getY(), npc.home.getZ() + 0.5, 0.9); }
    }

    /** Ranged NPCs (Kaina) shoot frost-tipped arrows at their target. */
    private static final class IceBowGoal extends Goal {
        private final FvNpcEntity npc;
        IceBowGoal(FvNpcEntity npc) { this.npc = npc; setFlags(EnumSet.of(Flag.LOOK)); }
        @Override public boolean canUse() { LivingEntity t = npc.getTarget(); return npc.def().ranged() && t != null && t.isAlive() && npc.distanceToSqr(t) > 9 && npc.hasLineOfSight(t); }
        @Override public void tick() {
            LivingEntity t = npc.getTarget();
            if (t == null) return;
            npc.getLookControl().setLookAt(t, 30, 30);
            if (npc.shotCooldown > 0) return;
            npc.shotCooldown = 22;
            Arrow a = new Arrow(npc.level(), npc);
            double dx = t.getX() - npc.getX(), dy = t.getY(0.33) - a.getY(), dz = t.getZ() - npc.getZ();
            a.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.1, dz, 2.0f, 1.5f);
            a.setBaseDamage(4.0);
            npc.level().addFreshEntity(a);
            if (npc.level() instanceof ServerLevel sl) {
                sl.sendParticles(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, a.getX(), a.getY(), a.getZ(), 8, 0.1, 0.1, 0.1, 0.02);
                sl.playSound(null, npc.getX(), npc.getY(), npc.getZ(), net.minecraft.sounds.SoundEvents.CROSSBOW_SHOOT, net.minecraft.sounds.SoundSource.NEUTRAL, 0.8f, 1.2f);
            }
        }
    }

    static boolean unused(FvCap c) { return false; }
}
