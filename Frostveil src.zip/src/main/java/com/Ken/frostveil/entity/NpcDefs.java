package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.CharacterProfile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Who everyone is: look, stats, role, home, daily schedule, special ability and what they say.
 * Looks follow the lore notes; anything not stated there is a placeholder you can retune here.
 * A schedule is a string "from-to:activity@place;..." in game hours (0-24, 6 = sunrise). Places are POI names, or $home / $work.
 * Activities: sleep, eat, cook, feed, work, train, patrol, guard, play, gather, wander.
 */
public final class NpcDefs {
    public record Entry(int from, int to, String act, String poi) {
        public boolean covers(int h) { return from <= to ? (h >= from && h < to) : (h >= from || h < to); }
    }

    public record Def(String id, CharacterProfile look, float scale, float health, float damage, boolean friendly, boolean ranged, String weapon,
                      String role, String home, String ability, boolean unique, boolean randomLook, List<Entry> sched) {
        public Entry at(int hour) {
            for (Entry e : sched) if (e.covers(hour)) return e;
            return null;
        }
        public boolean civilian() { return friendly && damage < 3.5f; }
    }

    /** Who likes to visit whom (small talk, greetings). */
    private static final Map<String, String> FRIENDS = Map.of("kaina", "yu", "yu", "kaina", "awi", "fang", "fang", "awi", "igor", "tetsu", "tetsu", "igor", "drayt", "awi");

    public static String friend(String id) { return FRIENDS.getOrDefault(id, ""); }

    private static final Map<String, Def> DEFS = new HashMap<>();
    private static final Map<String, String[]> PHRASES = new HashMap<>();

    private NpcDefs() {}

    public static Def get(String id) { return DEFS.getOrDefault(id, DEFS.get("villager")); }
    public static boolean exists(String id) { return DEFS.containsKey(id); }
    public static Iterable<Def> all() { return DEFS.values(); }

    public static String[] phrases(String key) { return PHRASES.getOrDefault(key, PHRASES.get("generic")); }

    private static List<Entry> sched(String spec) {
        List<Entry> out = new ArrayList<>();
        if (spec == null || spec.isEmpty()) return out;
        for (String part : spec.split(";")) {
            String[] a = part.split(":");
            String[] t = a[0].split("-");
            String[] b = a[1].split("@");
            out.add(new Entry(Integer.parseInt(t[0]), Integer.parseInt(t[1]), b[0], b.length > 1 ? b[1] : "center"));
        }
        return out;
    }

    private static CharacterProfile p(String body, String skin, String eye, String hair, String hairColor, String coat, String coatColor, String shirt) {
        CharacterProfile c = new CharacterProfile();
        c.bodyType = body; c.skin = skin; c.eyeColor = eye; c.hair = hair; c.hairColor = hairColor; c.highlight = "none";
        c.coat = coat; c.coatColor = coatColor; c.shirtColor = shirt; c.trim = "silver"; c.waistBag = false; c.boots = "waterproof";
        return c;
    }

    /** Unique look for each generic villager, stable per seed. */
    public static CharacterProfile randomLook(Def d, int seed) {
        Random r = new Random(seed * 31L + d.id().hashCode());
        CharacterProfile c = d.look().copy();
        c.skin = CharacterProfile.SKIN.get(r.nextInt(5));
        c.eyeColor = CharacterProfile.EYE.get(r.nextInt(5));
        c.hair = CharacterProfile.HAIR.get(r.nextInt(CharacterProfile.HAIR.size() - 1));
        c.hairColor = CharacterProfile.HAIR_COLOR.get(r.nextInt(CharacterProfile.HAIR_COLOR.size()));
        c.bodyType = r.nextBoolean() ? "male" : "female";
        c.brows = CharacterProfile.BROWS.get(r.nextInt(3));
        c.eyeShape = CharacterProfile.EYE_SHAPE.get(r.nextInt(3));
        c.shirtColor = CharacterProfile.SHIRT_COLOR.get(r.nextInt(CharacterProfile.SHIRT_COLOR.size()));
        if (!d.role().equals("guard")) c.coatColor = CharacterProfile.COAT_COLOR.get(r.nextInt(CharacterProfile.COAT_COLOR.size()));
        return c;
    }

    private static void add(String id, CharacterProfile look, float scale, float health, float damage, boolean friendly, boolean ranged, String weapon,
                            String role, String home, String ability, boolean unique, boolean randomLook, String sched) {
        DEFS.put(id, new Def(id, look, scale, health, damage, friendly, ranged, weapon, role, home, ability, unique, randomLook, sched(sched)));
    }

    static {
        String[] gen = {"Hmm.", "Cold today.", "Stay warm.", "Have you eaten?", "Tatsuma is home."};
        PHRASES.put("generic", gen);
        PHRASES.put("child", new String[]{"Catch me!", "Snowball fight!", "Is there soup yet?", "Awi is so strong!", "Shimoro, play with us!", "Haha!"});
        PHRASES.put("farmer", new String[]{"The soil is frozen but the roots hold.", "Good harvest this year.", "Soma wood grows faster than weeds.", "My back..."});
        PHRASES.put("merchant", new String[]{"Fresh goods from Green Earthia!", "Spices from Vulcred, hot enough to wake the dead!", "Frozen fish, sliced thin!", "Best prices in the north!"});
        PHRASES.put("guard", new String[]{"All quiet.", "Eyes on the road.", "Nothing gets past the fence.", "Stay inside after dark."});
        PHRASES.put("smith", new String[]{"Fire from Vulcred, steel from Azora.", "*clang*", "A blade needs patience.", "Mind the sparks."});
        PHRASES.put("hunter", new String[]{"Tracks near the forest.", "The beasts are restless.", "Don't go past the Soma trees alone."});
        PHRASES.put("cook", new String[]{"Soup is almost ready.", "Eat while it is hot.", "Wash your hands first."});
        PHRASES.put("elder", new String[]{"Peace is built, not found.", "Tatsuma belongs to those who want no kings.", "Watch the road."});
        PHRASES.put("guardian", new String[]{"Hmph.", "Again. Once more.", "I will protect this place."});
        PHRASES.put("trainer", new String[]{"Breathe.", "Again.", "Mountains do not move because you shout."});
        PHRASES.put("raider", new String[]{"Find the heir!", "Where is the boy?", "In the name of the true king!", "The order must be restored!", "Nothing stops the Ash Knights!", "Search every house!"});
        PHRASES.put("alarm", new String[]{"Ash Knights!", "To arms!", "Get the children inside!", "They are at the gate!"});

        add("villager", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "sand", "grey"), 1f, 20, 2, true, false, "", "villager", "house_w", "", false, true, "6-8:eat@kaina_table;8-18:wander@center;18-20:gather@center;20-6:sleep@$home");

        CharacterProfile awi = p("female", "yellow", "green", "ponytail", "black", "wool_shirt", "forest", "charcoal");
        awi.earring = true; awi.trim = "gold"; awi.build = "athletic";
        add("awi", awi, 0.97f, 60, 6, true, false, "minecraft:trident", "guardian", "awi_house", "spear", true, false,
                "5-8:train@awi_table;8-9:eat@kaina_table;9-12:train@awi_table;12-14:feed@stable;14-18:patrol@center;18-20:gather@council;20-22:wander@center;22-5:sleep@$home");
        CharacterProfile kaina = p("female", "fair", "brown", "curly", "white", "long_coat", "sand", "cream");
        add("kaina", kaina, 0.95f, 70, 4, true, true, "minecraft:bow", "cook", "kaina_house", "bow", true, false,
                "5-6:cook@kaina_table;6-8:feed@kaina_table;8-11:wander@center;11-13:cook@kaina_table;13-17:work@market;17-19:cook@kaina_table;19-21:gather@center;21-5:sleep@$home");
        CharacterProfile yu = p("male", "yellow", "brown", "messy", "white", "long_coat", "ice", "navy");
        yu.goggles = true;
        add("yu", yu, 0.96f, 90, 7, true, false, "", "elder", "yu_house", "frost_burst", true, false,
                "6-8:wander@center;8-12:work@council;12-13:eat@kaina_table;13-16:wander@forge;16-19:work@council;19-21:gather@center;21-6:sleep@$home");
        CharacterProfile fang = p("male", "brown", "brown", "bald", "black", "wool_shirt", "charcoal", "charcoal");
        fang.build = "heavy";
        add("fang", fang, 1.12f, 120, 8, true, false, "", "trainer", "yu_house", "slam", true, false,
                "6-9:train@awi_table;9-12:work@council;12-14:eat@kaina_table;14-17:train@awi_table;17-21:gather@center;21-6:sleep@$home");
        CharacterProfile drayt = p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "sand", "grey");
        add("drayt", drayt, 0.8f, 30, 1, true, false, "", "child", "house_w", "", true, false,
                "6-7:eat@kaina_table;7-12:work@forge;12-13:eat@kaina_table;13-18:play@center;18-20:gather@market;20-6:sleep@$home");
        CharacterProfile igor = p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "charcoal", "grey");
        igor.goggles = true;
        add("igor", igor, 1f, 50, 3, true, false, "minecraft:iron_pickaxe", "smith", "house_sw", "", true, false,
                "6-7:eat@kaina_table;7-12:work@forge;12-13:eat@kaina_table;13-19:work@forge;19-21:gather@center;21-6:sleep@$home");
        CharacterProfile tetsu = p("male", "brown", "grey", "messy", "black", "long_coat", "charcoal", "charcoal");
        tetsu.scarf = "white";
        add("tetsu", tetsu, 0.94f, 40, 2, true, false, "", "smith", "house_s", "", true, false,
                "7-12:work@forge;12-13:eat@kaina_table;13-18:work@forge;18-21:wander@forge;21-7:sleep@$home");
        CharacterProfile ryo = p("male", "pale", "grey", "ponytail", "black", "wool_shirt", "sand", "grey");
        add("ryo", ryo, 1.0f, 80, 8, true, false, "frostveil:katana", "scout", "yu_house", "wind_dash", true, false, "");
        CharacterProfile fargas = p("male", "yellow", "violet", "long_hanging", "black", "long_coat", "charcoal", "charcoal");
        fargas.scarf = "none";
        add("fargas", fargas, 1.02f, 140, 4, false, false, "", "stranger", "", "", true, false, "");
        CharacterProfile ash = p("male", "pale", "brown", "messy", "black", "long_coat", "charcoal", "grey");
        ash.boots = "plain";
        add("ash_knight", ash, 1f, 28, 4, false, false, "minecraft:iron_sword", "raider", "", "", false, true, "");

        // generic villagers (random looks, schedules, bubbles)
        add("child", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "forest", "grey"), 0.75f, 14, 0, true, false, "", "child", "kaina_house", "", false, true,
                "6-7:eat@kaina_table;7-12:play@center;12-13:eat@kaina_table;13-18:play@center;18-20:gather@kaina_table;20-6:sleep@$home");
        add("bully", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "forest", "grey"), 0.8f, 10, 0, true, false, "", "child", "kaina_house", "", false, true, "");
        add("farmer", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "sand", "green"), 1f, 24, 2, true, false, "minecraft:iron_hoe", "farmer", "house_ne", "", false, true,
                "6-7:eat@kaina_table;7-12:work@farm;12-13:eat@kaina_table;13-18:work@farm;18-20:gather@center;20-6:sleep@$home");
        add("merchant", p("male", "tan", "brown", "wolf_cut", "grey", "long_coat", "crimson", "cream"), 1f, 24, 1, true, false, "", "merchant", "house_market", "", false, true,
                "7-19:work@market;19-20:gather@center;20-7:sleep@$home");
        add("guard", p("male", "pale", "blue", "messy", "silver", "long_coat", "midnight", "navy"), 1f, 40, 6, true, false, "minecraft:iron_sword", "guard", "house_se", "", false, true,
                "6-18:patrol@center;18-22:guard@$work;22-6:sleep@$home");
        add("hunter", p("male", "tan", "green", "wolf_cut", "brown", "cloak", "forest", "green"), 1f, 30, 5, true, true, "minecraft:bow", "hunter", "house_w", "bow", false, true,
                "5-6:wander@south_gate;6-17:wander@south_gate;17-20:gather@kaina_table;20-5:sleep@$home");
        add("smith", p("male", "brown", "brown", "messy", "black", "wool_shirt", "charcoal", "grey"), 1.05f, 40, 3, true, false, "minecraft:iron_pickaxe", "smith", "house_w", "", false, true,
                "6-7:eat@kaina_table;7-12:work@forge;12-13:eat@kaina_table;13-19:work@forge;19-21:gather@center;21-6:sleep@$home");
        add("gate_knight", p("male", "pale", "blue", "messy", "silver", "long_coat", "midnight", "navy"), 1f, 40, 5, true, false, "minecraft:iron_sword", "guard", "", "", false, true, "");
    }
}
