package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.CharacterProfile;
import java.util.HashMap;
import java.util.Map;

/**
 * Looks and basic combat stats for story NPCs. Looks come from the lore character notes (E1-E5);
 * anything not stated there is a placeholder the author can retune here. Skins are painted at runtime from the profile
 * unless a PNG exists at assets/frostveil/textures/entity/npc/<id>.png (drop your own art in to override).
 */
public final class NpcDefs {
    public record Def(String id, CharacterProfile look, float scale, float health, float damage, boolean friendly, boolean ranged, String weapon) {}

    private static final Map<String, Def> DEFS = new HashMap<>();

    private NpcDefs() {}

    public static Def get(String id) {
        return DEFS.getOrDefault(id, DEFS.get("villager"));
    }

    public static boolean exists(String id) { return DEFS.containsKey(id); }

    private static CharacterProfile p(String body, String skin, String eye, String hair, String hairColor, String coat, String coatColor, String shirt) {
        CharacterProfile c = new CharacterProfile();
        c.bodyType = body; c.skin = skin; c.eyeColor = eye; c.hair = hair; c.hairColor = hairColor; c.highlight = "none";
        c.coat = coat; c.coatColor = coatColor; c.shirtColor = shirt; c.trim = "silver"; c.waistBag = false; c.boots = "waterproof";
        return c;
    }

    private static void add(String id, CharacterProfile look, float scale, float health, float damage, boolean friendly, boolean ranged, String weapon) {
        DEFS.put(id, new Def(id, look, scale, health, damage, friendly, ranged, weapon));
    }

    static {
        add("villager", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "sand", "grey"), 1f, 20, 2, true, false, "");

        CharacterProfile awi = p("female", "yellow", "green", "ponytail", "black", "wool_shirt", "forest", "charcoal");
        awi.earring = true; awi.trim = "gold"; awi.build = "athletic";
        add("awi", awi, 0.97f, 40, 5, true, false, "minecraft:iron_spear_placeholder"); // spear: see FvNpcEntity.weaponFor

        CharacterProfile kaina = p("female", "fair", "brown", "curly", "white", "long_coat", "sand", "cream");
        add("kaina", kaina, 0.95f, 60, 4, true, true, "minecraft:bow");

        CharacterProfile yu = p("male", "yellow", "brown", "messy", "white", "long_coat", "ice", "navy");
        yu.goggles = true;
        add("yu", yu, 0.96f, 80, 7, true, false, "");

        CharacterProfile fang = p("male", "brown", "brown", "bald", "black", "wool_shirt", "charcoal", "charcoal");
        fang.build = "heavy";
        add("fang", fang, 1.12f, 120, 8, true, false, "");

        CharacterProfile drayt = p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "crimson", "grey");
        add("drayt", drayt, 0.8f, 20, 1, true, false, "");

        CharacterProfile igor = p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "charcoal", "grey");
        igor.goggles = true;
        add("igor", igor, 1f, 40, 3, true, false, "minecraft:iron_pickaxe");

        CharacterProfile tetsu = p("male", "brown", "grey", "messy", "black", "long_coat", "charcoal", "charcoal");
        tetsu.scarf = "white";
        add("tetsu", tetsu, 0.94f, 30, 2, true, false, "");

        CharacterProfile ryo = p("male", "pale", "grey", "ponytail", "black", "wool_shirt", "sand", "grey");
        ryo.scarf = "none";
        add("ryo", ryo, 1.0f, 60, 7, true, false, "minecraft:iron_sword");

        CharacterProfile fargas = p("male", "yellow", "violet", "long_hanging", "black", "long_coat", "charcoal", "charcoal");
        add("fargas", fargas, 1.02f, 140, 4, false, false, "");

        CharacterProfile ash = p("male", "pale", "brown", "messy", "black", "long_coat", "charcoal", "grey");
        ash.boots = "plain";
        add("ash_knight", ash, 1f, 30, 5, false, false, "minecraft:iron_sword");

        add("bully", p("male", "yellow", "brown", "messy", "brown", "wool_shirt", "forest", "grey"), 0.8f, 10, 0, true, false, "");
        add("gate_knight", p("male", "pale", "blue", "messy", "silver", "long_coat", "midnight", "navy"), 1f, 40, 5, true, false, "minecraft:iron_sword");
    }
}
