package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.story.MissionManager;
import java.util.EnumSet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Fargas (Asvar), Arc 1 mini-boss. Smoke body: he slips behind you ("mist step"), flings serrated poison shards (violet drop:
 * dizziness, pain, blurred screen) and cannot be truly hurt in the scripted fights.
 * mode 0 = overwhelms the player (scripted loss), mode 1 = village raid (retreats after a time).
 */
public class FargasEntity extends Monster {
    private int mode = 0;
    private int limit = 900;
    private int mistCd = 60, shardCd = 40;

    public FargasEntity(EntityType<? extends FargasEntity> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 140).add(Attributes.MOVEMENT_SPEED, 0.33).add(Attributes.ATTACK_DAMAGE, 3).add(Attributes.FOLLOW_RANGE, 32);
    }

    public void script(int mode, int limitTicks) { this.mode = mode; this.limit = limitTicks; }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MistStep(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.getEntity() instanceof Player) amount = Math.min(amount, 0.4f); // he is not hurt in scripted fights
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 3; i++) level().addParticle(ParticleTypes.LARGE_SMOKE, getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0, 0.02, 0);
            if (random.nextInt(6) == 0) level().addParticle(ParticleTypes.WITCH, getRandomX(0.4), getY() + 1.6, getRandomZ(0.4), 0, 0, 0);
            return;
        }
        LivingEntity t = getTarget();
        if (t != null && --shardCd <= 0 && distanceToSqr(t) > 16 && distanceToSqr(t) < 400) {
            shardCd = 45;
            Arrow a = new Arrow(level(), this);
            double dx = t.getX() - getX(), dy = t.getY(0.4) - a.getY(), dz = t.getZ() - getZ();
            a.shoot(dx, dy, dz, 1.8f, 1.0f);
            a.setBaseDamage(2.0);
            a.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0));
            a.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            level().addFreshEntity(a);
        }
        if (tickCount > limit) end(t);
        else if (mode == 0 && t instanceof ServerPlayer p && p.getHealth() < p.getMaxHealth() * 0.4f) end(p);
    }

    private void end(LivingEntity t) {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 40, 0.5, 0.8, 0.5, 0.05);
            for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(40))) {
                MissionManager.event(p, mode == 0 ? "fargas_overwhelm" : "fargas_retreat", "");
            }
        }
        discard();
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putInt("mode", mode); t.putInt("limit", limit); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); mode = t.getInt("mode"); limit = t.getInt("limit") == 0 ? 900 : t.getInt("limit"); }

    /** Slip behind the target in a puff of smoke. */
    private static final class MistStep extends Goal {
        private final FargasEntity f;
        MistStep(FargasEntity f) { this.f = f; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { LivingEntity t = f.getTarget(); return t != null && --f.mistCd <= 0 && f.distanceToSqr(t) > 9 && f.distanceToSqr(t) < 400; }
        @Override public void start() {
            LivingEntity t = f.getTarget();
            f.mistCd = 90;
            Vec3 back = t.position().subtract(t.getLookAngle().multiply(1, 0, 1).normalize().scale(2.2));
            if (f.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, f.getX(), f.getY() + 1, f.getZ(), 25, 0.4, 0.7, 0.4, 0.03);
                f.teleportTo(back.x, t.getY(), back.z);
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, f.getX(), f.getY() + 1, f.getZ(), 25, 0.4, 0.7, 0.4, 0.03);
            }
        }
        @Override public boolean canContinueToUse() { return false; }
    }

    static boolean unused(FvCap c) { return false; }
}
