package com.Ken.frostveil.entity;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.story.MissionManager;
import java.util.EnumSet;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Fargas (Asvar), Arc 1 mini-boss. Smoke body: he slips behind you ("mist step"), flings serrated poison shards (violet drop:
 * dizziness, pain, blurred screen) and cannot be truly hurt in the scripted fights.
 * mode 0 = overwhelms the player (scripted loss), mode 1 = village raid (retreats after a time).
 */
public class FargasEntity extends PathfinderMob {
    private int mode = 0;
    private int limit = 900;
    private int mistCd = 60, shardCd = 40;
    private final ServerBossEvent bar = new ServerBossEvent(Component.literal("The Stranger"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_6);

    public FargasEntity(EntityType<? extends FargasEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomName(Component.literal("The Stranger"));
        setCustomNameVisible(false);
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bar.removePlayer(p); }
    @Override public void remove(RemovalReason reason) { bar.removeAllPlayers(); super.remove(reason); }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 140).add(Attributes.MOVEMENT_SPEED, 0.33).add(Attributes.ATTACK_DAMAGE, 3).add(Attributes.FOLLOW_RANGE, 32);
    }

    public void script(int mode, int limitTicks) {
        this.mode = mode; this.limit = limitTicks;
        setNoAi(mode == 2); // mode 2 = cutscene: he only stands and watches
        if (mode != 2) tickCount = 0;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MistStep(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        targetSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        amount = Math.min(amount, 0.4f); // he is not really hurt in scripted fights (by anyone)
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            for (int i = 0; i < 3; i++) level().addParticle(ParticleTypes.LARGE_SMOKE, getRandomX(0.6), getRandomY(), getRandomZ(0.6), 0, 0.02, 0);
            if (random.nextInt(6) == 0) level().addParticle(ParticleTypes.WITCH, getRandomX(0.4), getY() + 1.6, getRandomZ(0.4), 0, 0, 0);
            return;
        }
        if (tickCount == 1 && level() instanceof ServerLevel sl0) { // arrival: smoke and a sound you feel before you see him
            sl0.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 60, 0.6, 1.0, 0.6, 0.06);
            sl0.playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.2f, 0.5f);
            sl0.playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 1.5f, 0.8f);
        }
        bar.setProgress(Mth.clamp(1f - tickCount / (float) Math.max(1, limit), 0f, 1f));
        LivingEntity t = getTarget();
        if (t != null && --shardCd <= 0 && distanceToSqr(t) > 16 && distanceToSqr(t) < 400) {
            shardCd = 45;
            Arrow a = new Arrow(level(), this);
            double dx = t.getX() - getX(), dy = t.getY(0.4) - a.getY(), dz = t.getZ() - getZ();
            a.shoot(dx, dy, dz, 1.8f, 1.0f);
            a.setBaseDamage(2.0);
            a.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0));
            a.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0));
            level().addFreshEntity(a);
        }
        if (mode == 2) return;
        if (tickCount > limit) end(t);
        else if (mode == 0 && t instanceof ServerPlayer p && p.getHealth() < p.getMaxHealth() * 0.4f) end(p);
        else if (mode == 0 && t == null && tickCount > 200) { // nobody to chase: pick the nearest player so the scene cannot stall
            Player near = level().getNearestPlayer(this, 40);
            if (near != null) setTarget(near);
        }
    }

    private void end(LivingEntity t) {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 40, 0.5, 0.8, 0.5, 0.05);
            for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(40))) {
                MissionManager.event(p, mode == 0 ? "fargas_overwhelm" : "fargas_retreat", "");
            }
        }
        discard();
    }

    @Override public void addAdditionalSaveData(CompoundTag t) { super.addAdditionalSaveData(t); t.putInt("mode", mode); t.putInt("limit", limit); }
    @Override public void readAdditionalSaveData(CompoundTag t) { super.readAdditionalSaveData(t); mode = t.getInt("mode"); limit = t.getInt("limit") == 0 ? 900 : t.getInt("limit"); }

    /** Slip behind the target in a puff of smoke. */
    private static final class MistStep extends Goal {
        private final FargasEntity f;
        MistStep(FargasEntity f) { this.f = f; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { LivingEntity t = f.getTarget(); return t != null && --f.mistCd <= 0 && f.distanceToSqr(t) > 9 && f.distanceToSqr(t) < 400; }
        @Override public void start() {
            LivingEntity t = f.getTarget();
            f.mistCd = 90;
            Vec3 back = t.position().subtract(t.getLookAngle().multiply(1, 0, 1).normalize().scale(2.2));
            if (f.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, f.getX(), f.getY() + 1, f.getZ(), 25, 0.4, 0.7, 0.4, 0.03);
                f.teleportTo(back.x, t.getY(), back.z);
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, f.getX(), f.getY() + 1, f.getZ(), 25, 0.4, 0.7, 0.4, 0.03);
            }
        }
        @Override public boolean canContinueToUse() { return false; }
    }

    static boolean unused(FvCap c) { return false; }
}
