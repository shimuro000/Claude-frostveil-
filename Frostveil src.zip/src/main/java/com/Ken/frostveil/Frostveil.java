package com.Ken.frostveil;

import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModBlocks;
import com.Ken.frostveil.registry.ModEffects;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/** Frostveil: story-driven action RPG built on the EIU system. */
@Mod(Fv.ID)
public final class Frostveil {
    public static final Logger LOG = LogUtils.getLogger();

    public Frostveil() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        ModEntities.TYPES.register(bus);
        ModEffects.EFFECTS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(FvNet::init);
    }
}
