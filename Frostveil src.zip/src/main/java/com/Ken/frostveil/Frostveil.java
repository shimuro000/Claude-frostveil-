package com.Ken.frostveil;

import com.Ken.frostveil.capability.EnergyCapabilityEvents;
import com.Ken.frostveil.capability.StoryCapabilityEvents;
import com.Ken.frostveil.command.FrostveilCommand;
import com.Ken.frostveil.energy.EnergyConfig;
import com.Ken.frostveil.energy.EnergyEngine;
import com.Ken.frostveil.network.FrostveilNetwork;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** Frostveil entry point. Common (client + server) code only; client code lives in the client package. */
@Mod(Frostveil.MOD_ID)
public class Frostveil {
    public static final String MOD_ID = "frostveil";

    public Frostveil() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);
        modBus.addListener(StoryCapabilityEvents::registerCapabilities);
        modBus.addListener(EnergyCapabilityEvents::registerCapabilities);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, EnergyConfig.SPEC);

        MinecraftForge.EVENT_BUS.register(StoryCapabilityEvents.class);
        MinecraftForge.EVENT_BUS.register(EnergyCapabilityEvents.class);
        MinecraftForge.EVENT_BUS.register(EnergyEngine.class);
        MinecraftForge.EVENT_BUS.register(FrostveilCommand.class);
    }

    private void commonSetup(final FMLCommonSetupEvent event) { event.enqueueWork(FrostveilNetwork::register); }
}
