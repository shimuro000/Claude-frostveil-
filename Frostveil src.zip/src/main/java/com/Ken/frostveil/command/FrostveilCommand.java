package com.Ken.frostveil.command;

import com.Ken.frostveil.capability.PlayerEnergyData;
import com.Ken.frostveil.energy.ChannelState;
import com.Ken.frostveil.energy.EnergyEngine;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Test and admin commands (permission level 2). They stand in for the story triggers until the story engine
 * exists: /frostveil awaken | aura N | learn skin_sense|forge|cutoff|infuse STAGE | closure true|false | flow
 */
public final class FrostveilCommand {
    private FrostveilCommand() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("frostveil").requires(s -> s.hasPermission(2))
            .then(Commands.literal("awaken").executes(c -> { EnergyEngine.awaken(c.getSource().getPlayerOrException()); return 1; }))
            .then(Commands.literal("flow").executes(c -> { EnergyEngine.startFlow(c.getSource().getPlayerOrException()); return 1; }))
            .then(Commands.literal("closure").then(Commands.argument("on", BoolArgumentType.bool()).executes(c -> {
                EnergyEngine.setChannelState(c.getSource().getPlayerOrException(),
                        BoolArgumentType.getBool(c, "on") ? ChannelState.FORCED_CLOSURE : ChannelState.NORMAL);
                return 1; })))
            .then(Commands.literal("aura").then(Commands.argument("amount", IntegerArgumentType.integer(0, 100000)).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                PlayerEnergyData d = EnergyEngine.data(p);
                if (d == null) return 0;
                d.aura = Math.min(d.quantity, IntegerArgumentType.getInteger(c, "amount"));
                EnergyEngine.sync(p);
                return 1; })))
            .then(Commands.literal("learn")
                .then(Commands.argument("skill", StringArgumentType.word())
                .then(Commands.argument("stage", IntegerArgumentType.integer(0, 5)).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    PlayerEnergyData d = EnergyEngine.data(p);
                    if (d == null) return 0;
                    int st = IntegerArgumentType.getInteger(c, "stage");
                    switch (StringArgumentType.getString(c, "skill")) {
                        case "skin_sense" -> d.skinSenseStage = st;
                        case "forge" -> d.forgeStage = st;
                        case "cutoff" -> d.cutoffStage = st;
                        case "infuse" -> d.infuseStage = st;
                        default -> { c.getSource().sendFailure(Component.literal("skin_sense, forge, cutoff or infuse")); return 0; }
                    }
                    EnergyEngine.sync(p);
                    return 1; })))));
    }
}
