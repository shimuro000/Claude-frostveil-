package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.entity.EiuBeastEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Rules of the Frostveil world: no vanilla monsters (zombies, creepers, skeletons, spiders, phantoms...). Only Frostveil's own enemies exist. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class WorldRules {
    private WorldRules() {}

    @SubscribeEvent
    public static void join(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide()) return;
        if (!e.getLevel().dimension().equals(Fv.WORLD)) return;
        if (e.getEntity() instanceof Enemy && !(e.getEntity() instanceof EiuBeastEntity)) e.setCanceled(true);
    }
}
