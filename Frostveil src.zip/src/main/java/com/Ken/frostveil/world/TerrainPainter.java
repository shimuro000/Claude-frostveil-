package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Frostveil's own terrain look. The land is shaped by vanilla's tall "amplified" noise (jagged peaks, steep slopes, hill valleys) and every new chunk
 * is then repainted in a manga style: white snow blankets and wind-blown drifts, dark craggy rock on steep faces and high ridges,
 * vanilla trees stripped into bare, snow-laden winter trees with branches, and new bare birch / dark trees in cold woods.
 * Each chunk is painted once (remembered in saved data). The area around Tatsuma is left alone.
 */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class TerrainPainter {
    public static final class Done extends SavedData {
        final Set<Long> done = new HashSet<>();
        public static Done load(CompoundTag t) { Done d = new Done(); for (long l : t.getLongArray("d")) d.done.add(l); return d; }
        @Override public CompoundTag save(CompoundTag t) { long[] a = new long[done.size()]; int i = 0; for (long l : done) a[i++] = l; t.putLongArray("d", a); return t; }
    }

    private TerrainPainter() {}

    @SubscribeEvent
    public static void chunkLoad(ChunkEvent.Load e) {
        if (e.getLevel().isClientSide() || !(e.getLevel() instanceof ServerLevel sl) || !sl.dimension().equals(Fv.WORLD)) return;
        if (!(e.getChunk() instanceof LevelChunk chunk) || !sl.getServer().isSameThread()) return;
        ChunkPos cp = chunk.getPos();
        Done d = sl.getDataStorage().computeIfAbsent(Done::load, Done::new, "frostveil_terrain");
        if (!d.done.add(cp.toLong())) return;
        d.setDirty();
        int mx = cp.getMiddleBlockX(), mz = cp.getMiddleBlockZ();
        if (mx * mx + mz * mz < 64 * 64) return; // Tatsuma and its flattened ground
        try { paint(sl, chunk); } catch (RuntimeException ex) { com.Ken.frostveil.Frostveil.LOG.error("Terrain painter failed on chunk {}: {}", cp, ex.toString()); }
    }

    // ---------------------------------------------------------------- small value noise
    private static float hash(int x, int z, long seed) {
        long h = x * 341873128712L + z * 132897987541L + seed * 0x9E3779B97F4A7C15L;
        h = (h ^ (h >>> 13)) * 1274126177L;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / 16777215f;
    }

    private static float vnoise(double x, double z, long seed) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        float fx = (float) (x - x0), fz = (float) (z - z0);
        fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz);
        float a = hash(x0, z0, seed), b = hash(x0 + 1, z0, seed), c = hash(x0, z0 + 1, seed), d = hash(x0 + 1, z0 + 1, seed);
        float t = a + (b - a) * fx, u = c + (d - c) * fx;
        return t + (u - t) * fz;
    }

    private static float fbm(double x, double z, long seed) {
        return 0.5f * vnoise(x / 48.0, z / 48.0, seed) + 0.3f * vnoise(x / 20.0, z / 20.0, seed + 1) + 0.2f * vnoise(x / 8.0, z / 8.0, seed + 2);
    }

    private static boolean natural(BlockState s) {
        return s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT) || s.is(Blocks.PODZOL) || s.is(Blocks.COARSE_DIRT) || s.is(Blocks.ROOTED_DIRT)
                || s.is(Blocks.GRAVEL) || s.is(Blocks.SAND) || s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW) || s.is(Blocks.MYCELIUM);
    }

    private static boolean rockLike(BlockState s) { return s.is(Blocks.STONE) || s.is(Blocks.ANDESITE) || s.is(Blocks.GRANITE) || s.is(Blocks.DIORITE) || s.is(Blocks.TUFF) || s.is(Blocks.DEEPSLATE); }

    // ---------------------------------------------------------------- the painter
    private static void paint(ServerLevel sl, LevelChunk chunk) {
        long seed = sl.getSeed();
        int minX = chunk.getPos().getMinBlockX(), minZ = chunk.getPos().getMinBlockZ();
        int[][] ground = new int[16][16];
        boolean[][] trunkDone = new boolean[16][16];
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        // 1. find the ground of every column, thin out vanilla trees into bare trees with branches
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = minX + lx, z = minZ + lz;
                int y = chunk.getHeight(Heightmap.Types.WORLD_SURFACE, lx, lz) - 1;
                while (y > sl.getMinBuildHeight()) {
                    m.set(x, y, z);
                    BlockState st = chunk.getBlockState(m);
                    if (st.is(BlockTags.LEAVES)) {
                        float r = hash(x, y * 31 + z, seed + 5);
                        chunk.setBlockState(m, r < 0.12f ? Blocks.SNOW_BLOCK.defaultBlockState() : Blocks.AIR.defaultBlockState(), false);
                    } else if (st.is(BlockTags.LOGS) && !trunkDone[lz][lx]) {
                        trunkDone[lz][lx] = true;
                        branches(chunk, lx, y, lz, minX, minZ, seed, st);
                    }
                    if (st.isAir() || st.is(BlockTags.LEAVES) || st.is(BlockTags.LOGS) || st.is(Blocks.SNOW) || st.is(Blocks.VINE)) { y--; continue; }
                    break;
                }
                m.set(x, y, z);
                BlockState g = chunk.getBlockState(m);
                ground[lz][lx] = (g.getFluidState().isEmpty() && !g.is(Blocks.ICE) && !g.is(Blocks.PACKED_ICE) && !g.is(Blocks.BLUE_ICE)) ? y : Integer.MIN_VALUE;
            }
        }
        // 2. surface: snow blankets and drifts on gentle ground, dark rock on steep or high ground
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int y = ground[lz][lx];
                if (y == Integer.MIN_VALUE) continue;
                int x = minX + lx, z = minZ + lz;
                int slope = 0;
                int[][] nb = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                for (int[] o : nb) { int nx = Math.max(0, Math.min(15, lx + o[0])), nz = Math.max(0, Math.min(15, lz + o[1])); if (ground[nz][nx] != Integer.MIN_VALUE) slope = Math.max(slope, Math.abs(y - ground[nz][nx])); }
                float n = fbm(x, z, seed), rockN = fbm(x + 500, z - 300, seed + 9);
                boolean rock = slope >= 3 || (y > 150 && rockN > 0.56f) || rockN > 0.8f;
                m.set(x, y, z);
                BlockState g = chunk.getBlockState(m);
                if (rock && (natural(g) || rockLike(g))) {
                    for (int d = 0; d < 3; d++) {
                        m.set(x, y - d, z);
                        float r = hash(x + d * 17, z - d * 13, seed + 21);
                        BlockState rs = r < 0.12f ? Blocks.BLACKSTONE.defaultBlockState() : (r < 0.3f ? Blocks.COBBLED_DEEPSLATE.defaultBlockState() : (r < 0.55f ? Blocks.ANDESITE.defaultBlockState() : (r < 0.8f ? Blocks.STONE.defaultBlockState() : Blocks.TUFF.defaultBlockState())));
                        BlockState cur = chunk.getBlockState(m);
                        if (natural(cur) || rockLike(cur)) chunk.setBlockState(m, rs, false);
                    }
                } else if (natural(g)) {
                    for (int d = 0; d < 3; d++) {
                        m.set(x, y - d, z);
                        if (natural(chunk.getBlockState(m))) chunk.setBlockState(m, Blocks.SNOW_BLOCK.defaultBlockState(), false);
                    }
                    if (slope <= 1 && n > 0.5f) { // wind-blown drifts
                        int h = 1 + (int) ((n - 0.5f) * 8f);
                        for (int d = 1; d <= Math.min(3, h); d++) { m.set(x, y + d, z); if (chunk.getBlockState(m).isAir()) chunk.setBlockState(m, Blocks.SNOW_BLOCK.defaultBlockState(), false); else break; }
                    }
                }
            }
        }
        // 3. new bare trees: many in cold woods, a few on open plains
        float wood = vnoise((minX + 8) / 96.0, (minZ + 8) / 96.0, seed + 77);
        int count = wood > 0.55f ? 6 + (int) (hash(minX, minZ, seed + 3) * 6) : (int) (hash(minX, minZ, seed + 4) * 3);
        for (int i = 0; i < count; i++) {
            int lx = 4 + (int) (hash(minX + i * 7, minZ, seed + 31) * 8), lz = 4 + (int) (hash(minX, minZ + i * 11, seed + 32) * 8);
            int y = ground[lz][lx];
            if (y == Integer.MIN_VALUE || y > 170) continue;
            int x = minX + lx, z = minZ + lz;
            m.set(x, y, z);
            BlockState g = chunk.getBlockState(m);
            if (!g.is(Blocks.SNOW_BLOCK) && !g.is(Blocks.GRASS_BLOCK) && !g.is(Blocks.DIRT)) continue;
            m.set(x, y + 1, z);
            if (!chunk.getBlockState(m).isAir()) continue;
            BlockState log = (hash(x, z, seed + 40) < 0.7f ? Blocks.BIRCH_LOG : Blocks.DARK_OAK_LOG).defaultBlockState();
            int h = 7 + (int) (hash(x, z, seed + 41) * 7);
            for (int t = 1; t <= h; t++) { m.set(x, y + t, z); chunk.setBlockState(m, log, false); }
            m.set(x, y + h + 1, z); chunk.setBlockState(m, Blocks.SNOW_BLOCK.defaultBlockState(), false);
            for (int level = h - 1; level >= h / 2; level -= 2) branches(chunk, lx, y + level, lz, minX, minZ, seed + level, log);
        }
    }

    /** Diagonal branches radiating from a trunk, snow resting on top. Only writes inside this chunk. */
    private static void branches(LevelChunk chunk, int lx, int y, int lz, int minX, int minZ, long seed, BlockState log) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        BlockState base = log.hasProperty(RotatedPillarBlock.AXIS) ? log : Blocks.SPRUCE_LOG.defaultBlockState();
        for (int[] d : dirs) {
            if (hash(minX + lx * 3 + d[0], minZ + lz * 5 + d[1] + y, seed + 61) < 0.45f) continue;
            int len = 2 + (int) (hash(minX + lx, minZ + lz + y, seed + 62) * 3);
            for (int i = 1; i <= len; i++) {
                int bx = lx + d[0] * i, bz = lz + d[1] * i;
                if (bx < 0 || bx > 15 || bz < 0 || bz > 15) break;
                int by = y + (i + 1) / 2;
                m.set(minX + bx, by, minZ + bz);
                if (!chunk.getBlockState(m).isAir() && !chunk.getBlockState(m).is(BlockTags.LEAVES)) break;
                chunk.setBlockState(m, base.setValue(RotatedPillarBlock.AXIS, d[0] != 0 ? net.minecraft.core.Direction.Axis.X : net.minecraft.core.Direction.Axis.Z), false);
                m.set(minX + bx, by + 1, minZ + bz);
                if (chunk.getBlockState(m).isAir()) chunk.setBlockState(m, i == len ? Blocks.SNOW_BLOCK.defaultBlockState() : Blocks.SNOW.defaultBlockState(), false);
            }
        }
    }
}
