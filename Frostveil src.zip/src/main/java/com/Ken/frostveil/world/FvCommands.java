package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.story.MissionManager;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /frostveil ... : menu for everyone, test and cheat commands for operators. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class FvCommands {
    private FvCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("frostveil")
                .then(Commands.literal("menu").executes(c -> { FvNet.toPlayer(c.getSource().getPlayerOrException(), new FvNet.ScreenMsg("mode_select")); return 1; }))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    FvData d = FvCap.get(p);
                    d.copyFrom(new FvData());
                    d.mark();
                    FvNet.syncData(p);
                    FvNet.broadcastAppearance(p);
                    FvNet.toPlayer(p, new FvNet.ScreenMsg("mode_select"));
                    return 1;
                }))
                .then(Commands.literal("unlock").requires(s -> s.hasPermission(2)).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    FvData d = FvCap.get(p);
                    d.unlockedForms = 7; d.unlockedPrims = 0xFF; d.awakened = true;
                    d.skinSenseStage = 4; d.forgeStage = 4; d.cutoffStage = 3; d.infuseStage = 3;
                    d.ctrlMental = 6; d.ctrlPhysical = 6; d.ctrlExternal = 6; d.quantity = 150; d.aura = 150; d.output = 25; d.points += 10;
                    d.mark();
                    c.getSource().sendSuccess(() -> Component.literal("Everything unlocked for testing."), false);
                    return 1;
                }))
                .then(Commands.literal("points").requires(s -> s.hasPermission(2)).then(Commands.argument("n", IntegerArgumentType.integer(1, 100)).executes(c -> {
                    FvData d = FvCap.get(c.getSource().getPlayerOrException());
                    d.points += IntegerArgumentType.getInteger(c, "n"); d.mark(); return 1;
                })))
                .then(Commands.literal("mission").requires(s -> s.hasPermission(2)).then(Commands.argument("id", StringArgumentType.word()).executes(c -> {
                    MissionManager.start(c.getSource().getPlayerOrException(), StringArgumentType.getString(c, "id")); return 1;
                })))
                .then(Commands.literal("tatsuma").requires(s -> s.hasPermission(2)).executes(c -> {
                    FrostveilWorld.startFree(c.getSource().getPlayerOrException()); return 1;
                }))
                .then(Commands.literal("aura").requires(s -> s.hasPermission(2)).executes(c -> {
                    FvData d = FvCap.get(c.getSource().getPlayerOrException()); d.aura = d.quantity; d.focus = 100; d.mark(); return 1;
                })));
    }

    static ShapeSpec unused() { return null; }
}
