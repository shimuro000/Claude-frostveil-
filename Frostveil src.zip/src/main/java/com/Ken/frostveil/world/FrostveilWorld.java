package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.eiu.ServerActions;
import com.Ken.frostveil.registry.ModItems;
import com.Ken.frostveil.story.MissionManager;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;

/** The story dimension (frostveil:world): where Tatsuma stands and where the story starts. */
public final class FrostveilWorld {
    private FrostveilWorld() {}

    /** Remembers that the village exists and the ground height it was built on. */
    public static final class Data extends SavedData {
        public boolean built = false;
        public int baseY = 64;
        public boolean damaged = false;
        public boolean raid = false;
        public final java.util.List<String> respawn = new java.util.ArrayList<>(); // slot keys of villagers that died and come back at dawn

        public static Data load(CompoundTag t) {
            Data d = new Data();
            d.built = t.getBoolean("built"); d.baseY = t.getInt("baseY"); d.damaged = t.getBoolean("damaged"); d.raid = t.getBoolean("raid");
            net.minecraft.nbt.ListTag l = t.getList("respawn", net.minecraft.nbt.Tag.TAG_STRING);
            for (int i = 0; i < l.size(); i++) d.respawn.add(l.getString(i));
            return d;
        }

        @Override
        public CompoundTag save(CompoundTag t) {
            t.putBoolean("built", built); t.putInt("baseY", baseY); t.putBoolean("damaged", damaged); t.putBoolean("raid", raid);
            net.minecraft.nbt.ListTag l = new net.minecraft.nbt.ListTag();
            for (String k : respawn) l.add(net.minecraft.nbt.StringTag.valueOf(k));
            t.put("respawn", l);
            return t;
        }
    }

    public static Data data(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(Data::load, Data::new, "frostveil_world");
    }

    /** Named places. Inside the village they sit on the flattened ground, outside they follow the terrain. */
    public static BlockPos poi(ServerLevel level, String name) {
        int[] o = TatsumaBuilder.POIS.get(name);
        if (o == null) return null;
        Data d = data(level);
        if (d.built && Math.abs(o[0]) <= 44 && Math.abs(o[1]) <= 44) return new BlockPos(o[0], d.baseY + 1, o[1]);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, o[0], o[1]);
        return new BlockPos(o[0], y, o[1]);
    }

    private static ServerLevel world(ServerPlayer p) {
        ServerLevel w = p.server.getLevel(Fv.WORLD);
        if (w == null) ServerActions.msg(p, "The Frostveil dimension is missing (data/frostveil/dimension). Check the mod jar.");
        return w;
    }

    public static void ensureVillage(ServerLevel w) {
        Data d = data(w);
        if (!d.built) {
            TatsumaBuilder.build(w, d);
            d.built = true;
            d.setDirty();
            Population.populate(w); // people are created ONCE, when the village is built
        }
        Population.ensure(w);
    }

    public static void startStory(ServerPlayer p) {
        ServerLevel w = world(p);
        if (w == null) return;
        ensureVillage(w);
        BlockPos at = poi(w, "spawn");
        p.teleportTo(w, at.getX() + 0.5, at.getY(), at.getZ() + 0.5, 90f, 0f);
        p.setRespawnPosition(Fv.WORLD, poi(w, "kaina_house"), 0f, true, false);
        w.setDayTime(23000L);
        w.setWeatherParameters(6000, 0, false, false);
        p.getInventory().clearContent();
        p.getInventory().add(new ItemStack(ModItems.WAIST_BAG.get()));
        p.getInventory().add(new ItemStack(ModItems.TENN_COIN.get(), 30));
        MissionManager.begin(p);
    }

    public static void startFree(ServerPlayer p) {
        ServerLevel w = world(p);
        if (w == null) return;
        ensureVillage(w);
        BlockPos at = poi(w, "center");
        p.teleportTo(w, at.getX() + 0.5, at.getY() + 3, at.getZ() + 3.5, 0f, 0f);
        p.setRespawnPosition(Fv.WORLD, poi(w, "kaina_house"), 0f, true, false);
        p.getInventory().add(new ItemStack(ModItems.SMALL_AXE.get()));
        p.getInventory().add(new ItemStack(ModItems.VEGETABLE_SOUP.get(), 4));
        p.getInventory().add(new ItemStack(ModItems.TENN_COIN.get(), 100));
    }

    public static void damageVillage(ServerLevel w) {
        Data d = data(w);
        if (d.damaged) return;
        d.damaged = true;
        d.setDirty();
        TatsumaBuilder.burnHouse(w, d);
    }
}
