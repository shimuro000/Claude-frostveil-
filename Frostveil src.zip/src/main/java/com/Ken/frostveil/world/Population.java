package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.entity.FvNpcEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.horse.Markings;
import net.minecraft.world.entity.animal.horse.Variant;
import net.minecraft.world.phys.AABB;

/**
 * Fills Tatsuma with people. Called when the village is built, when a player enters the dimension and from time to time:
 * missing important characters and villagers are created again (never duplicated, never taken from a player's party).
 */
public final class Population {
    private record Slot(String id, int count, String home, String work) {}

    private static final Slot[] ROSTER = {
            new Slot("kaina", 1, "", ""), new Slot("awi", 1, "", ""), new Slot("yu", 1, "", ""), new Slot("drayt", 1, "", ""),
            new Slot("igor", 1, "", ""), new Slot("tetsu", 1, "", ""),
            new Slot("child", 4, "kaina_house", ""),
            new Slot("farmer", 2, "house_ne", "farm"), new Slot("farmer", 1, "house_s", "farm"),
            new Slot("merchant", 2, "house_market", "market"), new Slot("merchant", 1, "house_market", "market"),
            new Slot("guard", 1, "house_se", "north_gate"), new Slot("guard", 1, "house_se", "south_gate"), new Slot("guard", 1, "house_se", "north_gate"),
            new Slot("hunter", 2, "house_w", "south_gate"),
            new Slot("smith", 1, "house_w", "forge"),
    };

    private Population() {}

    private static boolean inSomeParty(ServerLevel l, String id) {
        for (ServerPlayer p : l.getServer().getPlayerList().getPlayers()) if (FvCap.get(p).inParty(id)) return true;
        return false;
    }

    public static String slotKey(String id, String home, String work) { return id + "|" + home + "|" + work; }

    private static void spawnSlot(ServerLevel l, Slot s) {
        String homeName = s.home().isEmpty() ? com.Ken.frostveil.entity.NpcDefs.get(s.id()).home() : s.home();
        BlockPos at = FrostveilWorld.poi(l, s.work().isEmpty() ? homeName : s.work());
        if (at == null) return;
        FvNpcEntity n = FvNpcEntity.spawn(l, s.id(), at.offset(l.random.nextInt(5) - 2, 0, l.random.nextInt(5) - 2));
        n.setPlaces(homeName, s.work());
    }

    /** The only moment the whole roster is created: right after the village is built. */
    public static void populate(ServerLevel l) {
        for (Slot s : ROSTER) for (int i = 0; i < s.count(); i++) spawnSlot(l, s);
        BlockPos st = FrostveilWorld.poi(l, "stable");
        for (int i = 0; i < 3 && st != null; i++) {
            Horse h = EntityType.HORSE.create(l);
            if (h == null) break;
            h.moveTo(st.getX() - 3 + i * 2, st.getY(), st.getZ() + 1, l.random.nextFloat() * 360, 0);
            h.setTamed(true);
            h.setVariantAndMarkings(Variant.WHITE, Markings.NONE);
            h.setPersistenceRequired();
            l.addFreshEntity(h);
        }
        BlockPos pen = FrostveilWorld.poi(l, "farm");
        for (int i = 0; i < 5 && pen != null; i++) {
            Chicken c = EntityType.CHICKEN.create(l);
            if (c == null) break;
            c.moveTo(pen.getX() + l.random.nextInt(6) - 3, pen.getY(), pen.getZ() + l.random.nextInt(6) - 3, 0, 0);
            c.setPersistenceRequired();
            l.addFreshEntity(c);
        }
    }

    /** Called at login / dimension change / every few minutes: brings back villagers that DIED, and removes duplicates. Never creates from "not found". */
    public static void ensure(ServerLevel l) {
        if (!l.dimension().equals(Fv.WORLD)) return;
        FrostveilWorld.Data d = FrostveilWorld.data(l);
        if (!d.built) return;
        if (!d.respawn.isEmpty() && !d.raid) {
            for (String key : new java.util.ArrayList<>(d.respawn)) {
                for (Slot s : ROSTER) {
                    String home = s.home().isEmpty() ? com.Ken.frostveil.entity.NpcDefs.get(s.id()).home() : s.home();
                    if (slotKey(s.id(), home, s.work()).equals(key)) { if (!(s.home().isEmpty() && inSomeParty(l, s.id()))) spawnSlot(l, s); break; }
                }
            }
            d.respawn.clear();
            d.setDirty();
        }
        cleanup(l);
    }

    /** Removes duplicates among the LOADED NPCs (unique people keep one copy; generic ones are capped by the roster). */
    public static void cleanup(ServerLevel l) {
        java.util.Map<String, Integer> allowed = new java.util.HashMap<>();
        for (Slot s : ROSTER) {
            String home = s.home().isEmpty() ? com.Ken.frostveil.entity.NpcDefs.get(s.id()).home() : s.home();
            allowed.merge(slotKey(s.id(), home, s.work()), s.count(), Integer::sum);
        }
        java.util.Map<String, Integer> seen = new java.util.HashMap<>();
        for (FvNpcEntity e : l.getEntitiesOfClass(FvNpcEntity.class, new AABB(-200, -64, -200, 200, 320, 200))) {
            if (e.getOwnerId() != null || !e.isAlive()) continue;
            String id = e.npcId();
            if (!allowed.containsKey(slotKey(id, e.homeName(), e.workName())) && !com.Ken.frostveil.entity.NpcDefs.get(id).unique()) continue;
            String key = com.Ken.frostveil.entity.NpcDefs.get(id).unique() ? id : slotKey(id, e.homeName(), e.workName());
            int cap = com.Ken.frostveil.entity.NpcDefs.get(id).unique() ? 1 : allowed.getOrDefault(key, 99);
            int n = seen.merge(key, 1, Integer::sum);
            if (n > cap && !e.isScripted()) e.discard();
        }
        java.util.List<Horse> horses = l.getEntitiesOfClass(Horse.class, new AABB(-200, -64, -200, 200, 320, 200));
        for (int i = 3; i < horses.size(); i++) if (!horses.get(i).getPersistentData().getBoolean("fv_scene_horse")) horses.get(i).discard();
        java.util.List<Chicken> hens = l.getEntitiesOfClass(Chicken.class, new AABB(-200, -64, -200, 200, 320, 200));
        for (int i = 5; i < hens.size(); i++) hens.get(i).discard();
    }
}
