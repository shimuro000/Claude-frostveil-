package com.Ken.frostveil.world;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.entity.FvNpcEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.horse.Markings;
import net.minecraft.world.entity.animal.horse.Variant;
import net.minecraft.world.phys.AABB;

/**
 * Fills Tatsuma with people. Called when the village is built, when a player enters the dimension and from time to time:
 * missing important characters and villagers are created again (never duplicated, never taken from a player's party).
 */
public final class Population {
    private record Slot(String id, int count, String home, String work) {}

    private static final Slot[] ROSTER = {
            new Slot("kaina", 1, "", ""), new Slot("awi", 1, "", ""), new Slot("yu", 1, "", ""), new Slot("drayt", 1, "", ""),
            new Slot("igor", 1, "", ""), new Slot("tetsu", 1, "", ""),
            new Slot("child", 4, "kaina_house", ""),
            new Slot("farmer", 2, "house_ne", "farm"), new Slot("farmer", 1, "house_s", "farm"),
            new Slot("merchant", 2, "house_market", "market"), new Slot("merchant", 1, "house_market", "market"),
            new Slot("guard", 1, "house_se", "north_gate"), new Slot("guard", 1, "house_se", "south_gate"), new Slot("guard", 1, "house_se", "north_gate"),
            new Slot("hunter", 2, "house_w", "south_gate"),
            new Slot("smith", 1, "house_w", "forge"),
    };

    private Population() {}

    private static int countOf(ServerLevel l, String id, String home) {
        int n = 0;
        for (FvNpcEntity e : l.getEntitiesOfClass(FvNpcEntity.class, new AABB(-120, -64, -120, 120, 320, 120))) {
            if (e.npcId().equals(id) && e.isAlive() && (home.isEmpty() || e.homeName().equals(home))) n++;
        }
        return n;
    }

    private static boolean inSomeParty(ServerLevel l, String id) {
        for (ServerPlayer p : l.getServer().getPlayerList().getPlayers()) if (FvCap.get(p).inParty(id)) return true;
        return false;
    }

    public static void ensure(ServerLevel l) {
        if (!l.dimension().equals(Fv.WORLD) || !FrostveilWorld.data(l).built) return;
        for (Slot s : ROSTER) {
            boolean unique = s.home().isEmpty();
            if (unique && inSomeParty(l, s.id())) continue;
            int have = countOf(l, s.id(), s.home());
            for (int i = have; i < s.count(); i++) {
                String homeName = s.home().isEmpty() ? com.Ken.frostveil.entity.NpcDefs.get(s.id()).home() : s.home();
                BlockPos at = FrostveilWorld.poi(l, s.work().isEmpty() ? homeName : s.work());
                if (at == null) continue;
                FvNpcEntity n = FvNpcEntity.spawn(l, s.id(), at.offset(l.random.nextInt(5) - 2, 0, l.random.nextInt(5) - 2));
                n.setPlaces(homeName, s.work());
            }
        }
        // stable animals
        int horses = l.getEntitiesOfClass(Horse.class, new AABB(10, -64, -10, 45, 320, 20)).size();
        BlockPos st = FrostveilWorld.poi(l, "stable");
        for (int i = horses; i < 3 && st != null; i++) {
            Horse h = EntityType.HORSE.create(l);
            if (h == null) break;
            h.moveTo(st.getX() - 3 + i * 2, st.getY(), st.getZ() + 1, l.random.nextFloat() * 360, 0);
            h.setTamed(true);
            h.setVariantAndMarkings(Variant.WHITE, Markings.NONE);
            h.setPersistenceRequired();
            l.addFreshEntity(h);
        }
        int hens = l.getEntitiesOfClass(Chicken.class, new AABB(-60, -64, -60, 60, 320, 60)).size();
        BlockPos pen = FrostveilWorld.poi(l, "farm");
        for (int i = hens; i < 5 && pen != null; i++) {
            Chicken c = EntityType.CHICKEN.create(l);
            if (c == null) break;
            c.moveTo(pen.getX() + l.random.nextInt(6) - 3, pen.getY(), pen.getZ() + l.random.nextInt(6) - 3, 0, 0);
            c.setPersistenceRequired();
            l.addFreshEntity(c);
        }
    }
}
