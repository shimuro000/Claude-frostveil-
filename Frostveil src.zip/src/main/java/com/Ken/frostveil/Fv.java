package com.Ken.frostveil;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

/** Shared constants and helpers. */
public final class Fv {
    public static final String ID = "frostveil";
    public static final ResourceKey<Level> WORLD = ResourceKey.create(Registries.DIMENSION, id("world"));

    private Fv() {}

    public static ResourceLocation id(String path) {
        return new ResourceLocation(ID, path);
    }
}
