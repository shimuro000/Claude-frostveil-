package com.Ken.frostveil.combat;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModEffects;
import com.Ken.frostveil.story.MissionManager;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Server-side melee: a 3-hit light chain, a charged heavy attack, a held ice weapon whose reach and damage come from its recipe,
 * Forge and Infuse bonuses. The client only sends the input and plays the animation.
 */
public final class CombatService {
    private static final float[] COMBO_MUL = {1.0f, 1.15f, 1.75f};

    private CombatService() {}

    public static void attack(ServerPlayer p, boolean heavy, int charge) {
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        if (now < d.nextAttack) return;
        if (now > d.comboExpire) d.comboIndex = 0;

        // held ice weapon (Solid Shaper HOLD): reach, damage and arc come from the recipe
        IceConstructEntity held = null;
        if (d.heldConstruct >= 0) {
            Entity e = level.getEntity(d.heldConstruct);
            if (e instanceof IceConstructEntity ic && ic.isAlive()) held = ic;
        }
        float reach = 3.0f;
        float arcDeg = heavy ? 110f : 75f;
        float base = (float) p.getAttributeValue(Attributes.ATTACK_DAMAGE);
        if (held != null) {
            ShapeSpec hs = held.spec();
            reach = 2.5f + hs.length * 0.9f;
            base = Math.max(base, held.heldDamage() * 0.7f);
            if (hs.prim == ShapeSpec.Prim.BLADE) arcDeg += 35f;
            if (hs.prim == ShapeSpec.Prim.LANCE) arcDeg = 40f;
            if (hs.prim == ShapeSpec.Prim.WALL || hs.prim == ShapeSpec.Prim.DISC) arcDeg = 120f;
        }
        int idx = heavy ? 2 : d.comboIndex;
        float mul = heavy ? 1.6f + Mth.clamp(charge, 0, 20) * 0.06f : COMBO_MUL[idx];
        float dmg = base * mul * (1f + d.strength * 0.012f);

        boolean forgeArm = d.forgeLimb == 1 || d.forgeLimb == 2;
        if (forgeArm && d.aura > 1) {
            dmg *= 1f + 0.22f * d.forgeStage;
            d.aura -= 0.4f;
            reach += 0.2f;
        }
        boolean infused = d.infuseTicks > 0 && !p.getMainHandItem().isEmpty();
        if (infused) dmg += 1.5f + d.infuseStage;
        if (p.hasEffect(ModEffects.FRACTURE.get())) dmg *= 0.55f;

        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double cos = Math.cos(Math.toRadians(arcDeg / 2.0));
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(reach + 0.5), t -> canHit(p, t));
        int hits = 0;
        float reachF = reach;
        targets.sort(Comparator.comparingDouble(t -> t.distanceToSqr(p)));
        for (LivingEntity t : targets) {
            Vec3 to = t.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist - t.getBbWidth() * 0.5 > reachF) continue;
            if (look.dot(to.normalize()) < cos) continue;
            if (hits >= (held != null && held.spec().prim == ShapeSpec.Prim.BLADE ? 4 : 2)) break;
            t.invulnerableTime = 0;
            boolean ok = t.hurt(p.damageSources().playerAttack(p), dmg);
            if (!ok) continue;
            hits++;
            double kb = heavy ? 1.1 : (idx == 2 ? 0.9 : 0.35);
            t.knockback(kb, -look.x, -look.z);
            if (idx == 2 || heavy) t.setDeltaMovement(t.getDeltaMovement().add(0, 0.28, 0)); // finisher launches
            if (infused || held != null) t.setTicksFrozen(Math.min(t.getTicksRequiredToFreeze() + 40, t.getTicksFrozen() + 60));
            float strength = Mth.clamp(dmg / 10f, 0.2f, 1f);
            Vec3 at = t.getBoundingBox().getCenter();
            String el = (infused || held != null) ? d.element : "none";
            FvNet.toNear(level, at.x, at.y, at.z, 48, new FvNet.ImpactMsg(t.getId(), (float) at.x, (float) at.y, (float) at.z, strength, el, heavy || idx == 2 ? 1 : 0, dmg));
            hitSound(level, t, heavy || idx == 2, infused || held != null);
            MissionManager.event(p, "hit", t.getType().builtInRegistryHolder().key().location().getPath());
            if (forgeArm) forgeStrain(p, d, heavy);
            if (!t.isAlive()) FvNet.toNear(level, at.x, at.y, at.z, 48, new FvNet.ImpactMsg(t.getId(), (float) at.x, (float) at.y, (float) at.z, 0.8f, el, 3, dmg));
        }
        if (hits > 0) {
            d.flow = Math.min(100, d.flow + (idx == 2 ? 3f : 1f));
            d.lastHurt = Math.min(d.lastHurt, now - 0); // hitting keeps the fight "hot" but does not shake focus
        } else {
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.6f, heavy ? 0.8f : 1.2f);
        }
        d.comboIndex = heavy ? 0 : (idx + 1) % 3;
        d.comboExpire = now + 24;
        d.nextAttack = now + (heavy ? 18 : (idx == 2 ? 14 : 8));
        d.mark();
    }

    private static boolean canHit(ServerPlayer p, LivingEntity t) {
        if (t == p || !t.isAlive() || t.isSpectator()) return false;
        if (t instanceof Player) return false;
        if (t instanceof FvNpcEntity n) return n.isHostileTo(p);
        return true;
    }

    private static void hitSound(ServerLevel level, LivingEntity t, boolean big, boolean ice) {
        level.playSound(null, t.getX(), t.getY(), t.getZ(), big ? SoundEvents.PLAYER_ATTACK_CRIT : SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1f, big ? 0.9f : 1.15f);
        if (ice) level.playSound(null, t.getX(), t.getY(), t.getZ(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 0.9f, big ? 0.8f : 1.3f);
        if (big) level.playSound(null, t.getX(), t.getY(), t.getZ(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.18f, 1.9f);
    }

    /** Over-Forge: past the Body Limit the bones pay. "It hurts your hand, but it hurts them more." */
    private static void forgeStrain(ServerPlayer p, FvData d, boolean heavy) {
        float load = (6f + d.forgeStage * 5f) * (heavy ? 1.6f : 1f) + d.fatigue * 0.08f;
        if (!d.hasFlag("first_forge")) {
            d.setFlag("first_forge");
            com.Ken.frostveil.eiu.ServerActions.msg(p, "It hurts your hand, but it hurts them more.");
            return;
        }
        if (load > d.bodyLimit && p.getRandom().nextFloat() < 0.15f + (load - d.bodyLimit) * 0.03f) {
            p.addEffect(new MobEffectInstance(ModEffects.FRACTURE.get(), 20 * 90, 0));
            d.forgeLimb = 0;
            com.Ken.frostveil.eiu.ServerActions.msg(p, "Something cracks in your hand. You pushed past your Body Limit.");
            p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SKELETON_HURT, SoundSource.PLAYERS, 0.8f, 0.6f);
        }
    }
}
