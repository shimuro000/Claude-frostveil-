package com.Ken.frostveil.combat;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.eiu.ServerActions;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.story.MissionManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Dodge, guard, parry, focus shock (Law 5), halo absorb, kill events for missions. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class CombatEvents {
    private CombatEvents() {}

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        DamageSource src = e.getSource();
        Entity attacker = src.getEntity();
        if (attacker == null && src.getDirectEntity() == null) return; // environment damage is not dodgeable
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        if (now < d.dodgeUntil) {
            e.setCanceled(true);
            // perfect dodge: the hit lands in the first ticks of the dodge window
            if (now - (d.dodgeUntil - 8) <= 5) {
                d.flow = Math.min(100, d.flow + 8);
                d.focus = Math.min(100, d.focus + 6);
                d.mark();
                FvNet.toNear(level, p.getX(), p.getY(), p.getZ(), 48, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY() + 1f, (float) p.getZ(), 0.9f, d.element, 5, 0));
                MissionManager.event(p, "perfect_dodge", "");
            }
            return;
        }
        if (d.guarding && attacker != null) {
            Vec3 to = attacker.position().subtract(p.position()).normalize();
            Vec3 look = p.getLookAngle();
            if (look.x * to.x + look.z * to.z > 0.2) {
                boolean parry = now - d.guardSince <= 7;
                if (parry) {
                    e.setCanceled(true);
                    if (attacker instanceof LivingEntity le) {
                        le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 3, false, false));
                        le.knockback(0.9, to.x * -1, to.z * -1);
                    }
                    d.flow = Math.min(100, d.flow + 10);
                    d.focus = Math.min(100, d.focus + 12);
                    d.mark();
                    Vec3 at = p.getEyePosition().add(look.scale(0.9));
                    FvNet.toNear(level, at.x, at.y, at.z, 48, new FvNet.ImpactMsg(attacker.getId(), (float) at.x, (float) at.y, (float) at.z, 1f, d.element, 2, 0));
                    level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1f, 1.3f);
                    level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 1.8f);
                    MissionManager.event(p, "parry", "");
                }
            }
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            FvData d = FvCap.get(p);
            if (!d.active()) return;
            long now = p.level().getGameTime();
            float amount = e.getAmount();
            Entity attacker = e.getSource().getEntity();
            if (d.guarding && attacker != null) {
                amount *= 0.4f; // plain guard
                d.aura = Math.max(0, d.aura - amount * 0.8f);
            }
            if (d.forgeLimb == 4 && d.aura > 1) { amount *= 0.8f; d.aura -= 0.5f; }
            if (d.haloOn && d.haloShards > 0 && attacker != null) {
                d.haloShards--;
                amount *= 0.6f;
                FvNet.toNear((ServerLevel) p.level(), p.getX(), p.getY() + 1, p.getZ(), 48, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY() + 1f, (float) p.getZ(), 0.5f, d.element, 3, 0));
            }
            e.setAmount(amount);
            // Law 5: pain and fear shrink the Focus meter; a rattled mind cracks shapes
            d.focus = Math.max(0, d.focus - Mth.clamp(amount * 3.5f, 4f, 40f));
            d.lastHurt = now;
            d.flow = Math.max(0, d.flow - 3f);
            d.mark();
            FvNet.toPlayer(p, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY(), (float) p.getZ(), Mth.clamp(amount / 8f, 0.2f, 1f), d.element, 7, amount));
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        Entity killer = e.getSource().getEntity();
        if (killer instanceof ServerPlayer p) {
            MissionManager.event(p, "kill", e.getEntity().getType().builtInRegistryHolder().key().location().getPath());
        } else if (e.getSource().getDirectEntity() instanceof com.Ken.frostveil.ice.IceConstructEntity ic && ic.getOwner() instanceof ServerPlayer p2) {
            MissionManager.event(p2, "kill", e.getEntity().getType().builtInRegistryHolder().key().location().getPath());
        }
        if (e.getEntity() instanceof ServerPlayer dead) {
            ServerActions.msg(dead, "You fall. You will wake at the last safe place.");
        }
    }
}
