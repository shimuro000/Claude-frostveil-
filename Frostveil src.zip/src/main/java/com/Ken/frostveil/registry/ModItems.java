package com.Ken.frostveil.registry;

import com.Ken.frostveil.Fv;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Fv.ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Fv.ID);

    private static Item.Properties p() {
        return new Item.Properties();
    }

    // Story items (names follow the author's item list, section J4)
    public static final RegistryObject<Item> ICE_STICK = ITEMS.register("ice_stick", () -> new SwordItem(Tiers.WOOD, 1, -2.2f, p().stacksTo(1)));
    public static final RegistryObject<Item> SMALL_AXE = ITEMS.register("small_axe", () -> new AxeItem(Tiers.WOOD, 2.0f, -2.8f, p().stacksTo(1)));
    public static final RegistryObject<Item> SOMA_FIREWOOD = ITEMS.register("soma_firewood", () -> new Item(p()));
    public static final RegistryObject<Item> TENN_COIN = ITEMS.register("tenn_coin", () -> new Item(p()));
    public static final RegistryObject<Item> ID_PAPERS = ITEMS.register("id_papers", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> EXPLORER_COMPASS = ITEMS.register("explorer_compass", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> SMART_BRACELET = ITEMS.register("smart_bracelet", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> LANTERN_BACKPACK = ITEMS.register("lantern_backpack", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> WAIST_BAG = ITEMS.register("waist_bag", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> POPUP_TENT = ITEMS.register("popup_tent", () -> new Item(p().stacksTo(1)));
    public static final RegistryObject<Item> VEGETABLE_SOUP = ITEMS.register("vegetable_soup", () ->
            new Item(p().stacksTo(16).food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6f).build())));
    public static final RegistryObject<Item> MONSTER_MEAT = ITEMS.register("monster_meat", () ->
            new Item(p().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.3f).meat().build())));
    public static final RegistryObject<Item> SCARLET_SCALE = ITEMS.register("scarlet_scale", () -> new Item(p()));

    // Block items
    public static final RegistryObject<Item> CONJURED_ICE_ITEM = ITEMS.register("conjured_ice", () -> ModBlocks.blockItem(ModBlocks.CONJURED_ICE));
    public static final RegistryObject<Item> SOMA_LOG_ITEM = ITEMS.register("soma_log", () -> ModBlocks.blockItem(ModBlocks.SOMA_LOG));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.frostveil"))
            .icon(() -> new ItemStack(ICE_STICK.get()))
            .displayItems((params, out) -> ITEMS.getEntries().forEach(e -> out.accept(e.get())))
            .build());

    private ModItems() {}
}
