package com.Ken.frostveil.registry;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.ice.ConjuredIceBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, Fv.ID);

    /** Temporary ice made by Solid Shaper. It cracks and shatters on its own. */
    public static final RegistryObject<Block> CONJURED_ICE = BLOCKS.register("conjured_ice", ConjuredIceBlock::new);

    /** Soma Forest wood: the fast-growing magic trees that Kaina's firewood comes from. */
    public static final RegistryObject<Block> SOMA_LOG = BLOCKS.register("soma_log", () ->
            new RotatedPillarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.6f).sound(SoundType.WOOD)));

    private ModBlocks() {}

    static BlockItem blockItem(RegistryObject<Block> block) {
        return new BlockItem(block.get(), new Item.Properties());
    }
}
