package com.Ken.frostveil.registry;

import com.Ken.frostveil.Fv;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Injury / state effects from the lore: Fracture (over-Forge), Forced Closure, Exhaustion (low aura, Law 2). */
public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, Fv.ID);

    public static final RegistryObject<MobEffect> FRACTURE = EFFECTS.register("fracture", () ->
            new Simple(MobEffectCategory.HARMFUL, 0xC9B79C)
                    .addAttributeModifier(Attributes.ATTACK_DAMAGE, "5b8c0d0e-6a0e-4a2f-9a0e-4f0a7c3f1a01", -0.45, AttributeModifier.Operation.MULTIPLY_TOTAL));
    public static final RegistryObject<MobEffect> FORCED_CLOSURE = EFFECTS.register("forced_closure", () ->
            new Simple(MobEffectCategory.HARMFUL, 0x3A4A66)
                    .addAttributeModifier(Attributes.MOVEMENT_SPEED, "5b8c0d0e-6a0e-4a2f-9a0e-4f0a7c3f1a02", -0.25, AttributeModifier.Operation.MULTIPLY_TOTAL));
    public static final RegistryObject<MobEffect> EXHAUSTION = EFFECTS.register("exhaustion", () ->
            new Simple(MobEffectCategory.HARMFUL, 0x6B6B7A)
                    .addAttributeModifier(Attributes.ATTACK_SPEED, "5b8c0d0e-6a0e-4a2f-9a0e-4f0a7c3f1a03", -0.3, AttributeModifier.Operation.MULTIPLY_TOTAL));

    private ModEffects() {}

    private static final class Simple extends MobEffect {
        Simple(MobEffectCategory category, int color) {
            super(category, color);
        }
    }
}
