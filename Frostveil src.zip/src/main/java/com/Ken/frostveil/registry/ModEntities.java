package com.Ken.frostveil.registry;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.entity.EiuBeastEntity;
import com.Ken.frostveil.entity.FargasEntity;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.SnowFieldEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = Fv.ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Fv.ID);

    public static final RegistryObject<EntityType<IceConstructEntity>> ICE_CONSTRUCT = TYPES.register("ice_construct", () ->
            EntityType.Builder.<IceConstructEntity>of(IceConstructEntity::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(1).fireImmune().build("ice_construct"));

    public static final RegistryObject<EntityType<SnowFieldEntity>> SNOW_FIELD = TYPES.register("snow_field", () ->
            EntityType.Builder.<SnowFieldEntity>of(SnowFieldEntity::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f).clientTrackingRange(10).updateInterval(20).fireImmune().build("snow_field"));

    public static final RegistryObject<EntityType<FvNpcEntity>> NPC = TYPES.register("npc", () ->
            EntityType.Builder.<FvNpcEntity>of(FvNpcEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f).clientTrackingRange(10).build("npc"));

    public static final RegistryObject<EntityType<EiuBeastEntity>> BEAST = TYPES.register("eiu_beast", () ->
            EntityType.Builder.<EiuBeastEntity>of(EiuBeastEntity::new, MobCategory.MONSTER)
                    .sized(1.1f, 1.5f).clientTrackingRange(10).build("eiu_beast"));

    public static final RegistryObject<EntityType<FargasEntity>> FARGAS = TYPES.register("fargas", () ->
            EntityType.Builder.<FargasEntity>of(FargasEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).clientTrackingRange(12).build("fargas"));

    private ModEntities() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(NPC.get(), FvNpcEntity.createAttributes().build());
        event.put(BEAST.get(), EiuBeastEntity.createAttributes().build());
        event.put(FARGAS.get(), FargasEntity.createAttributes().build());
    }
}
