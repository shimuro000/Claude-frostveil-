package com.Ken.frostveil.capability;

import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.network.FrostveilNetwork;
import com.Ken.frostveil.network.SyncStoryDataPacket;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Registers, attaches, persists and syncs the {@link PlayerStoryData} capability.
 */
public class StoryCapabilityEvents {
    public static final Capability<PlayerStoryData> STORY = CapabilityManager.get(new CapabilityToken<>() {});
    private static final ResourceLocation KEY = new ResourceLocation(Frostveil.MOD_ID, "story");

    /** Mod-bus: declare the capability type. */
    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(PlayerStoryData.class);
    }

    /** Provider that holds one data instance per player and handles NBT save/load. */
    private static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final PlayerStoryData data = new PlayerStoryData();
        private final LazyOptional<PlayerStoryData> optional = LazyOptional.of(() -> data);

        @Override
        public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
            return cap == STORY ? optional.cast() : LazyOptional.empty();
        }

        @Override public CompoundTag serializeNBT() { return data.save(); }
        @Override public void deserializeNBT(CompoundTag nbt) { data.load(nbt); }
    }

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(KEY, new Provider());
        }
    }

    /** Keep the story save when the player dies or returns from the End. */
    @SubscribeEvent
    public static void clone(PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(STORY).ifPresent(old ->
                event.getEntity().getCapability(STORY).ifPresent(neu -> neu.copyFrom(old)));
        event.getOriginal().invalidateCaps();
    }

    /** Send the server-side data to the client when the player joins, respawns or changes dimension. */
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) { sync(event.getEntity()); }
    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) { sync(event.getEntity()); }
    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) { sync(event.getEntity()); }

    public static void sync(Player player) {
        if (player instanceof ServerPlayer sp) {
            sp.getCapability(STORY).ifPresent(data -> FrostveilNetwork.sendToPlayer(sp, new SyncStoryDataPacket(data.save())));
        }
    }
}
