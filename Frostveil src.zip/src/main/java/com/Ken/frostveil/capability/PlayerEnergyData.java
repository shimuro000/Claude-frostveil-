package com.Ken.frostveil.capability;

import com.Ken.frostveil.energy.ChannelState;
import com.Ken.frostveil.energy.Element;
import net.minecraft.nbt.CompoundTag;

/**
 * PlayerEnergy capability data (G7). Server owns it, the client holds a synced copy for rendering.
 * Public fields keep this class small; only the server-side EnergyEngine mutates the real copy.
 */
public class PlayerEnergyData {
    public boolean awakened;                       // first feeling reached (D5)
    public Element element = Element.ICE;          // Story Mode: Shimoro is ice. TODO(phase-3): Free World First Training sets it once.
    public double quantity = 100, output = 10, efficiency = 0.05; // Aura Quantity / Output / Efficiency (D9) [DESIGN] start values
    public double aura = 100;
    public int strength = 10, speed = 10, endurance = 10, perception = 10, focusStat = 10; // body stats (G6)
    public int bodyLimit = 400;                    // Law 6: Forge strain ticks the body can take before injury
    public double focus = 100;                     // Law 5
    public double externalRange = 3.0;             // control level 3 range in blocks (weak at the start, D3)
    public int skinSenseStage, forgeStage, cutoffStage, infuseStage; // 0 = not learned (Saga 1: learned by story)
    public String weakStat = "";                   // PLACEHOLDER: which of Quantity/Output/Efficiency is weakest (see LORE_GAPS.md)
    public boolean skinSense, shroud, forgeActive, infuseHeld, focusHold;
    public int forgeLimb;                          // 0 right arm, 1 left arm, 2 legs, 3 torso
    public ChannelState channel = ChannelState.NORMAL;
    public int forgeStrain, fracturedHandTicks, flowTicks, meditationTicks;
    public double flowCounter;                     // hidden Flow counter (G7)
    public long dodgeUntil, dodgeCooldownUntil;

    /** Skin Sense radius in blocks: 1 at stage 1, growing (D10). */
    public double skinSenseRadius() { return skinSenseStage <= 0 ? 0 : 1.0 + 0.5 * (skinSenseStage - 1); }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("Awakened", awakened);
        t.putString("Element", element.name());
        t.putDouble("Quantity", quantity); t.putDouble("Output", output); t.putDouble("Efficiency", efficiency);
        t.putDouble("Aura", aura);
        t.putInt("Str", strength); t.putInt("Spd", speed); t.putInt("End", endurance); t.putInt("Per", perception); t.putInt("FocStat", focusStat);
        t.putInt("BodyLimit", bodyLimit);
        t.putDouble("Focus", focus); t.putDouble("ExtRange", externalRange);
        t.putInt("SkinStage", skinSenseStage); t.putInt("ForgeStage", forgeStage); t.putInt("CutoffStage", cutoffStage); t.putInt("InfuseStage", infuseStage);
        t.putString("WeakStat", weakStat);
        t.putBoolean("SkinSense", skinSense); t.putBoolean("Shroud", shroud); t.putBoolean("ForgeOn", forgeActive);
        t.putBoolean("InfuseHeld", infuseHeld); t.putBoolean("FocusHold", focusHold);
        t.putInt("ForgeLimb", forgeLimb);
        t.putString("Channel", channel.name());
        t.putInt("Strain", forgeStrain); t.putInt("Fracture", fracturedHandTicks); t.putInt("FlowTicks", flowTicks); t.putInt("Meditation", meditationTicks);
        t.putDouble("FlowCounter", flowCounter);
        return t;
    }

    /** Missing keys keep their defaults, so old saves never crash. */
    public void load(CompoundTag t) {
        awakened = t.getBoolean("Awakened");
        element = t.contains("Element") ? Element.byName(t.getString("Element")) : Element.ICE;
        quantity = t.contains("Quantity") ? t.getDouble("Quantity") : 100;
        output = t.contains("Output") ? t.getDouble("Output") : 10;
        efficiency = t.contains("Efficiency") ? t.getDouble("Efficiency") : 0.05;
        aura = t.contains("Aura") ? t.getDouble("Aura") : quantity;
        strength = t.contains("Str") ? t.getInt("Str") : 10; speed = t.contains("Spd") ? t.getInt("Spd") : 10;
        endurance = t.contains("End") ? t.getInt("End") : 10; perception = t.contains("Per") ? t.getInt("Per") : 10;
        focusStat = t.contains("FocStat") ? t.getInt("FocStat") : 10;
        bodyLimit = t.contains("BodyLimit") ? t.getInt("BodyLimit") : 400;
        focus = t.contains("Focus") ? t.getDouble("Focus") : 100;
        externalRange = t.contains("ExtRange") ? t.getDouble("ExtRange") : 3.0;
        skinSenseStage = t.getInt("SkinStage"); forgeStage = t.getInt("ForgeStage"); cutoffStage = t.getInt("CutoffStage"); infuseStage = t.getInt("InfuseStage");
        weakStat = t.getString("WeakStat");
        skinSense = t.getBoolean("SkinSense"); shroud = t.getBoolean("Shroud"); forgeActive = t.getBoolean("ForgeOn");
        infuseHeld = t.getBoolean("InfuseHeld"); focusHold = t.getBoolean("FocusHold");
        forgeLimb = Math.floorMod(t.getInt("ForgeLimb"), 4);
        channel = t.contains("Channel") ? ChannelState.byName(t.getString("Channel")) : ChannelState.NORMAL;
        forgeStrain = t.getInt("Strain"); fracturedHandTicks = t.getInt("Fracture"); flowTicks = t.getInt("FlowTicks"); meditationTicks = t.getInt("Meditation");
        flowCounter = t.getDouble("FlowCounter");
    }

    /** Copy on respawn; temporary toggles are cleared. */
    public void copyFrom(PlayerEnergyData o) {
        load(o.save());
        skinSense = shroud = forgeActive = infuseHeld = focusHold = false;
        forgeStrain = flowTicks = meditationTicks = 0;
        aura = quantity;
        focus = 100;
    }
}
