package com.Ken.frostveil.capability;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Per-player story save. Every player has an independent copy (multiplayer safe).
 * The server owns this data; the client only receives a synced copy for rendering.
 *
 * Story content (mission ids, chapter names) is data-driven JSON; this class only stores ids.
 */
public class PlayerStoryData {
    /** Id of the active mission, empty if none. PLACEHOLDER: first mission id is defined in data/frostveil/missions. */
    private String activeMission = "";
    private final Set<String> completedMissions = new LinkedHashSet<>();

    /** [DESIGN] Current EIU amount and its cap. Values are tuning numbers, not lore. */
    private int eiu = 100;
    private int maxEiu = 100;

    public String getActiveMission() { return activeMission; }
    public void setActiveMission(String id) { this.activeMission = id == null ? "" : id; }

    public Set<String> getCompletedMissions() { return completedMissions; }
    public void completeMission(String id) {
        completedMissions.add(id);
        if (id.equals(activeMission)) activeMission = "";
    }

    public int getEiu() { return eiu; }
    public int getMaxEiu() { return maxEiu; }
    public void setMaxEiu(int max) {
        this.maxEiu = Math.max(1, max);
        this.eiu = Math.min(this.eiu, this.maxEiu);
    }
    public void setEiu(int value) { this.eiu = Math.max(0, Math.min(value, maxEiu)); }

    /** Serialise to NBT for saving and for network sync. */
    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("ActiveMission", activeMission);
        tag.putInt("Eiu", eiu);
        tag.putInt("MaxEiu", maxEiu);
        ListTag list = new ListTag();
        for (String id : completedMissions) list.add(StringTag.valueOf(id));
        tag.put("Completed", list);
        return tag;
    }

    /** Load from NBT. Missing keys fall back to defaults so old saves never crash. */
    public void load(CompoundTag tag) {
        activeMission = tag.getString("ActiveMission");
        maxEiu = tag.contains("MaxEiu") ? Math.max(1, tag.getInt("MaxEiu")) : 100;
        eiu = tag.contains("Eiu") ? Math.max(0, Math.min(tag.getInt("Eiu"), maxEiu)) : maxEiu;
        completedMissions.clear();
        ListTag list = tag.getList("Completed", Tag.TAG_STRING);
        for (int i = 0; i < list.size(); i++) completedMissions.add(list.getString(i));
    }

    /** Copy all state from another instance (used when a player respawns). */
    public void copyFrom(PlayerStoryData other) {
        load(other.save());
    }
}
