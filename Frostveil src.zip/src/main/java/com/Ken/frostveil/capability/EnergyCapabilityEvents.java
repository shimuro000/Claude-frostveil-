package com.Ken.frostveil.capability;

import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.network.FrostveilNetwork;
import com.Ken.frostveil.network.SyncEnergyPacket;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Registers, attaches, saves, copies and syncs the PlayerEnergyData capability. */
public class EnergyCapabilityEvents {
    public static final Capability<PlayerEnergyData> ENERGY = CapabilityManager.get(new CapabilityToken<>() {});
    private static final ResourceLocation KEY = new ResourceLocation(Frostveil.MOD_ID, "energy");

    public static void registerCapabilities(RegisterCapabilitiesEvent event) { event.register(PlayerEnergyData.class); }

    private static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final PlayerEnergyData data = new PlayerEnergyData();
        private final LazyOptional<PlayerEnergyData> opt = LazyOptional.of(() -> data);

        @Override
        public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
            return cap == ENERGY ? opt.cast() : LazyOptional.empty();
        }
        @Override public CompoundTag serializeNBT() { return data.save(); }
        @Override public void deserializeNBT(CompoundTag nbt) { data.load(nbt); }
    }

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) e.addCapability(KEY, new Provider());
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        e.getOriginal().reviveCaps();
        e.getOriginal().getCapability(ENERGY).ifPresent(old -> e.getEntity().getCapability(ENERGY).ifPresent(n -> n.copyFrom(old)));
        e.getOriginal().invalidateCaps();
    }

    @SubscribeEvent public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) { sync(e.getEntity()); }
    @SubscribeEvent public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) { sync(e.getEntity()); }
    @SubscribeEvent public static void onDim(PlayerEvent.PlayerChangedDimensionEvent e) { sync(e.getEntity()); }

    public static void sync(Player p) {
        if (p instanceof ServerPlayer sp) sp.getCapability(ENERGY).ifPresent(d -> FrostveilNetwork.sendToPlayer(sp, new SyncEnergyPacket(d.save())));
    }
}
