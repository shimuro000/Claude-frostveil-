package com.Ken.frostveil.network;

import com.Ken.frostveil.client.ClientEnergyCache;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server to client: full copy of the player's energy data, for HUD rendering only. */
public class SyncEnergyPacket {
    private final CompoundTag data;
    public SyncEnergyPacket(CompoundTag data) { this.data = data; }
    public static void encode(SyncEnergyPacket m, FriendlyByteBuf b) { b.writeNbt(m.data); }
    public static SyncEnergyPacket decode(FriendlyByteBuf b) {
        CompoundTag t = b.readNbt();
        return new SyncEnergyPacket(t == null ? new CompoundTag() : t);
    }
    public static void handle(SyncEnergyPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientEnergyCache.update(m.data)));
        ctx.get().setPacketHandled(true);
    }
}
