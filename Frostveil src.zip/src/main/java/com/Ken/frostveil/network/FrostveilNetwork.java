package com.Ken.frostveil.network;

import com.Ken.frostveil.Frostveil;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** The one and only SimpleChannel of the mod. Server authoritative: S2C carries state, C2S carries inputs only. */
public class FrostveilNetwork {
    private static final String PROTOCOL = "1";
    private static SimpleChannel channel;

    public static void register() {
        channel = NetworkRegistry.newSimpleChannel(new ResourceLocation(Frostveil.MOD_ID, "main"),
                () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
        int id = 0;
        channel.messageBuilder(SyncStoryDataPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncStoryDataPacket::encode).decoder(SyncStoryDataPacket::decode)
                .consumerMainThread(SyncStoryDataPacket::handle).add();
        channel.messageBuilder(SyncEnergyPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncEnergyPacket::encode).decoder(SyncEnergyPacket::decode)
                .consumerMainThread(SyncEnergyPacket::handle).add();
        channel.messageBuilder(ActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ActionPacket::encode).decoder(ActionPacket::decode)
                .consumerMainThread(ActionPacket::handle).add();
    }

    public static void sendToPlayer(ServerPlayer player, Object packet) { channel.send(PacketDistributor.PLAYER.with(() -> player), packet); }
    public static void sendToServer(Object packet) { channel.sendToServer(packet); }
}
