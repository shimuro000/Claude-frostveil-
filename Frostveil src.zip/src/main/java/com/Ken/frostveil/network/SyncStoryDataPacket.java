package com.Ken.frostveil.network;

import com.Ken.frostveil.client.ClientStoryCache;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server to client: a full copy of the player's story data, used for UI rendering only. */
public class SyncStoryDataPacket {
    private final CompoundTag data;

    public SyncStoryDataPacket(CompoundTag data) { this.data = data; }

    public static void encode(SyncStoryDataPacket msg, FriendlyByteBuf buf) { buf.writeNbt(msg.data); }

    public static SyncStoryDataPacket decode(FriendlyByteBuf buf) {
        CompoundTag tag = buf.readNbt();
        return new SyncStoryDataPacket(tag == null ? new CompoundTag() : tag);
    }

    public static void handle(SyncStoryDataPacket msg, Supplier<NetworkEvent.Context> ctx) {
        // DistExecutor keeps client-only classes from loading on a dedicated server.
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientStoryCache.update(msg.data)));
        ctx.get().setPacketHandled(true);
    }
}
