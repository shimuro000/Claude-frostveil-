package com.Ken.frostveil.network;

import com.Ken.frostveil.energy.EnergyAction;
import com.Ken.frostveil.energy.EnergyEngine;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client to server: one input intent. The server validates everything in EnergyEngine. */
public class ActionPacket {
    private final EnergyAction action;
    private final boolean state;
    public ActionPacket(EnergyAction action, boolean state) { this.action = action; this.state = state; }
    public static void encode(ActionPacket m, FriendlyByteBuf b) { b.writeEnum(m.action); b.writeBoolean(m.state); }
    public static ActionPacket decode(FriendlyByteBuf b) { return new ActionPacket(b.readEnum(EnergyAction.class), b.readBoolean()); }
    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) EnergyEngine.handleAction(p, m.action, m.state);
        });
        ctx.get().setPacketHandled(true);
    }
}
