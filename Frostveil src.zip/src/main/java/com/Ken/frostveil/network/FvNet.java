package com.Ken.frostveil.network;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.combat.CombatService;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.data.PublicState;
import com.Ken.frostveil.ice.IceShaping;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.story.DialogueService;
import com.Ken.frostveil.story.MissionManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** All packets in one place. Server is authoritative: client messages are requests that get validated. */
public final class FvNet {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(Fv.id("main"), () -> VERSION, VERSION::equals, VERSION::equals);
    private static int next = 0;

    private FvNet() {}

    public interface Msg {
        void encode(FriendlyByteBuf b);
        void handle(NetworkEvent.Context ctx);
    }

    private static <M extends Msg> void reg(Class<M> cls, Function<FriendlyByteBuf, M> dec, NetworkDirection dir) {
        CH.registerMessage(next++, cls, Msg::encode, dec, (m, sup) -> {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> m.handle(ctx));
            ctx.setPacketHandled(true);
        }, Optional.of(dir));
    }

    public static void init() {
        // client -> server
        reg(ActionMsg.class, ActionMsg::new, NetworkDirection.PLAY_TO_SERVER);
        reg(CastMsg.class, CastMsg::new, NetworkDirection.PLAY_TO_SERVER);
        reg(SaveSpecMsg.class, SaveSpecMsg::new, NetworkDirection.PLAY_TO_SERVER);
        reg(ProfileMsg.class, ProfileMsg::new, NetworkDirection.PLAY_TO_SERVER);
        reg(AttackMsg.class, AttackMsg::new, NetworkDirection.PLAY_TO_SERVER);
        reg(ChoiceMsg.class, ChoiceMsg::new, NetworkDirection.PLAY_TO_SERVER);
        // server -> client
        reg(SyncDataMsg.class, SyncDataMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(AppearanceMsg.class, AppearanceMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(PublicStateMsg.class, PublicStateMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(ImpactMsg.class, ImpactMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(CaptionMsg.class, CaptionMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(DialogueMsg.class, DialogueMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(JournalMsg.class, JournalMsg::new, NetworkDirection.PLAY_TO_CLIENT);
        reg(ScreenMsg.class, ScreenMsg::new, NetworkDirection.PLAY_TO_CLIENT);
    }

    // ---- send helpers ----
    public static void toServer(Msg m) { CH.sendToServer(m); }
    public static void toPlayer(ServerPlayer p, Msg m) { CH.send(PacketDistributor.PLAYER.with(() -> p), m); }
    public static void toTracking(ServerPlayer p, Msg m) { CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), m); }
    public static void toAll(Msg m) { CH.send(PacketDistributor.ALL.noArg(), m); }
    public static void toNear(net.minecraft.server.level.ServerLevel level, double x, double y, double z, double r, Msg m) {
        CH.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, r, level.dimension())), m);
    }

    public static void syncData(ServerPlayer p) {
        FvData d = FvCap.get(p);
        d.dirty = false;
        toPlayer(p, new SyncDataMsg(d.save()));
    }

    public static void broadcastAppearance(ServerPlayer p) {
        FvData d = FvCap.get(p);
        toAll(new AppearanceMsg(p.getUUID(), d.profile.toTag(), d.ageStage, d.mode));
    }

    // =================== client -> server ===================

    /** Small toggles and requests: skin_sense, forge_limb, shroud, cutoff, infuse, meditate, guard, dodge, form, slot, point, order... */
    public record ActionMsg(String action, int a, int b, float f) implements Msg {
        public ActionMsg(FriendlyByteBuf buf) { this(buf.readUtf(32), buf.readVarInt(), buf.readVarInt(), buf.readFloat()); }
        public ActionMsg(String action) { this(action, 0, 0, 0f); }
        public ActionMsg(String action, int a) { this(action, a, 0, 0f); }
        public void encode(FriendlyByteBuf buf) { buf.writeUtf(action, 32); buf.writeVarInt(a); buf.writeVarInt(b); buf.writeFloat(f); }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) com.Ken.frostveil.eiu.ServerActions.handle(p, action, a, b, f);
        }
    }

    /** Cast the current shape: the recipe, how long F was held (mental phase), and an optional freehand stroke. */
    public record CastMsg(ShapeSpec spec, int held, List<Vec3> stroke) implements Msg {
        public CastMsg(FriendlyByteBuf buf) { this(ShapeSpec.read(buf), buf.readVarInt(), readStroke(buf)); }
        public void encode(FriendlyByteBuf buf) {
            spec.write(buf); buf.writeVarInt(held);
            int n = Math.min(stroke.size(), 64);
            buf.writeVarInt(n);
            for (int i = 0; i < n; i++) { Vec3 v = stroke.get(i); buf.writeDouble(v.x); buf.writeDouble(v.y); buf.writeDouble(v.z); }
        }
        private static List<Vec3> readStroke(FriendlyByteBuf buf) {
            int n = Math.min(buf.readVarInt(), 64);
            List<Vec3> out = new ArrayList<>();
            for (int i = 0; i < n; i++) out.add(new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()));
            return out;
        }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) IceShaping.cast(p, spec, held, stroke);
        }
    }

    /** Save a recipe into a preset slot (Shape Studio). */
    public record SaveSpecMsg(int slot, ShapeSpec spec) implements Msg {
        public SaveSpecMsg(FriendlyByteBuf buf) { this(buf.readVarInt(), ShapeSpec.read(buf)); }
        public void encode(FriendlyByteBuf buf) { buf.writeVarInt(slot); spec.write(buf); }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) IceShaping.saveSpec(p, slot, spec);
        }
    }

    /** Character creator result. */
    public record ProfileMsg(CompoundTag profile, int mode) implements Msg {
        public ProfileMsg(FriendlyByteBuf buf) { this(buf.readNbt(), buf.readVarInt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeNbt(profile); buf.writeVarInt(mode); }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) com.Ken.frostveil.eiu.ServerActions.setProfile(p, profile, mode);
        }
    }

    /** Light or heavy attack input (client cancels the vanilla swing, the server resolves the hit). */
    public record AttackMsg(boolean heavy, int chargeTicks) implements Msg {
        public AttackMsg(FriendlyByteBuf buf) { this(buf.readBoolean(), buf.readVarInt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeBoolean(heavy); buf.writeVarInt(chargeTicks); }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) CombatService.attack(p, heavy, chargeTicks);
        }
    }

    /** A dialogue choice. */
    public record ChoiceMsg(int entityId, int choice) implements Msg {
        public ChoiceMsg(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readVarInt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeVarInt(entityId); buf.writeVarInt(choice); }
        public void handle(NetworkEvent.Context ctx) {
            ServerPlayer p = ctx.getSender();
            if (p != null) DialogueService.choose(p, entityId, choice);
        }
    }

    // =================== server -> client ===================

    public record SyncDataMsg(CompoundTag tag) implements Msg {
        public SyncDataMsg(FriendlyByteBuf buf) { this(buf.readNbt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeNbt(tag); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.sync(tag)); }
    }

    public record AppearanceMsg(UUID id, CompoundTag profile, int age, int mode) implements Msg {
        public AppearanceMsg(FriendlyByteBuf buf) { this(buf.readUUID(), buf.readNbt(), buf.readVarInt(), buf.readVarInt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeUUID(id); buf.writeNbt(profile); buf.writeVarInt(age); buf.writeVarInt(mode); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.appearance(id, profile, age, mode)); }
    }

    public record PublicStateMsg(UUID id, PublicState state) implements Msg {
        public PublicStateMsg(FriendlyByteBuf buf) { this(buf.readUUID(), PublicState.read(buf)); }
        public void encode(FriendlyByteBuf buf) { buf.writeUUID(id); state.write(buf); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.publicState(id, state)); }
    }

    /**
     * A moment that must feel good: a hit, a parry, a shatter, a cast.
     * kind: 0 light hit, 1 heavy/finisher hit, 2 parry, 3 shatter (ice broken), 4 cast burst, 5 dodge, 6 flow start, 7 hurt
     */
    public record ImpactMsg(int entityId, float x, float y, float z, float strength, String element, int kind, float damage) implements Msg {
        public ImpactMsg(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readUtf(16), buf.readVarInt(), buf.readFloat()); }
        public void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entityId); buf.writeFloat(x); buf.writeFloat(y); buf.writeFloat(z); buf.writeFloat(strength); buf.writeUtf(element, 16); buf.writeVarInt(kind); buf.writeFloat(damage);
        }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.impact(this)); }
    }

    /** Narrator caption (cutscenes). Lines are separated by '\n'. */
    public record CaptionMsg(String text, int ticks, boolean blackScreen) implements Msg {
        public CaptionMsg(FriendlyByteBuf buf) { this(buf.readUtf(1024), buf.readVarInt(), buf.readBoolean()); }
        public void encode(FriendlyByteBuf buf) { buf.writeUtf(text, 1024); buf.writeVarInt(ticks); buf.writeBoolean(blackScreen); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.caption(text, ticks, blackScreen)); }
    }

    public record DialogueMsg(int entityId, CompoundTag node) implements Msg {
        public DialogueMsg(FriendlyByteBuf buf) { this(buf.readVarInt(), buf.readNbt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeVarInt(entityId); buf.writeNbt(node); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.dialogue(entityId, node)); }
    }

    public record JournalMsg(CompoundTag tag) implements Msg {
        public JournalMsg(FriendlyByteBuf buf) { this(buf.readNbt()); }
        public void encode(FriendlyByteBuf buf) { buf.writeNbt(tag); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.journal(tag)); }
    }

    /** Ask the client to open a screen: "mode_select", "creator", "journal", "none". */
    public record ScreenMsg(String screen) implements Msg {
        public ScreenMsg(FriendlyByteBuf buf) { this(buf.readUtf(32)); }
        public void encode(FriendlyByteBuf buf) { buf.writeUtf(screen, 32); }
        public void handle(NetworkEvent.Context ctx) { DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.Ken.frostveil.client.ClientHooks.openScreen(screen)); }
    }
}
