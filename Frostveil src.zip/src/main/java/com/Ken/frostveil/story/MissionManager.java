package com.Ken.frostveil.story;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.world.FrostveilWorld;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Data-driven story engine (design follows the author's mission schema, with DragonMineZ's idea of a requirement tree).
 * Missions live in data/frostveil/missions/*.json. A mission has requirements, ordered objectives (go to a place, make a game event
 * happen N times, wait, wait for a flag) and actions that run when it starts, when objectives finish and when it completes.
 */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class MissionManager {
    public record Obj(String type, String poi, int radius, String event, String arg, int count, String text, List<String> onDone) {}
    public record Mission(String id, String title, int arc, String desc, List<String> requires, String hint, List<String> onStart, List<String> onComplete, List<Obj> objectives, boolean stub) {}

    private static final Map<String, Mission> MISSIONS = new LinkedHashMap<>();

    private MissionManager() {}

    @SubscribeEvent
    public static void reload(AddReloadListenerEvent e) {
        e.addListener(new SimpleJsonResourceReloadListener(new Gson(), "missions") {
            @Override
            protected void apply(Map<ResourceLocation, JsonElement> map, ResourceManager rm, ProfilerFiller pf) {
                MISSIONS.clear();
                List<ResourceLocation> keys = new ArrayList<>(map.keySet());
                keys.sort(ResourceLocation::compareTo);
                for (ResourceLocation k : keys) {
                    try {
                        JsonObject root = map.get(k).getAsJsonObject();
                        for (JsonElement me : root.getAsJsonArray("missions")) {
                            Mission m = parse(me.getAsJsonObject());
                            MISSIONS.put(m.id(), m);
                        }
                    } catch (Exception ex) {
                        Frostveil.LOG.error("Bad mission file {}: {}", k, ex.toString());
                    }
                }
                Frostveil.LOG.info("Frostveil: loaded {} missions", MISSIONS.size());
            }
        });
    }

    private static List<String> strs(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o.has(key)) for (JsonElement e : o.getAsJsonArray(key)) out.add(e.getAsString());
        return out;
    }

    private static String str(JsonObject o, String key, String def) { return o.has(key) ? o.get(key).getAsString() : def; }

    private static Mission parse(JsonObject o) {
        List<Obj> objs = new ArrayList<>();
        if (o.has("objectives")) {
            for (JsonElement e : o.getAsJsonArray("objectives")) {
                JsonObject j = e.getAsJsonObject();
                objs.add(new Obj(str(j, "type", "event"), str(j, "poi", ""), j.has("radius") ? j.get("radius").getAsInt() : 5, str(j, "event", ""), str(j, "arg", ""),
                        j.has("count") ? j.get("count").getAsInt() : 1, str(j, "text", ""), strs(j, "on_done")));
            }
        }
        return new Mission(o.get("id").getAsString(), str(o, "title", "?"), o.has("arc") ? o.get("arc").getAsInt() : 1, str(o, "desc", ""), strs(o, "requires"),
                str(o, "hint", ""), strs(o, "on_start"), strs(o, "on_complete"), objs, o.has("stub") && o.get("stub").getAsBoolean());
    }

    public static Mission get(String id) { return MISSIONS.get(id); }
    public static Iterable<Mission> all() { return MISSIONS.values(); }

    // ---------- requirements ----------

    public static boolean meets(ServerPlayer p, FvData d, String cond) {
        boolean neg = cond.startsWith("!");
        String c = neg ? cond.substring(1) : cond;
        int i = c.indexOf(':');
        String k = i < 0 ? c : c.substring(0, i), v = i < 0 ? "" : c.substring(i + 1);
        boolean r = switch (k) {
            case "done" -> d.done(v);
            case "active" -> d.active.containsKey(v);
            case "flag" -> d.hasFlag(v);
            case "mode" -> v.equals("story") ? d.mode == FvData.MODE_STORY : d.mode == FvData.MODE_FREE;
            case "awakened" -> d.awakened;
            case "obj" -> { // obj:missionId|index
                String[] a = v.split("\\|");
                yield a.length == 2 && d.active.containsKey(a[0]) && d.active.get(a[0]) == Integer.parseInt(a[1]);
            }
            default -> true;
        };
        return neg != r;
    }

    private static boolean available(ServerPlayer p, FvData d, Mission m) {
        if (m.stub() || d.done(m.id()) || d.active.containsKey(m.id())) return false;
        for (String c : m.requires()) if (!meets(p, d, c)) return false;
        return true;
    }

    // ---------- lifecycle ----------

    public static void begin(ServerPlayer p) { start(p, "arc1_01"); }

    public static void start(ServerPlayer p, String id) {
        FvData d = FvCap.get(p);
        Mission m = MISSIONS.get(id);
        if (m == null || d.active.containsKey(id) || d.done(id)) return;
        d.active.put(id, 0);
        d.progress.put(id, 0);
        d.mark();
        for (String a : m.onStart()) Actions.run(p, a);
        p.displayClientMessage(net.minecraft.network.chat.Component.literal("New mission: " + m.title()), false);
        updateTracker(p, d);
    }

    /** Game events feed missions: "ice_cast", "kill", "talk", "feel_core", "wall_built", ... */
    public static void event(ServerPlayer p, String type, String arg) {
        FvData d = FvCap.get(p);
        if (!d.inStory() && !d.active()) return;
        for (String id : new ArrayList<>(d.active.keySet())) {
            Mission m = MISSIONS.get(id);
            if (m == null) continue;
            int idx = d.active.get(id);
            if (idx >= m.objectives().size()) continue;
            Obj o = m.objectives().get(idx);
            if (!o.type().equals("event") || !o.event().equals(type)) continue;
            if (!o.arg().isEmpty() && !o.arg().equals(arg)) continue;
            int n = d.progress.merge(id, 1, Integer::sum);
            d.mark();
            if (n >= o.count()) advance(p, d, m);
            else updateTracker(p, d);
        }
    }

    private static void advance(ServerPlayer p, FvData d, Mission m) {
        int idx = d.active.get(m.id());
        Obj done = m.objectives().get(idx);
        d.active.put(m.id(), idx + 1);
        d.progress.put(m.id(), 0);
        for (String a : done.onDone()) Actions.run(p, a);
        if (idx + 1 >= m.objectives().size()) {
            d.active.remove(m.id());
            d.progress.remove(m.id());
            d.completed.add(m.id());
            for (String a : m.onComplete()) Actions.run(p, a);
            p.displayClientMessage(net.minecraft.network.chat.Component.literal("Mission complete: " + m.title()), false);
            p.playNotifySound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, net.minecraft.sounds.SoundSource.PLAYERS, 0.5f, 1.2f);
        }
        d.mark();
        updateTracker(p, d);
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.tickCount % 10 != 0) return;
        FvData d = FvCap.get(p);
        if (!d.active() || !d.created) return;
        for (String id : new ArrayList<>(d.active.keySet())) {
            Mission m = MISSIONS.get(id);
            if (m == null) { d.active.remove(id); continue; }
            int idx = d.active.get(id);
            if (idx >= m.objectives().size()) continue;
            Obj o = m.objectives().get(idx);
            switch (o.type()) {
                case "go_to" -> {
                    BlockPos at = FrostveilWorld.poi((ServerLevel) p.level(), o.poi());
                    if (at != null && p.level().dimension().equals(Fv.WORLD) && p.position().distanceToSqr(at.getX() + 0.5, p.getY(), at.getZ() + 0.5) <= (double) o.radius() * o.radius()) advance(p, d, m);
                }
                case "wait" -> { if (d.progress.merge(id, 10, Integer::sum) >= o.count()) advance(p, d, m); }
                case "flag" -> { if (d.hasFlag(o.arg())) advance(p, d, m); }
                default -> { }
            }
        }
        if (p.tickCount % 40 == 0) {
            for (Mission m : MISSIONS.values()) {
                if (available(p, d, m) && !m.requires().isEmpty()) start(p, m.id());
            }
        }
    }

    public static void updateTracker(ServerPlayer p, FvData d) {
        String best = d.active.containsKey(d.tracked) ? d.tracked : (d.active.isEmpty() ? "" : d.active.keySet().iterator().next());
        d.tracked = best;
        d.trackedTitle = ""; d.trackedObj = ""; d.trackedPos = 0;
        Mission m = MISSIONS.get(best);
        if (m != null) {
            int idx = Math.min(d.active.get(best), m.objectives().size() - 1);
            Obj o = m.objectives().get(idx);
            int prog = d.progress.getOrDefault(best, 0);
            d.trackedTitle = m.title();
            d.trackedObj = o.text() + (o.type().equals("event") && o.count() > 1 ? "  (" + prog + "/" + o.count() + ")" : "");
            if (o.type().equals("go_to") && p.level() instanceof ServerLevel sl) {
                BlockPos at = FrostveilWorld.poi(sl, o.poi());
                if (at != null) d.trackedPos = at.asLong();
            }
        }
        d.mark();
    }

    /** Journal screen content: active, available-but-blocked (with hints), done, and coming (stub) missions. */
    public static CompoundTag journal(ServerPlayer p) {
        FvData d = FvCap.get(p);
        CompoundTag out = new CompoundTag();
        ListTag list = new ListTag();
        for (Mission m : MISSIONS.values()) {
            CompoundTag t = new CompoundTag();
            t.putString("id", m.id()); t.putString("title", m.title()); t.putInt("arc", m.arc()); t.putString("desc", m.desc());
            String status;
            if (d.done(m.id())) status = "done";
            else if (d.active.containsKey(m.id())) {
                status = "active";
                int idx = Math.min(d.active.get(m.id()), m.objectives().size() - 1);
                t.putString("obj", m.objectives().get(idx).text());
            } else if (m.stub()) status = "coming";
            else {
                boolean ok = true;
                for (String c : m.requires()) if (!meets(p, d, c)) { ok = false; break; }
                status = ok ? "ready" : "locked";
                t.putString("hint", m.hint());
            }
            t.putString("status", status);
            list.add(t);
        }
        out.put("list", list);
        return out;
    }

    static CompoundTag unused() { return new CompoundTag(); }

    static FvNet unusedNet() { return null; }
}
