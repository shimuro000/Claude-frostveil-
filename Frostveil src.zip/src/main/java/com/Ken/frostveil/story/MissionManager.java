package com.Ken.frostveil.story;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.world.FrostveilWorld;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Data-driven story engine (design follows the author's mission schema, with DragonMineZ's idea of a requirement tree).
 * Missions live in data/frostveil/missions/*.json. A mission has requirements, ordered objectives (go to a place, make a game event
 * happen N times, wait, wait for a flag) and actions that run when it starts, when objectives finish and when it completes.
 */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class MissionManager {
    public record Obj(String type, String poi, int radius, String event, String arg, int count, String text, List<String> onDone, String target, int timeout) {}
    private record Target(BlockPos pos, String npc) {}
    public record Mission(String id, String title, int arc, String desc, List<String> requires, String hint, List<String> onStart, List<String> onComplete, List<Obj> objectives, boolean stub, int delay, boolean restart, int restartObj, List<String> restartActions) {}

    private static final Map<String, Mission> MISSIONS = new LinkedHashMap<>();

    private MissionManager() {}

    @SubscribeEvent
    public static void reload(AddReloadListenerEvent e) {
        e.addListener(new SimpleJsonResourceReloadListener(new Gson(), "missions") {
            @Override
            protected void apply(Map<ResourceLocation, JsonElement> map, ResourceManager rm, ProfilerFiller pf) {
                MISSIONS.clear();
                List<ResourceLocation> keys = new ArrayList<>(map.keySet());
                keys.sort(ResourceLocation::compareTo);
                for (ResourceLocation k : keys) {
                    try {
                        JsonObject root = map.get(k).getAsJsonObject();
                        for (JsonElement me : root.getAsJsonArray("missions")) {
                            Mission m = parse(me.getAsJsonObject());
                            MISSIONS.put(m.id(), m);
                        }
                    } catch (Exception ex) {
                        Frostveil.LOG.error("Bad mission file {}: {}", k, ex.toString());
                    }
                }
                Frostveil.LOG.info("Frostveil: loaded {} missions", MISSIONS.size());
            }
        });
    }

    private static List<String> strs(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o.has(key)) for (JsonElement e : o.getAsJsonArray(key)) out.add(e.getAsString());
        return out;
    }

    private static String str(JsonObject o, String key, String def) { return o.has(key) ? o.get(key).getAsString() : def; }

    private static Mission parse(JsonObject o) {
        List<Obj> objs = new ArrayList<>();
        if (o.has("objectives")) {
            for (JsonElement e : o.getAsJsonArray("objectives")) {
                JsonObject j = e.getAsJsonObject();
                objs.add(new Obj(str(j, "type", "event"), str(j, "poi", ""), j.has("radius") ? j.get("radius").getAsInt() : 5, str(j, "event", ""), str(j, "arg", ""),
                        j.has("count") ? j.get("count").getAsInt() : 1, str(j, "text", ""), strs(j, "on_done"), str(j, "target", ""), j.has("timeout") ? j.get("timeout").getAsInt() : 0));
            }
        }
        return new Mission(o.get("id").getAsString(), str(o, "title", "?"), o.has("arc") ? o.get("arc").getAsInt() : 1, str(o, "desc", ""), strs(o, "requires"),
                str(o, "hint", ""), strs(o, "on_start"), strs(o, "on_complete"), objs, o.has("stub") && o.get("stub").getAsBoolean(),
                o.has("delay") ? o.get("delay").getAsInt() : 0, o.has("restart") && o.get("restart").getAsBoolean(), o.has("restart_obj") ? o.get("restart_obj").getAsInt() : 0, strs(o, "restart_actions"));
    }

    public static Mission get(String id) { return MISSIONS.get(id); }
    public static Iterable<Mission> all() { return MISSIONS.values(); }

    // ---------- requirements ----------

    public static boolean meets(ServerPlayer p, FvData d, String cond) {
        boolean neg = cond.startsWith("!");
        String c = neg ? cond.substring(1) : cond;
        int i = c.indexOf(':');
        String k = i < 0 ? c : c.substring(0, i), v = i < 0 ? "" : c.substring(i + 1);
        boolean r = switch (k) {
            case "done" -> d.done(v);
            case "active" -> d.active.containsKey(v);
            case "flag" -> d.hasFlag(v);
            case "mode" -> v.equals("story") ? d.mode == FvData.MODE_STORY : d.mode == FvData.MODE_FREE;
            case "awakened" -> d.awakened;
            case "obj" -> { // obj:missionId|index
                String[] a = v.split("\\|");
                yield a.length == 2 && d.active.containsKey(a[0]) && d.active.get(a[0]) == Integer.parseInt(a[1]);
            }
            default -> true;
        };
        return neg != r;
    }

    private static boolean available(ServerPlayer p, FvData d, Mission m) {
        if (m.stub() || d.done(m.id()) || d.active.containsKey(m.id())) return false;
        for (String c : m.requires()) if (!meets(p, d, c)) return false;
        if (m.delay() > 0) { // pacing: wait a while after the mission this one follows
            long last = 0;
            for (String c : m.requires()) if (c.startsWith("done:")) last = Math.max(last, d.doneAt.getOrDefault(c.substring(5), 0L));
            if (last > 0 && p.level().getGameTime() - last < m.delay()) return false;
        }
        return true;
    }

    /** Dying inside a fight restarts that mission (from the objective it names), so a death never leaves the story broken. */
    @SubscribeEvent
    public static void respawned(net.minecraftforge.event.entity.player.PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        FvData d = FvCap.get(p);
        for (String id : new ArrayList<>(d.active.keySet())) {
            Mission m = MISSIONS.get(id);
            if (m == null || !m.restart()) continue;
            d.active.put(id, Math.min(m.restartObj(), Math.max(0, m.objectives().size() - 1)));
            d.progress.put(id, 0);
            d.objTimers.clear();
            for (String a : m.restartActions()) Actions.run(p, a);
            p.displayClientMessage(net.minecraft.network.chat.Component.literal("You wake up. The mission restarts: " + m.title()), false);
            d.mark();
            updateTracker(p, d);
        }
    }

    // ---------- lifecycle ----------

    public static void begin(ServerPlayer p) { start(p, "arc1_01"); }

    public static void start(ServerPlayer p, String id) {
        FvData d = FvCap.get(p);
        Mission m = MISSIONS.get(id);
        if (m == null || d.active.containsKey(id) || d.done(id)) return;
        d.active.put(id, 0);
        d.progress.put(id, 0);
        d.mark();
        for (String a : m.onStart()) Actions.run(p, a);
        p.displayClientMessage(net.minecraft.network.chat.Component.literal("New mission: " + m.title()), false);
        updateTracker(p, d);
    }

    /** Game events feed missions: "ice_cast", "kill", "talk", "feel_core", "wall_built", ... */
    public static void event(ServerPlayer p, String type, String arg) {
        FvData d = FvCap.get(p);
        if (!d.inStory() && !d.active()) return;
        for (String id : new ArrayList<>(d.active.keySet())) {
            Mission m = MISSIONS.get(id);
            if (m == null) continue;
            int idx = d.active.get(id);
            if (idx >= m.objectives().size()) continue;
            Obj o = m.objectives().get(idx);
            if (!o.type().equals("event") || !o.event().equals(type)) continue;
            if (!o.arg().isEmpty() && !o.arg().equals(arg)) continue;
            int n = d.progress.merge(id, 1, Integer::sum);
            d.mark();
            if (n >= o.count()) advance(p, d, m);
            else updateTracker(p, d);
        }
    }

    private static void advance(ServerPlayer p, FvData d, Mission m) {
        int idx = d.active.get(m.id());
        Obj done = m.objectives().get(idx);
        d.active.put(m.id(), idx + 1);
        d.progress.put(m.id(), 0);
        for (String a : done.onDone()) Actions.run(p, a);
        if (idx + 1 >= m.objectives().size()) {
            d.active.remove(m.id());
            d.progress.remove(m.id());
            d.completed.add(m.id());
            d.doneAt.put(m.id(), p.level().getGameTime());
            for (String a : m.onComplete()) Actions.run(p, a);
            p.displayClientMessage(net.minecraft.network.chat.Component.literal("Mission complete: " + m.title()), false);
            p.playNotifySound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, net.minecraft.sounds.SoundSource.PLAYERS, 0.5f, 1.2f);
        }
        d.mark();
        updateTracker(p, d);
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p) || p.tickCount % 10 != 0) return;
        FvData d = FvCap.get(p);
        if (!d.active() || !d.created) return;
        for (String id : new ArrayList<>(d.active.keySet())) {
            Mission m = MISSIONS.get(id);
            if (m == null) { d.active.remove(id); continue; }
            int idx = d.active.get(id);
            if (idx >= m.objectives().size()) continue;
            Obj o = m.objectives().get(idx);
            switch (o.type()) {
                case "go_to" -> {
                    BlockPos at = Actions.where((ServerLevel) p.level(), p, o.poi());
                    if (at != null && p.level().dimension().equals(Fv.WORLD) && p.position().distanceToSqr(at.getX() + 0.5, p.getY(), at.getZ() + 0.5) <= (double) o.radius() * o.radius()) advance(p, d, m);
                }
                case "wait" -> { if (d.progress.merge(id, 10, Integer::sum) >= o.count()) advance(p, d, m); }
                case "flag" -> { if (d.hasFlag(o.arg())) advance(p, d, m); }
                default -> { }
            }
        }
        long now = p.level().getGameTime();
        for (String id : new ArrayList<>(d.active.keySet())) { // stuck-breaker: objectives with a timeout resolve themselves
            Mission m = MISSIONS.get(id);
            if (m == null) continue;
            int idx = d.active.get(id);
            if (idx >= m.objectives().size()) continue;
            Obj o = m.objectives().get(idx);
            long st = d.objTimers.computeIfAbsent(id + "#" + idx, k -> now);
            if (o.timeout() > 0 && now - st > o.timeout()) { advance(p, d, m); }
        }
        if (p.tickCount % 20 == 0) refreshTracker(p, d);
        if (p.tickCount % 40 == 0) {
            for (Mission m : MISSIONS.values()) {
                if (available(p, d, m) && !m.requires().isEmpty()) start(p, m.id());
            }
        }
    }

    private static Target resolve(ServerPlayer p, Obj o) {
        ServerLevel sl = p.serverLevel();
        String poiName = !o.target().isEmpty() ? o.target() : o.poi();
        if (o.type().equals("event") && o.event().equals("talk") && !o.arg().isEmpty()) {
            com.Ken.frostveil.entity.FvNpcEntity best = null;
            double bd = Double.MAX_VALUE;
            for (com.Ken.frostveil.entity.FvNpcEntity n : sl.getEntitiesOfClass(com.Ken.frostveil.entity.FvNpcEntity.class, p.getBoundingBox().inflate(300))) {
                if (!n.npcId().equals(o.arg())) continue;
                double dd = n.distanceToSqr(p);
                if (dd < bd) { bd = dd; best = n; }
            }
            if (best != null) return new Target(best.blockPosition(), o.arg());
            BlockPos h = FrostveilWorld.poi(sl, com.Ken.frostveil.entity.NpcDefs.get(o.arg()).home());
            return h == null ? null : new Target(h, o.arg());
        }
        if (o.event().startsWith("fargas")) {
            com.Ken.frostveil.entity.FargasEntity best = null;
            double bd = Double.MAX_VALUE;
            for (com.Ken.frostveil.entity.FargasEntity f : sl.getEntitiesOfClass(com.Ken.frostveil.entity.FargasEntity.class, p.getBoundingBox().inflate(300))) {
                double dd = f.distanceToSqr(p);
                if (dd < bd) { bd = dd; best = f; }
            }
            if (best != null) return new Target(best.blockPosition(), "");
        }
        if (o.event().equals("kill") || o.event().equals("spar_end")) {
            com.Ken.frostveil.entity.FvNpcEntity best = null;
            double bd = Double.MAX_VALUE;
            for (com.Ken.frostveil.entity.FvNpcEntity n : sl.getEntitiesOfClass(com.Ken.frostveil.entity.FvNpcEntity.class, p.getBoundingBox().inflate(300))) {
                if (!n.isHostileTo(p)) continue;
                double dd = n.distanceToSqr(p);
                if (dd < bd) { bd = dd; best = n; }
            }
            if (best != null) return new Target(best.blockPosition(), "");
        }
        if (!poiName.isEmpty()) {
            BlockPos at = Actions.where(sl, p, poiName);
            if (at != null) return new Target(at, "");
        }
        return null;
    }

    /** Re-aim the compass (NPCs walk around) without spamming syncs: only marks dirty when something changed. */
    public static void refreshTracker(ServerPlayer p, FvData d) {
        Mission m = MISSIONS.get(d.tracked);
        if (m == null || !d.active.containsKey(d.tracked) || m.objectives().isEmpty()) return;
        int idx = Math.min(d.active.get(d.tracked), m.objectives().size() - 1);
        Target t = resolve(p, m.objectives().get(idx));
        long pos = t == null ? 0 : t.pos().asLong();
        String npc = t == null ? "" : t.npc();
        if (pos != d.trackedPos || !npc.equals(d.trackedNpc)) { d.trackedPos = pos; d.trackedNpc = npc; d.mark(); }
    }

    public static void updateTracker(ServerPlayer p, FvData d) {
        String best = d.active.containsKey(d.tracked) ? d.tracked : (d.active.isEmpty() ? "" : d.active.keySet().iterator().next());
        d.tracked = best;
        d.trackedTitle = ""; d.trackedObj = ""; d.trackedPos = 0; d.trackedNpc = "";
        Mission m = MISSIONS.get(best);
        if (m != null && !m.objectives().isEmpty()) {
            int idx = Math.min(d.active.get(best), m.objectives().size() - 1);
            Obj o = m.objectives().get(idx);
            int prog = d.progress.getOrDefault(best, 0);
            d.trackedTitle = m.title();
            d.trackedObj = o.text() + (o.type().equals("event") && o.count() > 1 ? "  (" + prog + "/" + o.count() + ")" : "");
            Target t = resolve(p, o);
            if (t != null) { d.trackedPos = t.pos().asLong(); d.trackedNpc = t.npc(); }
        }
        d.mark();
    }

    /** Emergency button (journal): finish the current objective of the tracked mission. */
    public static void skip(ServerPlayer p) {
        FvData d = FvCap.get(p);
        Mission m = MISSIONS.get(d.tracked);
        if (m == null || !d.active.containsKey(d.tracked)) { com.Ken.frostveil.eiu.ServerActions.msg(p, "No active objective to skip."); return; }
        advance(p, d, m);
        com.Ken.frostveil.eiu.ServerActions.msg(p, "Objective skipped.");
    }

    /** Journal screen content: active, available-but-blocked (with hints), done, and coming (stub) missions. */
    public static CompoundTag journal(ServerPlayer p) {
        FvData d = FvCap.get(p);
        CompoundTag out = new CompoundTag();
        ListTag list = new ListTag();
        for (Mission m : MISSIONS.values()) {
            CompoundTag t = new CompoundTag();
            t.putString("id", m.id()); t.putString("title", m.title()); t.putInt("arc", m.arc()); t.putString("desc", m.desc());
            String status;
            if (d.done(m.id())) status = "done";
            else if (d.active.containsKey(m.id())) {
                status = "active";
                int idx = Math.min(d.active.get(m.id()), m.objectives().size() - 1);
                t.putString("obj", m.objectives().get(idx).text());
            } else if (m.stub()) status = "coming";
            else {
                boolean ok = true;
                for (String c : m.requires()) if (!meets(p, d, c)) { ok = false; break; }
                status = ok ? "ready" : "locked";
                t.putString("hint", m.hint());
            }
            t.putString("status", status);
            list.add(t);
        }
        out.put("list", list);
        return out;
    }

    static CompoundTag unused() { return new CompoundTag(); }

    static FvNet unusedNet() { return null; }
}
