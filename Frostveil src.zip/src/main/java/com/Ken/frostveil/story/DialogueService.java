package com.Ken.frostveil.story;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.Frostveil;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.network.FvNet;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Dialogue from data/frostveil/dialogues/*.json. An entry is picked per NPC by its "if" conditions (first match wins,
 * list specific entries before the default one). Nodes have speaker, text, optional choices and "actions".
 */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class DialogueService {
    private record State(String dialogue, String node, int entityId, String npc) {}

    private static final Map<String, JsonObject> DIALOGUES = new LinkedHashMap<>();
    private static final Map<UUID, State> OPEN = new HashMap<>();

    private DialogueService() {}

    @SubscribeEvent
    public static void reload(AddReloadListenerEvent e) {
        e.addListener(new SimpleJsonResourceReloadListener(new Gson(), "dialogues") {
            @Override
            protected void apply(Map<ResourceLocation, JsonElement> map, ResourceManager rm, ProfilerFiller pf) {
                DIALOGUES.clear();
                List<ResourceLocation> keys = new ArrayList<>(map.keySet());
                keys.sort(ResourceLocation::compareTo);
                for (ResourceLocation k : keys) {
                    try {
                        for (JsonElement de : map.get(k).getAsJsonObject().getAsJsonArray("dialogues")) {
                            JsonObject o = de.getAsJsonObject();
                            DIALOGUES.put(o.get("id").getAsString(), o);
                        }
                    } catch (Exception ex) {
                        Frostveil.LOG.error("Bad dialogue file {}: {}", k, ex.toString());
                    }
                }
                Frostveil.LOG.info("Frostveil: loaded {} dialogues", DIALOGUES.size());
            }
        });
    }

    public static void open(ServerPlayer p, FvNpcEntity npc) {
        FvData d = FvCap.get(p);
        String picked = null;
        for (JsonObject o : DIALOGUES.values()) {
            if (!o.get("npc").getAsString().equals(npc.npcId())) continue;
            boolean ok = true;
            if (o.has("if")) for (JsonElement c : o.getAsJsonArray("if")) if (!MissionManager.meets(p, d, c.getAsString())) { ok = false; break; }
            if (!ok) continue;
            picked = o.get("id").getAsString();
            break;
        }
        // choose the lines first (they may depend on the current objective), then let the talk count for missions
        if (picked != null) start(p, picked, npc.getId()); else com.Ken.frostveil.eiu.ServerActions.msg(p, "...");
        MissionManager.event(p, "talk", npc.npcId());
    }

    public static void start(ServerPlayer p, String id, int entityId) {
        JsonObject o = DIALOGUES.get(id);
        if (o == null) return;
        String node = o.has("start") ? o.get("start").getAsString() : "a";
        String npc = o.get("npc").getAsString();
        enter(p, new State(id, node, entityId, npc));
    }

    private static void enter(ServerPlayer p, State st) {
        JsonObject o = DIALOGUES.get(st.dialogue());
        JsonObject n = o.getAsJsonObject("nodes").getAsJsonObject(st.node());
        if (n == null) { close(p, st); return; }
        if (n.has("actions")) for (JsonElement a : n.getAsJsonArray("actions")) Actions.run(p, a.getAsString());
        OPEN.put(p.getUUID(), st);
        CompoundTag t = new CompoundTag();
        t.putString("speaker", n.has("speaker") ? n.get("speaker").getAsString() : st.npc());
        t.putString("npc", st.npc());
        t.putString("text", n.get("text").getAsString());
        ListTag ch = new ListTag();
        if (n.has("choices")) for (JsonElement c : n.getAsJsonArray("choices")) {
            JsonObject co = c.getAsJsonObject();
            boolean ok = true;
            if (co.has("if")) for (JsonElement cc : co.getAsJsonArray("if")) if (!MissionManager.meets(p, FvCap.get(p), cc.getAsString())) { ok = false; break; }
            ch.add(StringTag.valueOf(ok ? co.get("text").getAsString() : "\u0000"));
        }
        t.put("choices", ch);
        FvNet.toPlayer(p, new FvNet.DialogueMsg(st.entityId(), t));
    }

    public static void choose(ServerPlayer p, int entityId, int idx) {
        State st = OPEN.get(p.getUUID());
        if (st == null) return;
        JsonObject n = DIALOGUES.get(st.dialogue()).getAsJsonObject("nodes").getAsJsonObject(st.node());
        String next = n.has("next") ? n.get("next").getAsString() : "";
        if (n.has("choices")) {
            JsonArray cs = n.getAsJsonArray("choices");
            if (idx < 0 || idx >= cs.size()) return;
            JsonObject c = cs.get(idx).getAsJsonObject();
            if (c.has("actions")) for (JsonElement a : c.getAsJsonArray("actions")) Actions.run(p, a.getAsString());
            if (c.has("trust")) FvCap.get(p).addTrust(st.npc(), c.get("trust").getAsInt());
            next = c.has("next") ? c.get("next").getAsString() : "";
        }
        if (next.isEmpty() || next.equals("end")) close(p, st);
        else enter(p, new State(st.dialogue(), next, st.entityId(), st.npc()));
    }

    private static void close(ServerPlayer p, State st) {
        OPEN.remove(p.getUUID());
        FvNet.toPlayer(p, new FvNet.DialogueMsg(st.entityId(), new CompoundTag()));
        MissionManager.event(p, "dialogue_end", st.dialogue());
    }

    static Entity unused() { return null; }
}
