package com.Ken.frostveil.story;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.entity.EiuBeastEntity;
import com.Ken.frostveil.entity.FargasEntity;
import com.Ken.frostveil.entity.FvNpcEntity;
import com.Ken.frostveil.ice.ShapeSpec;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.world.FrostveilWorld;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * The tiny script language used by mission and dialogue JSON.  Format: "type:payload"; payload parts are split with '|'.
 * e.g. "give:frostveil:small_axe|1", "spawn_npc:kaina|kaina_house", "caption:Dawn in Tatsuma|120|false", "flag:met_awi".
 */
public final class Actions {
    private Actions() {}

    public static void run(ServerPlayer p, String action) {
        FvData d = FvCap.get(p);
        ServerLevel level = p.serverLevel();
        int i = action.indexOf(':');
        String type = i < 0 ? action : action.substring(0, i);
        String[] a = (i < 0 ? "" : action.substring(i + 1)).split("\\|");
        try {
            switch (type) {
                case "caption" -> FvNet.toPlayer(p, new FvNet.CaptionMsg(a[0].replace("\\n", "\n"), a.length > 1 ? Integer.parseInt(a[1]) : 100, a.length > 2 && a[2].equals("true")));
                case "msg" -> p.displayClientMessage(Component.literal(a[0]), true);
                case "flag" -> d.setFlag(a[0]);
                case "unflag" -> { d.flags.remove(a[0]); d.mark(); }
                case "give" -> {
                    Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(a[0]));
                    if (it != null) { ItemStack st = new ItemStack(it, a.length > 1 ? Integer.parseInt(a[1]) : 1); if (!p.getInventory().add(st)) p.drop(st, false); }
                }
                case "take" -> {
                    Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(a[0]));
                    if (it != null) p.getInventory().clearOrCountMatchingItems(s -> s.is(it), a.length > 1 ? Integer.parseInt(a[1]) : 1, p.inventoryMenu.getCraftSlots());
                }
                case "spawn_npc" -> {
                    BlockPos at = FrostveilWorld.poi(level, a.length > 1 ? a[1] : "center");
                    if (at != null) { FvNpcEntity n = FvNpcEntity.spawn(level, a[0], at); if (a.length > 2 && a[2].equals("hostile")) n.setHostile(true); }
                }
                case "remove_npc" -> {
                    for (FvNpcEntity n : level.getEntitiesOfClass(FvNpcEntity.class, p.getBoundingBox().inflate(150))) if (n.npcId().equals(a[0])) n.discard();
                }
                case "npc_pose" -> {
                    for (FvNpcEntity n : level.getEntitiesOfClass(FvNpcEntity.class, p.getBoundingBox().inflate(150))) if (n.npcId().equals(a[0])) n.setNpcPose(Integer.parseInt(a[1]));
                }
                case "spawn_mob" -> {
                    BlockPos at = FrostveilWorld.poi(level, a.length > 1 ? a[1] : "center");
                    if (at == null) return;
                    switch (a[0]) {
                        case "fargas" -> {
                            FargasEntity f = new FargasEntity(ModEntities.FARGAS.get(), level);
                            f.moveTo(at.getX() + 0.5, at.getY(), at.getZ() + 0.5, 0, 0);
                            f.script(a.length > 2 ? Integer.parseInt(a[2]) : 0, a.length > 3 ? Integer.parseInt(a[3]) : 900);
                            level.addFreshEntity(f);
                        }
                        case "ash_knight" -> {
                            int n = a.length > 2 ? Integer.parseInt(a[2]) : 3;
                            for (int k = 0; k < n; k++) FvNpcEntity.spawn(level, "ash_knight", at.offset(level.random.nextInt(7) - 3, 0, level.random.nextInt(7) - 3)).setHostile(true);
                        }
                        case "beast" -> EiuBeastEntity.spawn(level, a.length > 2 ? Integer.parseInt(a[2]) : 0, at);
                        default -> { }
                    }
                }
                case "unlock_prim" -> { for (ShapeSpec.Prim pr : ShapeSpec.Prim.values()) if (pr.key.equals(a[0])) d.unlockPrim(pr); }
                case "unlock_form" -> { d.unlockedForms |= 1 << Integer.parseInt(a[0]); d.mark(); }
                case "stat" -> {
                    int v = Integer.parseInt(a[1]);
                    switch (a[0]) {
                        case "ctrlMental" -> d.ctrlMental = Math.min(10, d.ctrlMental + v);
                        case "ctrlPhysical" -> d.ctrlPhysical = Math.min(10, d.ctrlPhysical + v);
                        case "ctrlExternal" -> d.ctrlExternal = Math.min(10, d.ctrlExternal + v);
                        case "quantity" -> { d.quantity += v; d.aura += v; }
                        case "output" -> d.output += v;
                        default -> { }
                    }
                    d.mark();
                }
                case "points" -> { d.points += Integer.parseInt(a[0]); d.mark(); }
                case "awaken" -> { d.awakened = true; d.mark(); }
                case "tech" -> {
                    int v = Integer.parseInt(a[1]);
                    switch (a[0]) {
                        case "skin_sense" -> d.skinSenseStage = Math.max(d.skinSenseStage, v);
                        case "forge" -> d.forgeStage = Math.max(d.forgeStage, v);
                        case "cutoff" -> d.cutoffStage = Math.max(d.cutoffStage, v);
                        case "infuse" -> d.infuseStage = Math.max(d.infuseStage, v);
                        default -> { }
                    }
                    d.mark();
                }
                case "age" -> { d.ageStage = Integer.parseInt(a[0]); p.refreshDimensions(); d.mark(); FvNet.broadcastAppearance(p); }
                case "party" -> {
                    List<String> cur = new java.util.ArrayList<>(List.of(d.party.isEmpty() ? new String[0] : d.party.split(",")));
                    if (a[0].equals("add") && !cur.contains(a[1])) {
                        cur.add(a[1]);
                        FvNpcEntity n = FvNpcEntity.spawn(level, a[1], p.blockPosition());
                        n.setOwner(p.getUUID());
                    } else if (a[0].equals("remove")) cur.remove(a[1]);
                    d.party = String.join(",", cur);
                    d.mark();
                }
                case "teleport" -> { BlockPos at = FrostveilWorld.poi(level, a[0]); if (at != null) p.teleportTo(level, at.getX() + 0.5, at.getY(), at.getZ() + 0.5, p.getYRot(), 0); }
                case "time" -> level.setDayTime(switch (a[0]) { case "dawn" -> 23000L; case "night" -> 14000L; default -> 6000L; });
                case "weather" -> { if (a[0].equals("snow")) level.setWeatherParameters(0, 6000, true, false); else level.setWeatherParameters(6000, 0, false, false); }
                case "burn_village" -> FrostveilWorld.damageVillage(level);
                case "mission" -> MissionManager.start(p, a[0]);
                case "dialogue" -> DialogueService.start(p, a[0], -1);
                default -> { }
            }
        } catch (RuntimeException ex) {
            com.Ken.frostveil.Frostveil.LOG.error("Bad story action '{}': {}", action, ex.toString());
        }
    }
}
