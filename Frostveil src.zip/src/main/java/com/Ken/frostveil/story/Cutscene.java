package com.Ken.frostveil.story;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.Frostveil;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Timed scenes (data/frostveil/scripts/*.json): a list of {t: tick, a: action} run in order. Used for story moments:
 * the stranger's encounter, waking on Awi's horse, the council meeting... Every action is one from story/Actions.java.
 */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class Cutscene {
    private record Step(int t, String action) {}

    private static final class Run {
        final List<Step> steps; final long start; int idx = 0;
        Run(List<Step> steps, long start) { this.steps = steps; this.start = start; }
    }

    private static final Map<String, List<Step>> SCRIPTS = new HashMap<>();
    private static final Map<UUID, List<Run>> RUNS = new HashMap<>();

    private Cutscene() {}

    @SubscribeEvent
    public static void reload(AddReloadListenerEvent e) {
        e.addListener(new SimpleJsonResourceReloadListener(new Gson(), "scripts") {
            @Override
            protected void apply(Map<ResourceLocation, JsonElement> map, ResourceManager rm, ProfilerFiller pf) {
                SCRIPTS.clear();
                for (Map.Entry<ResourceLocation, JsonElement> en : map.entrySet()) {
                    try {
                        for (JsonElement se : en.getValue().getAsJsonObject().getAsJsonArray("scripts")) {
                            JsonObject o = se.getAsJsonObject();
                            List<Step> steps = new ArrayList<>();
                            for (JsonElement st : o.getAsJsonArray("steps")) {
                                JsonObject j = st.getAsJsonObject();
                                steps.add(new Step(j.get("t").getAsInt(), j.get("a").getAsString()));
                            }
                            steps.sort((x, y) -> Integer.compare(x.t(), y.t()));
                            SCRIPTS.put(o.get("id").getAsString(), steps);
                        }
                    } catch (Exception ex) {
                        Frostveil.LOG.error("Bad script file {}: {}", en.getKey(), ex.toString());
                    }
                }
                Frostveil.LOG.info("Frostveil: loaded {} scripts", SCRIPTS.size());
            }
        });
    }

    public static void start(ServerPlayer p, String name) {
        List<Step> steps = SCRIPTS.get(name);
        if (steps == null) { Frostveil.LOG.error("Unknown script {}", name); return; }
        RUNS.computeIfAbsent(p.getUUID(), k -> new ArrayList<>()).add(new Run(steps, p.level().getGameTime()));
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        List<Run> runs = RUNS.get(p.getUUID());
        if (runs == null || runs.isEmpty()) return;
        long now = p.level().getGameTime();
        for (Run r : new ArrayList<>(runs)) {
            long el = now - r.start;
            while (r.idx < r.steps.size() && r.steps.get(r.idx).t() <= el) {
                Actions.run(p, r.steps.get(r.idx).action());
                r.idx++;
            }
            if (r.idx >= r.steps.size()) runs.remove(r);
        }
    }
}
