package com.Ken.frostveil.story;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.registry.ModBlocks;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** World events that feed missions (cutting Soma wood...). */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class StoryEvents {
    private StoryEvents() {}

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (e.getPlayer() instanceof ServerPlayer p && e.getState().is(ModBlocks.SOMA_LOG.get())) {
            MissionManager.event(p, "soma_cut", "");
        }
    }
}
