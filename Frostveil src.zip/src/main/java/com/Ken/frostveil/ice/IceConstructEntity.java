package com.Ken.frostveil.ice;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.eiu.Element;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModEntities;
import com.Ken.frostveil.story.MissionManager;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * An ice shape made by a player. One class, four states:
 * FORMING (grows in front of the hands: mental phase made visible), FLYING, HELD (a weapon in the hand), STUCK.
 * The synced ShapeSpec is the exact recipe the player designed; the client draws it with IceMesh.
 */
public class IceConstructEntity extends Projectile {
    public static final int FORMING = 0, FLYING = 1, HELD = 2, DONE = 3;
    private static final EntityDataAccessor<CompoundTag> SPEC = SynchedEntityData.defineId(IceConstructEntity.class, EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(IceConstructEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> ELEMENT = SynchedEntityData.defineId(IceConstructEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> FORM_TIME = SynchedEntityData.defineId(IceConstructEntity.class, EntityDataSerializers.INT);

    private ShapeSpec cached;
    private int releaseAt = 12;
    private float damage = 4f;
    private float density = 1f;
    private float cost = 0f;
    private int maxAge = 100;
    private int pierce = 0;
    private Vec3 aim = Vec3.ZERO;
    private int slot = 0, slots = 1;

    public IceConstructEntity(EntityType<? extends IceConstructEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    /** Spawn a shape for a player. slot/slots place it inside a volley fan. */
    public static IceConstructEntity create(ServerPlayer owner, ShapeSpec spec, float density, float damage, int state, int slot, int slots, int releaseDelay, Vec3 aim, String element, float cost) {
        IceConstructEntity e = new IceConstructEntity(ModEntities.ICE_CONSTRUCT.get(), owner.level());
        e.setOwner(owner);
        e.setSpec(spec);
        e.entityData.set(STATE, state);
        e.entityData.set(ELEMENT, element);
        e.density = density; e.damage = damage; e.slot = slot; e.slots = slots; e.releaseAt = releaseDelay; e.aim = aim; e.cost = cost;
        e.maxAge = state == HELD ? 20 * 20 : 20 * 5;
        e.pierce = spec.prim == ShapeSpec.Prim.LANCE ? 2 : 0;
        e.entityData.set(FORM_TIME, Math.max(4, releaseDelay));
        e.setPos(handPos(owner, slot, slots));
        return e;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(SPEC, new CompoundTag());
        entityData.define(STATE, FORMING);
        entityData.define(ELEMENT, "ice");
        entityData.define(FORM_TIME, 12);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SPEC.equals(key)) cached = null;
    }

    public void setSpec(ShapeSpec s) { entityData.set(SPEC, s.toTag()); cached = s.copy(); }
    public ShapeSpec spec() { if (cached == null) cached = ShapeSpec.fromTag(entityData.get(SPEC)); return cached; }
    public int state() { return entityData.get(STATE); }
    public String element() { return entityData.get(ELEMENT); }
    /** 0..1 growth while forming (client uses it to scale the mesh). */
    public float grow(float partial) {
        if (state() != FORMING) return 1f;
        return Mth.clamp((tickCount + partial) / (float) Math.max(1, entityData.get(FORM_TIME)), 0.05f, 1f);
    }
    public float heldDamage() { return damage; }
    public float cost() { return cost; }

    private static Vec3 handPos(ServerPlayer p, int slot, int slots) {
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        double off = slots <= 1 ? 0 : (slot - (slots - 1) / 2.0) * 0.45;
        return p.getEyePosition().add(look.scale(1.1)).add(right.scale(0.35 + off)).add(0, -0.45 + Math.abs(off) * 0.12, 0);
    }

    @Override
    public void tick() {
        super.tick();
        Entity ownerE = getOwner();
        int state = state();
        if (level().isClientSide) {
            if (state == FLYING) {
                Vec3 v = getDeltaMovement();
                level().addParticle(Element.particle(element()), getX(), getY(), getZ(), -v.x * 0.1, 0.02, -v.z * 0.1);
                if (tickCount % 2 == 0) level().addParticle(ParticleTypes.SNOWFLAKE, getX(), getY(), getZ(), 0, 0, 0);
            }
            return;
        }
        if (!(ownerE instanceof ServerPlayer owner) || !owner.isAlive()) { shatter(); return; }
        if (tickCount > maxAge) { shatter(); return; }
        FvData d = FvCap.get(owner);

        if (state == FORMING || state == HELD) {
            // follow the hands; face where the owner looks
            Vec3 target = handPos(owner, slot, slots);
            setPos(target);
            setYRot(owner.getYRot());
            setXRot(owner.getXRot());
            if (state == HELD) {
                if (d.focus < 15) { // Law 5: a rattled mind cannot hold the shape
                    ((ServerLevel) level()).sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()), getX(), getY(), getZ(), 14, 0.3, 0.3, 0.3, 0.1);
                    shatter();
                }
                return;
            }
            if (tickCount >= releaseAt) launch(owner);
            return;
        }
        if (state == FLYING) {
            Vec3 v = getDeltaMovement();
            // aimed in forward direction; slight arc for heavy shapes
            setDeltaMovement(v.add(0, -0.004 * spec().length, 0));
            HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
            if (hit.getType() != HitResult.Type.MISS) {
                if (hit instanceof EntityHitResult ehr) onHitEntity(ehr); else if (hit instanceof BlockHitResult bhr) onHitBlock(bhr);
                if (!isAlive()) return;
            }
            Vec3 now = position().add(getDeltaMovement());
            setPos(now);
            Vec3 dv = getDeltaMovement();
            setYRot((float) (Mth.atan2(dv.x, dv.z) * (180.0 / Math.PI)));
            setXRot((float) (Mth.atan2(dv.y, dv.horizontalDistance()) * (180.0 / Math.PI)) * -1f);
        }
    }

    private void launch(ServerPlayer owner) {
        entityData.set(STATE, FLYING);
        Vec3 dir = aim.lengthSqr() < 1.0E-4 ? owner.getLookAngle() : aim;
        float spd = (1.25f + 0.35f * density - 0.08f * spec().length) * com.Ken.frostveil.eiu.ElementInfo.speedMul(element());
        setDeltaMovement(dir.normalize().scale(Math.max(0.7f, spd)));
        tickCount = 0;
        maxAge = 70;
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.PLAYERS, 0.9f, 1.4f + random.nextFloat() * 0.3f);
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.5f, 1.6f);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        if (!(getOwner() instanceof ServerPlayer owner) || !(target instanceof LivingEntity living)) return;
        FvData d = FvCap.get(owner);
        boolean dealt = living.hurt(damageSources().indirectMagic(this, owner), damage);
        if (dealt) {
            String el = element();
            Vec3 push = getDeltaMovement().normalize();
            double kb = 0.35 + density * 0.12;
            switch (el) {
                case "fire" -> living.setSecondsOnFire(4);
                case "lightning" -> { living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 24, 4)); ((ServerLevel) level()).sendParticles(ParticleTypes.ELECTRIC_SPARK, living.getX(), living.getY() + 1, living.getZ(), 14, 0.3, 0.6, 0.3, 0.2); }
                case "wind" -> { kb *= 2.0; living.setDeltaMovement(living.getDeltaMovement().add(0, 0.35, 0)); }
                case "earth" -> { kb *= 1.3; living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 50, 1)); }
                case "water" -> { living.clearFire(); living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 40, 1)); }
                default -> living.setTicksFrozen(Math.min(living.getTicksRequiredToFreeze() + 60, living.getTicksFrozen() + 50));
            }
            living.knockback(kb, -push.x, -push.z);
            living.invulnerableTime = Math.min(living.invulnerableTime, 6);
            float strength = Mth.clamp(damage / 12f, 0.2f, 1f);
            ServerLevel sl = (ServerLevel) level();
            FvNet.toNear(sl, target.getX(), target.getY(), target.getZ(), 48,
                    new FvNet.ImpactMsg(target.getId(), (float) result.getLocation().x, (float) result.getLocation().y, (float) result.getLocation().z, strength, element(), spec().count > 2 ? 0 : 1, damage));
            sl.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.9f, 1.1f + random.nextFloat() * 0.3f);
            MissionManager.event(owner, "ice_hit", living.getType().builtInRegistryHolder().key().location().getPath());
            if (!living.isAlive()) {
                FvNet.toNear(sl, target.getX(), target.getY(), target.getZ(), 48, new FvNet.ImpactMsg(target.getId(), (float) target.getX(), (float) target.getY() + 0.8f, (float) target.getZ(), 0.8f, element(), 3, damage));
            }
        }
        if (pierce-- <= 0) shatter();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        ServerLevel sl = (ServerLevel) level();
        Vec3 p = result.getLocation();
        FvNet.toNear(sl, p.x, p.y, p.z, 48, new FvNet.ImpactMsg(-1, (float) p.x, (float) p.y, (float) p.z, 0.35f, element(), 3, 0));
        shatter();
    }

    public void shatter() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()), getX(), getY(), getZ(), 16, 0.25, 0.25, 0.25, 0.12);
            sl.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY(), getZ(), 10, 0.3, 0.3, 0.3, 0.05);
            sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.6f, 1.2f);
        }
        discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) { discard(); } // constructs never persist

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
