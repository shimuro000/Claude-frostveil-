package com.Ken.frostveil.ice;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.registry.ModEntities;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkHooks;

/**
 * Snowmaker's field: a patch of falling snow. Snow settles on the ground, slows enemies and hides vision;
 * the owner (and allies) spend less aura for ice inside and sense vibrations further (Skin Sense bonus).
 */
public class SnowFieldEntity extends Entity {
    private static final EntityDataAccessor<Float> RADIUS = SynchedEntityData.defineId(SnowFieldEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<String> ELEMENT = SynchedEntityData.defineId(SnowFieldEntity.class, EntityDataSerializers.STRING);
    private int duration = 300;
    private java.util.UUID owner;

    public SnowFieldEntity(EntityType<? extends SnowFieldEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
    }

    public static SnowFieldEntity create(ServerPlayer owner, BlockPos at, float radius, int duration, String element) {
        SnowFieldEntity e = new SnowFieldEntity(ModEntities.SNOW_FIELD.get(), owner.level());
        e.owner = owner.getUUID();
        e.duration = duration;
        e.entityData.set(RADIUS, radius);
        e.entityData.set(ELEMENT, element);
        e.setPos(at.getX() + 0.5, at.getY(), at.getZ() + 0.5);
        return e;
    }

    public float radius() { return entityData.get(RADIUS); }

    @Override
    protected void defineSynchedData() { entityData.define(RADIUS, 3f); entityData.define(ELEMENT, "ice"); }

    public String element() { return entityData.get(ELEMENT); }

    @Override
    public void tick() {
        super.tick();
        float r = radius();
        if (level().isClientSide) {
            for (int i = 0; i < 6; i++) {
                double a = random.nextDouble() * Math.PI * 2, d = Math.sqrt(random.nextDouble()) * r;
                double px = getX() + Math.cos(a) * d, pz = getZ() + Math.sin(a) * d;
                switch (element()) {
                    case "fire" -> level().addParticle(ParticleTypes.FLAME, px, getY() + random.nextDouble() * 0.5, pz, 0, 0.08, 0);
                    case "wind" -> level().addParticle(ParticleTypes.CLOUD, px, getY() + random.nextDouble() * 2, pz, -Math.sin(a) * 0.12, 0.05, Math.cos(a) * 0.12);
                    case "lightning" -> level().addParticle(ParticleTypes.ELECTRIC_SPARK, px, getY() + 0.3 + random.nextDouble() * 2, pz, 0, 0, 0);
                    case "water" -> level().addParticle(ParticleTypes.SPLASH, px, getY() + 3.0 + random.nextDouble(), pz, 0, -0.2, 0);
                    case "earth" -> level().addParticle(ParticleTypes.CRIT, px, getY() + 0.2, pz, 0, 0.15, 0);
                    default -> level().addParticle(ParticleTypes.SNOWFLAKE, px, getY() + 3.5 + random.nextDouble(), pz, 0, -0.18, 0);
                }
            }
            return;
        }
        if (tickCount > duration) { discard(); return; }
        ServerLevel sl = (ServerLevel) level();
        if (owner != null) {
            Entity o = sl.getEntity(owner);
            if (o instanceof ServerPlayer sp) sp.getPersistentData().putLong("fv_snow_until", sl.getGameTime() + 25);
        }
        String el = element();
        if (!el.equals("ice") && tickCount % 20 == 0) {
            for (LivingEntity q : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, 3, r))) {
                if (q.distanceToSqr(this) > r * r) continue;
                boolean mine = owner != null && q.getUUID().equals(owner);
                boolean friend = q instanceof Player || mine || (q instanceof com.Ken.frostveil.entity.FvNpcEntity f && !f.isRaider());
                if (el.equals("water") && friend) { q.heal(1.0f); sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, q.getX(), q.getY() + 1, q.getZ(), 3, 0.3, 0.3, 0.3, 0); continue; }
                if (friend) continue;
                switch (el) {
                    case "fire" -> { q.setSecondsOnFire(3); q.hurt(sl.damageSources().onFire(), 1.5f); }
                    case "wind" -> q.setDeltaMovement(q.getDeltaMovement().add((q.getX() - getX()) * 0.12, 0.45, (q.getZ() - getZ()) * 0.12));
                    case "lightning" -> { q.hurt(sl.damageSources().lightningBolt(), 4f); sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, q.getX(), q.getY() + 1, q.getZ(), 16, 0.3, 0.8, 0.3, 0.25); sl.playSound(null, q.getX(), q.getY(), q.getZ(), net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_IMPACT, net.minecraft.sounds.SoundSource.PLAYERS, 0.4f, 1.6f); }
                    case "earth" -> { q.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2, false, false)); sl.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()), q.getX(), q.getY(), q.getZ(), 10, 0.4, 0.1, 0.4, 0.1); }
                    case "water" -> q.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, false));
                    default -> { }
                }
            }
        }
        if (!el.equals("ice")) return; // other elements have no snow or freezing
        if (tickCount % 10 == 0) {
            List<LivingEntity> list = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, 3, r));
            for (LivingEntity e : list) {
                if (e instanceof Player || (owner != null && e.getUUID().equals(owner))) continue;
                if (e.distanceToSqr(this) <= r * r) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1, false, false));
                    e.setTicksFrozen(Math.min(e.getTicksRequiredToFreeze(), e.getTicksFrozen() + 20));
                }
            }
        }
        if (tickCount % 8 == 0) { // let snow settle
            double a = random.nextDouble() * Math.PI * 2, d = Math.sqrt(random.nextDouble()) * r;
            BlockPos top = sl.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlockPos.containing(getX() + Math.cos(a) * d, getY(), getZ() + Math.sin(a) * d));
            if (Math.abs(top.getY() - getY()) < 6 && sl.getBlockState(top).isAir() && Blocks.SNOW.defaultBlockState().canSurvive(sl, top)) {
                sl.setBlock(top, Blocks.SNOW.defaultBlockState(), 3);
            } else {
                BlockState st = sl.getBlockState(top);
                if (st.is(Blocks.SNOW) && st.getValue(SnowLayerBlock.LAYERS) < 3) sl.setBlock(top, st.setValue(SnowLayerBlock.LAYERS, st.getValue(SnowLayerBlock.LAYERS) + 1), 3);
            }
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) { discard(); }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) { }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
