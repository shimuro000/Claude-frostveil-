package com.Ken.frostveil.ice;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.MapColor;

/**
 * Ice made by Solid Shaper. It is not permanent: it cracks in four stages (frosted-ice textures) and then shatters.
 * LIFE decides how long one stage lasts, so denser / better-controlled ice lasts longer.
 */
public class ConjuredIceBlock extends Block {
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 3);
    public static final IntegerProperty LIFE = IntegerProperty.create("life", 0, 3);
    /** 0 ice, 1 fire, 2 earth, 3 wind, 4 water, 5 lightning (same block, different look and light) */
    public static final IntegerProperty ELEM = IntegerProperty.create("elem", 0, 5);
    private static final int[] STEP_TICKS = {30, 60, 110, 200};

    public ConjuredIceBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.ICE).strength(0.6f).friction(0.98f).sound(SoundType.GLASS)
                .noOcclusion().noLootTable().lightLevel(st -> st.getValue(ELEM) == 1 ? 11 : (st.getValue(ELEM) == 5 ? 8 : 0)).isValidSpawn((s, g, p, e) -> false).isViewBlocking((s, g, p) -> false));
        registerDefaultState(stateDefinition.any().setValue(AGE, 0).setValue(LIFE, 1).setValue(ELEM, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AGE, LIFE, ELEM);
    }

    /** Place a conjured block; lifeClass 0..3 picks the stage length. */
    public static boolean place(ServerLevel level, BlockPos pos, int lifeClass) { return place(level, pos, lifeClass, 0); }

    public static boolean place(ServerLevel level, BlockPos pos, int lifeClass, int elem) {
        BlockState state = com.Ken.frostveil.registry.ModBlocks.CONJURED_ICE.get().defaultBlockState().setValue(LIFE, Math.max(0, Math.min(3, lifeClass))).setValue(ELEM, Math.max(0, Math.min(5, elem)));
        if (!level.setBlock(pos, state, 3)) return false;
        level.scheduleTick(pos, state.getBlock(), STEP_TICKS[Math.max(0, Math.min(3, lifeClass))]);
        return true;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int age = state.getValue(AGE);
        int step = STEP_TICKS[state.getValue(LIFE)];
        if (level.getBiome(pos).value().getBaseTemperature() > 1.0f) step = Math.max(10, step / 2); // heat eats ice faster
        if (age < 3) {
            level.setBlock(pos, state.setValue(AGE, age + 1), 3);
            level.scheduleTick(pos, this, step);
            level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.15f, 1.6f + random.nextFloat() * 0.4f);
        } else {
            shatter(level, pos, state);
        }
    }

    public static void shatter(ServerLevel level, BlockPos pos, BlockState state) {
        level.removeBlock(pos, false);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()),
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 10, 0.3, 0.3, 0.3, 0.08);
        level.sendParticles(ParticleTypes.SNOWFLAKE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.02);
        level.playSound(null, pos, SoundEvents.GLASS_BREAK, SoundSource.BLOCKS, 0.5f, 1.3f);
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter getter, BlockPos pos) { return true; }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter getter, BlockPos pos) { return 1.0f; }

    @Override
    public boolean skipRendering(BlockState state, BlockState adjacent, Direction side) {
        return adjacent.is(this) || super.skipRendering(state, adjacent, side);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && !old.is(this)) {
            level.scheduleTick(pos, this, STEP_TICKS[state.getValue(LIFE)]);
        }
    }
}
