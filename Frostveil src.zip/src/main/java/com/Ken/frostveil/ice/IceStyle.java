package com.Ken.frostveil.ice;

/**
 * Playstyle buckets. Every cast adds to the matching counter; perks unlock at thresholds, so the way you shape
 * ice (blades, walls, volleys, bridges, snow, halo) decides what your character becomes.
 */
public enum IceStyle {
    BLADE("Blade Dancer", "Held and thrown blades cost 15% less and can be 1 block longer."),
    VOLLEY("Shard Barrage", "Volleys can fire 2 more shards and fan out cleaner."),
    FORTRESS("Glacier Wall", "Walls and domes last 60% longer and can be 1 block wider."),
    STRIDER("Frost Strider", "Floors and bridges reach 2 blocks further from your hands."),
    FROSTFIELD("Snow Warden", "Snowfields grow 40% larger and cost less."),
    ORBITAL("Halo Keeper", "Halo shards recover faster and the halo can hold 3 more shards.");

    public final String title;
    public final String perk;

    IceStyle(String title, String perk) {
        this.title = title;
        this.perk = perk;
    }

    /** Uses needed for the perk. */
    public static final int PERK_AT = 40;
}
