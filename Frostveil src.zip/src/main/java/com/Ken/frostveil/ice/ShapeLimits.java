package com.Ken.frostveil.ice;

import com.Ken.frostveil.data.FvData;

/**
 * What a character can control. Level 3 (external control) is Shimoro's weakness in the lore:
 * he starts with a reach of 3 blocks from his hands; training and playstyle perks widen it.
 */
public record ShapeLimits(float reach, float maxLength, float maxWidth, int maxCount, float lifetimeMul, float costMul, float bladeBonus) {

    public static ShapeLimits of(FvData d) {
        int ext = d.ctrlExternal;
        int phys = d.ctrlPhysical;
        int men = d.ctrlMental;
        float reach = 3.0f + (ext - 1) * 0.55f;
        float maxLen = 2.0f + (ext - 1) * 0.5f + (men - 1) * 0.25f;
        float maxWid = 1.5f + (phys - 1) * 0.4f;
        int maxCount = 1 + men / 2;
        float life = 1f;
        float cost = 1f;
        float blade = 0f;
        if (d.styleUses(IceStyle.BLADE) >= IceStyle.PERK_AT) { cost *= 0.85f; blade = 1f; }
        if (d.styleUses(IceStyle.VOLLEY) >= IceStyle.PERK_AT) maxCount += 2;
        if (d.styleUses(IceStyle.FORTRESS) >= IceStyle.PERK_AT) { life *= 1.6f; maxWid += 1f; }
        if (d.styleUses(IceStyle.STRIDER) >= IceStyle.PERK_AT) reach += 2f;
        if (d.styleUses(IceStyle.ORBITAL) >= IceStyle.PERK_AT) maxCount += 3;
        return new ShapeLimits(reach, maxLen + blade, maxWid, Math.min(maxCount, 12), life, cost, blade);
    }
}
