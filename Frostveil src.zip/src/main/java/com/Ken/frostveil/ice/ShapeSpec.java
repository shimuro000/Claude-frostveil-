package com.Ken.frostveil.ice;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;

/**
 * A "recipe" for an ice shape. This is the heart of the creative system: the player builds recipes in the Shape Studio
 * (primitive + a few knobs) and the same recipe drives the preview, the projectile mesh, the placed blocks and the cost.
 */
public final class ShapeSpec {
    /** Basic shapes. Ordered by when the story unlocks them (bit index = ordinal). */
    public enum Prim {
        SPHERE("sphere"), WALL("wall"), SPIKE("spike"), SHARD("shard"), BLADE("blade"), DISC("disc"), LANCE("lance"), CLUSTER("cluster");
        public final String key;
        Prim(String key) { this.key = key; }
        public static Prim of(int i) { Prim[] v = values(); return v[Mth.clamp(i, 0, v.length - 1)]; }
    }

    /** What the shape does once made. */
    public enum Behavior {
        LAUNCH, // flies at the target
        HOLD,   // stays in the hand as a weapon (melee reach, damage and look follow the recipe)
        PLACE,  // becomes temporary ice blocks (stamp at the aim point, or along a freehand stroke)
        ORBIT;  // joins the Ice Halo around the body
        public static Behavior of(int i) { Behavior[] v = values(); return v[Mth.clamp(i, 0, v.length - 1)]; }
    }

    /** How a freehand stroke is thickened into blocks. */
    public enum Extrude {
        WALL, FLAT, BLOB;
        public static Extrude of(int i) { Extrude[] v = values(); return v[Mth.clamp(i, 0, v.length - 1)]; }
    }

    public int form = 0; // 0 Solid Shaper, 1 Snowmaker, 2 Ice Halo
    public Prim prim = Prim.SPHERE;
    public Behavior behavior = Behavior.LAUNCH;
    public Extrude extrude = Extrude.WALL;
    public boolean stroke = false;
    public float length = 1.5f;  // blocks
    public float width = 1.0f;   // blocks
    public float curve = 0f;     // -1..1 bend of blades / lances
    public float spread = 0.25f; // 0..1 fan width for volleys
    public float spin = 0f;      // 0..1 how fast the shape rotates in flight / orbit
    public int count = 1;        // volley size or halo shard count
    public String name = "";

    public ShapeSpec copy() {
        ShapeSpec s = new ShapeSpec();
        s.form = form; s.prim = prim; s.behavior = behavior; s.extrude = extrude; s.stroke = stroke;
        s.length = length; s.width = width; s.curve = curve; s.spread = spread; s.spin = spin; s.count = count; s.name = name;
        return s;
    }

    /** Clamp to what this character can control (control levels, perks). Called server-side on every received spec. */
    public ShapeSpec clamp(ShapeLimits lim) {
        form = Mth.clamp(form, 0, 2);
        length = Mth.clamp(length, 0.5f, lim.maxLength());
        width = Mth.clamp(width, 0.5f, lim.maxWidth());
        curve = Mth.clamp(curve, -1f, 1f);
        spread = Mth.clamp(spread, 0f, 1f);
        spin = Mth.clamp(spin, 0f, 1f);
        count = Mth.clamp(count, 1, lim.maxCount());
        if (name == null) name = "";
        if (name.length() > 16) name = name.substring(0, 16);
        return this;
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        t.putInt("form", form); t.putInt("prim", prim.ordinal()); t.putInt("beh", behavior.ordinal()); t.putInt("ext", extrude.ordinal());
        t.putBoolean("stroke", stroke);
        t.putFloat("len", length); t.putFloat("wid", width); t.putFloat("curve", curve); t.putFloat("spread", spread); t.putFloat("spin", spin);
        t.putInt("count", count); t.putString("name", name);
        return t;
    }

    public static ShapeSpec fromTag(CompoundTag t) {
        ShapeSpec s = new ShapeSpec();
        if (t == null || t.isEmpty()) return s;
        s.form = t.getInt("form"); s.prim = Prim.of(t.getInt("prim")); s.behavior = Behavior.of(t.getInt("beh")); s.extrude = Extrude.of(t.getInt("ext"));
        s.stroke = t.getBoolean("stroke");
        s.length = t.getFloat("len"); s.width = t.getFloat("wid"); s.curve = t.getFloat("curve"); s.spread = t.getFloat("spread"); s.spin = t.getFloat("spin");
        s.count = Math.max(1, t.getInt("count")); s.name = t.getString("name");
        if (s.length <= 0) s.length = 1.5f;
        if (s.width <= 0) s.width = 1f;
        return s;
    }

    public void write(FriendlyByteBuf b) {
        b.writeNbt(toTag());
    }

    public static ShapeSpec read(FriendlyByteBuf b) {
        return fromTag(b.readNbt());
    }

    /** The playstyle bucket this shape trains. */
    public IceStyle style() {
        if (form == 1) return IceStyle.FROSTFIELD;
        if (form == 2 || behavior == Behavior.ORBIT) return IceStyle.ORBITAL;
        if (behavior == Behavior.PLACE) return (stroke && extrude == Extrude.FLAT) || prim == Prim.DISC ? IceStyle.STRIDER : IceStyle.FORTRESS;
        if (behavior == Behavior.HOLD) return IceStyle.BLADE;
        return count >= 3 ? IceStyle.VOLLEY : (prim == Prim.BLADE || prim == Prim.LANCE ? IceStyle.BLADE : IceStyle.VOLLEY);
    }
}
