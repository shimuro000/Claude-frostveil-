package com.Ken.frostveil.ice;

import java.util.ArrayList;
import java.util.List;

/**
 * Procedural geometry for every ice shape, built from the same ShapeSpec the player designed.
 * No Minecraft classes here: returns quads as float[12] (4 x xyz). Local axes: +Z is the shape's long axis (base at 0, tip at +length).
 * Spheres and discs are centred on the origin.
 */
public final class IceMesh {
    private record Sec(float cx, float cy, float z, float rx, float ry) {}

    private IceMesh() {}

    public static List<float[]> build(ShapeSpec s) {
        float L = Math.max(0.3f, s.length), W = Math.max(0.2f, s.width);
        List<float[]> out = new ArrayList<>();
        switch (s.prim) {
            case SPHERE -> {
                float r = 0.2f + W * 0.25f;
                List<Sec> secs = new ArrayList<>();
                int n = 7;
                for (int i = 0; i <= n; i++) {
                    float t = (float) i / n;
                    float a = (float) (Math.PI * t);
                    secs.add(new Sec(0, 0, -r * (float) Math.cos(a), r * (float) Math.sin(a), r * (float) Math.sin(a)));
                }
                loft(out, secs, 8);
            }
            case SHARD -> loft(out, List.of(new Sec(0, 0, 0, 0, 0), new Sec(0, 0, L * 0.3f, W * 0.28f, W * 0.28f), new Sec(0, 0, L, 0, 0)), 4);
            case SPIKE -> loft(out, List.of(new Sec(0, 0, 0, W * 0.35f, W * 0.35f), new Sec(0, 0, L * 0.5f, W * 0.2f, W * 0.2f), new Sec(0, 0, L, 0, 0)), 6);
            case LANCE -> {
                float r = 0.05f + W * 0.05f;
                loft(out, List.of(new Sec(0, 0, 0, r, r), new Sec(0, 0, L * 0.82f, r, r), new Sec(0, 0, L, 0, 0)), 6);
            }
            case BLADE -> {
                List<Sec> secs = new ArrayList<>();
                int n = 6;
                for (int i = 0; i <= n; i++) {
                    float t = (float) i / n;
                    float taper = i == n ? 0f : (1f - 0.55f * t);
                    secs.add(new Sec(s.curve * 0.5f * L * t * t, 0, L * t, W * 0.28f * taper, 0.035f * taper));
                }
                loft(out, secs, 4);
            }
            case DISC -> loft(out, List.of(new Sec(0, 0, -0.05f, W * 0.6f, W * 0.6f), new Sec(0, 0, 0.05f, W * 0.6f, W * 0.6f)), 8);
            case WALL -> loft(out, List.of(new Sec(0, 0, 0, W * 0.5f, L * 0.5f), new Sec(0, 0, 0.14f, W * 0.5f, L * 0.5f)), 4);
            case CLUSTER -> {
                float[][] tilts = {{0, 0}, {0.6f, 0}, {-0.6f, 0}, {0, 0.6f}, {0, -0.6f}};
                for (float[] t : tilts) {
                    List<float[]> one = new ArrayList<>();
                    loft(one, List.of(new Sec(0, 0, 0, W * 0.2f, W * 0.2f), new Sec(0, 0, L * 0.5f, W * 0.12f, W * 0.12f), new Sec(0, 0, L * (t[0] == 0 && t[1] == 0 ? 1f : 0.7f), 0, 0)), 4);
                    for (float[] q : one) out.add(tilt(q, t[0], t[1]));
                }
            }
        }
        return out;
    }

    /** Connect cross-section rings with quads and close both ends. */
    private static void loft(List<float[]> out, List<Sec> secs, int n) {
        float k = n == 4 ? 1.4142f : 1f; // make a 4-gon read as a box of half-size r
        float[][][] rings = new float[secs.size()][n][3];
        for (int i = 0; i < secs.size(); i++) {
            Sec s = secs.get(i);
            for (int j = 0; j < n; j++) {
                double a = Math.PI * 2 * (j + 0.5) / n;
                rings[i][j] = new float[]{s.cx + s.rx * k * (float) Math.cos(a) * (n == 4 ? 0.7071f : 1f), s.cy + s.ry * k * (float) Math.sin(a) * (n == 4 ? 0.7071f : 1f), s.z};
            }
        }
        for (int i = 0; i + 1 < secs.size(); i++) {
            for (int j = 0; j < n; j++) {
                int j2 = (j + 1) % n;
                out.add(quad(rings[i][j], rings[i][j2], rings[i + 1][j2], rings[i + 1][j]));
            }
        }
        cap(out, rings[0], secs.get(0), n, true);
        cap(out, rings[secs.size() - 1], secs.get(secs.size() - 1), n, false);
    }

    private static void cap(List<float[]> out, float[][] ring, Sec s, int n, boolean start) {
        if (s.rx < 0.001f && s.ry < 0.001f) return; // a point: nothing to close
        float[] c = {s.cx, s.cy, s.z};
        for (int j = 0; j < n; j++) {
            int j2 = (j + 1) % n;
            out.add(start ? quad(c, ring[j2], ring[j], ring[j]) : quad(c, ring[j], ring[j2], ring[j2]));
        }
    }

    private static float[] quad(float[] a, float[] b, float[] c, float[] d) {
        return new float[]{a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2], d[0], d[1], d[2]};
    }

    private static float[] tilt(float[] q, float ax, float az) {
        float[] r = new float[12];
        float cx = (float) Math.cos(ax), sx = (float) Math.sin(ax), cz = (float) Math.cos(az), sz = (float) Math.sin(az);
        for (int i = 0; i < 4; i++) {
            float x = q[i * 3], y = q[i * 3 + 1], z = q[i * 3 + 2];
            float y1 = y * cx - z * sx, z1 = y * sx + z * cx; // around X
            float x2 = x * cz - y1 * sz, y2 = x * sz + y1 * cz; // around Z
            r[i * 3] = x2; r[i * 3 + 1] = y2; r[i * 3 + 2] = z1;
        }
        return r;
    }
}
