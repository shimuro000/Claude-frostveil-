package com.Ken.frostveil.ice;

import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.eiu.EiuRules;
import com.Ken.frostveil.eiu.ServerActions;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.story.MissionManager;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Server side of the creative ice system.
 * The player designs a ShapeSpec (primitive + knobs), optionally draws a freehand stroke, and releases.
 * This class validates everything against the character's control levels (ShapeLimits), charges aura, and makes the result:
 * flying shapes, a held weapon, temporary blocks, a snowfield, or Halo shards.
 */
public final class IceShaping {
    private static final int MAX_BLOCKS = 220;
    private IceShaping() {}

    // ---------- costs and damage ----------

    static float primMul(ShapeSpec.Prim p) {
        return switch (p) {
            case SPHERE -> 0.8f; case WALL -> 1.1f; case SPIKE -> 1.0f; case SHARD -> 0.9f;
            case BLADE -> 1.2f; case DISC -> 1.0f; case LANCE -> 1.3f; case CLUSTER -> 1.5f;
        };
    }

    public static float damageOf(ShapeSpec s, float density, FvData d) {
        float base = switch (s.prim) {
            case SPHERE -> 3f; case WALL -> 2f; case SPIKE -> 5f; case SHARD -> 4f;
            case BLADE -> 5f; case DISC -> 4f; case LANCE -> 6f; case CLUSTER -> 4f;
        };
        return base * (0.75f + 0.25f * s.length) * (0.6f + 0.4f * density) * (1f + d.output * 0.02f) * (1f + d.strength * 0.004f);
    }

    /** Aura cost of launching or holding a shape (before environment / efficiency). */
    public static float baseCost(ShapeSpec s) {
        float one = (3f + 2.2f * s.length + 1.6f * s.width) * primMul(s.prim);
        return one * (1f + 0.8f * (s.count - 1));
    }

    private static float finalCost(ServerPlayer p, FvData d, float base, float density, ShapeLimits lim) {
        float env = EiuRules.environmentCost(d.element, p.level(), p.blockPosition());
        if (p.getPersistentData().getLong("fv_snow_until") > p.level().getGameTime()) env *= 0.75f; // inside a Snowmaker field
        if (p.level().getGameTime() < d.flowUntil) density *= 0.5f; // Flow: minimum cost
        return EiuRules.cost(base, density, env, d.efficiency) * lim.costMul();
    }

    // ---------- cast ----------

    public static void saveSpec(ServerPlayer p, int slot, ShapeSpec in) {
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        slot = Mth.clamp(slot, 0, d.presets.length - 1);
        ShapeSpec s = in.copy().clamp(ShapeLimits.of(d));
        if (!d.formUnlocked(s.form)) s.form = FvData.FORM_SOLID;
        if (s.form == FvData.FORM_SNOW) { s.behavior = ShapeSpec.Behavior.PLACE; }
        if (s.form == FvData.FORM_HALO) { s.behavior = ShapeSpec.Behavior.ORBIT; }
        if (s.form == FvData.FORM_SOLID && s.behavior == ShapeSpec.Behavior.ORBIT) s.behavior = ShapeSpec.Behavior.LAUNCH;
        d.presets[slot] = s;
        d.selected = slot;
        d.mark();
        MissionManager.event(p, "shape_saved", s.prim.key);
    }

    public static void cast(ServerPlayer p, ShapeSpec in, int held, List<Vec3> stroke) {
        FvData d = FvCap.get(p);
        ServerLevel level = p.serverLevel();
        long now = level.getGameTime();
        if (!d.active()) return;
        if (!d.awakened) { ServerActions.msg(p, "You cannot shape EIU yet. Feel your core first (hold G)."); return; }
        if (now - d.lastCast < 5) return;
        if (p.hasEffect(com.Ken.frostveil.registry.ModEffects.FORCED_CLOSURE.get())) { ServerActions.msg(p, "Your channels are closed."); return; }
        ShapeLimits lim = ShapeLimits.of(d);
        ShapeSpec s = in.copy().clamp(lim);
        if (!d.formUnlocked(s.form)) { ServerActions.msg(p, "That ice form is not yours yet."); return; }
        if (s.form == FvData.FORM_SOLID && !d.primUnlocked(s.prim)) { ServerActions.msg(p, "You have not learned the " + s.prim.key + " yet."); return; }
        if (!"ice".equals(d.element) && s.behavior == ShapeSpec.Behavior.PLACE) { ServerActions.msg(p, "Only ice can be set into the world as blocks."); return; }
        if (s.form == FvData.FORM_SNOW) s.behavior = ShapeSpec.Behavior.PLACE;
        if (s.form == FvData.FORM_HALO) s.behavior = ShapeSpec.Behavior.ORBIT;

        // Level 1 (mental): the longer F is held, the clearer the picture. Blurred picture = blurred technique.
        float clarity = Mth.clamp(held / 16f, 0.3f, 1f);
        boolean flow = now < d.flowUntil;
        int window = 1 + Math.round(d.perception / 24f);
        boolean perfect = flow || Math.abs(held - 19) <= window; // Level 2 (physical): the rhythm ring
        float density = flow ? 1.8f : 0.55f + 1.45f * Mth.clamp(held, 6, 32) / 32f;
        if (perfect && !flow) { d.flow = Math.min(100, d.flow + 6); }
        s.length = Math.max(0.5f, s.length * (0.75f + 0.25f * clarity));
        s.spread = Math.min(1f, s.spread + (1f - clarity) * 0.35f);

        boolean ok = switch (s.behavior) {
            case LAUNCH -> castLaunch(p, d, s, density, perfect, lim);
            case HOLD -> castHold(p, d, s, density, lim);
            case PLACE -> s.form == FvData.FORM_SNOW ? castSnow(p, d, s, density, stroke, lim) : castPlace(p, d, s, density, stroke, lim);
            case ORBIT -> castHalo(p, d, s, density, lim);
        };
        if (!ok) return;
        d.lastCast = now;
        d.shroudOn = false; // Shroud breaks when a technique is used
        IceStyle st = s.style();
        int before = d.styleUses(st);
        d.addStyle(st, 1);
        if (before < IceStyle.PERK_AT && d.styleUses(st) >= IceStyle.PERK_AT) {
            ServerActions.msg(p, "Playstyle perk unlocked: " + st.title + ". " + st.perk);
            p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.4f);
        }
        d.efficiency = Math.min(0.6f, d.efficiency + 0.0006f); // repetition raises efficiency (D9)
        d.mark();
        FvNet.toNear(level, p.getX(), p.getY(), p.getZ(), 48, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) (p.getY() + 1.2), (float) p.getZ(), perfect ? 0.7f : 0.4f, d.element, 4, 0));
        MissionManager.event(p, "ice_cast", s.prim.key);
        MissionManager.event(p, "ice_cast_style", st.name().toLowerCase());
    }

    // ---------- behaviours ----------

    private static boolean castLaunch(ServerPlayer p, FvData d, ShapeSpec s, float density, boolean perfect, ShapeLimits lim) {
        float cost = finalCost(p, d, baseCost(s), perfect ? density * 0.72f : density, lim);
        if (!ServerActions.spend(p, d, cost)) return false;
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        Vec3 up = right.cross(look).normalize();
        float dmg = damageOf(s, density, d) / (float) Math.sqrt(s.count);
        for (int i = 0; i < s.count; i++) {
            double t = s.count == 1 ? 0 : (i - (s.count - 1) / 2.0) / Math.max(1.0, (s.count - 1) / 2.0);
            Vec3 dir = look.add(right.scale(t * s.spread * 0.55)).add(up.scale(Math.abs(t) * s.spread * 0.12)).normalize();
            IceConstructEntity e = IceConstructEntity.create(p, s, density, dmg, IceConstructEntity.FORMING, i, s.count, 10 + i * 2, dir, d.element, cost);
            p.level().addFreshEntity(e);
        }
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_CLUSTER_PLACE, SoundSource.PLAYERS, 0.8f, 1.2f);
        return true;
    }

    private static boolean castHold(ServerPlayer p, FvData d, ShapeSpec s, float density, ShapeLimits lim) {
        dropHeld(p, d);
        float cost = finalCost(p, d, baseCost(s) * 0.7f, density, lim);
        if (!ServerActions.spend(p, d, cost)) return false;
        ShapeSpec one = s.copy();
        one.count = 1;
        IceConstructEntity e = IceConstructEntity.create(p, one, density, damageOf(one, density, d), IceConstructEntity.HELD, 0, 1, 0, Vec3.ZERO, d.element, cost);
        p.level().addFreshEntity(e);
        d.heldConstruct = e.getId();
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.9f, 1.5f);
        return true;
    }

    public static void dropHeld(ServerPlayer p, FvData d) {
        if (d.heldConstruct >= 0) {
            Entity e = p.level().getEntity(d.heldConstruct);
            if (e instanceof IceConstructEntity ic) {
                d.aura = Math.min(d.quantity, d.aura + ic.cost() * 0.2f); // Cutoff refunds only what was still held
                ic.shatter();
            }
            d.heldConstruct = -1;
            d.mark();
        }
    }

    private static boolean castHalo(ServerPlayer p, FvData d, ShapeSpec s, float density, ShapeLimits lim) {
        ShapeSpec h = s.copy();
        h.form = FvData.FORM_HALO; h.behavior = ShapeSpec.Behavior.ORBIT;
        if (h.prim != ShapeSpec.Prim.SHARD && h.prim != ShapeSpec.Prim.BLADE && h.prim != ShapeSpec.Prim.SPIKE) h.prim = ShapeSpec.Prim.SHARD;
        float cost = finalCost(p, d, 2.5f * h.count * primMul(h.prim), density, lim);
        if (!ServerActions.spend(p, d, cost)) return false;
        d.haloSpec = h;
        d.haloOn = true;
        d.haloShards = h.count;
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1f, 1.2f);
        MissionManager.event(p, "halo_on", "");
        return true;
    }

    public static void setHalo(ServerPlayer p, FvData d, boolean on) {
        if (on && !d.formUnlocked(FvData.FORM_HALO)) { ServerActions.msg(p, "Ice Halo is not yours yet."); return; }
        if (on && !d.awakened) return;
        d.haloOn = on;
        d.haloShards = on ? d.haloSpec.count : 0;
        d.mark();
    }

    public static void releaseHalo(ServerPlayer p, FvData d) {
        if (!d.haloOn || d.haloShards <= 0) return;
        ShapeSpec h = d.haloSpec.copy();
        int n = d.haloShards;
        h.behavior = ShapeSpec.Behavior.LAUNCH;
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0)).normalize();
        float dmg = damageOf(h, 1.2f, d) * 0.8f;
        for (int i = 0; i < n; i++) {
            double t = n == 1 ? 0 : (i - (n - 1) / 2.0) / Math.max(1.0, (n - 1) / 2.0);
            Vec3 dir = look.add(right.scale(t * 0.2)).normalize();
            ShapeSpec one = h.copy();
            one.count = 1;
            p.level().addFreshEntity(IceConstructEntity.create(p, one, 1.2f, dmg, IceConstructEntity.FORMING, i, n, 4 + i, dir, d.element, 0));
        }
        d.haloShards = 0;
        d.mark();
    }

    // ---------- Halo: per-tick upkeep and interception ----------

    public static void tickHalo(ServerPlayer p, FvData d) {
        if (!d.haloOn) return;
        long now = p.level().getGameTime();
        ShapeLimits lim = ShapeLimits.of(d);
        int cap = d.haloSpec.count;
        float regenEvery = d.styleUses(IceStyle.ORBITAL) >= IceStyle.PERK_AT ? 25 : 45;
        if (d.haloShards < cap && now % (long) regenEvery == 0) { d.haloShards++; d.mark(); }
        if (d.focus < 20 && d.haloShards > 0) { // a rattled mind drops the halo
            d.haloShards = 0; d.mark();
            ((ServerLevel) p.level()).sendParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 30, 0.8, 0.8, 0.8, 0.1);
        }
        if (d.haloShards <= 0) return;
        double r = 3.0 + d.haloSpec.spread * 2;
        for (Projectile proj : p.level().getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(r), e -> e.getOwner() != p && !(e instanceof IceConstructEntity))) {
            if (proj.getDeltaMovement().lengthSqr() < 0.01) continue;
            proj.discard();
            d.haloShards--; d.flow = Math.min(100, d.flow + 4); d.mark();
            FvNet.toNear((ServerLevel) p.level(), proj.getX(), proj.getY(), proj.getZ(), 48, new FvNet.ImpactMsg(-1, (float) proj.getX(), (float) proj.getY(), (float) proj.getZ(), 0.5f, d.element, 2, 0));
            p.level().playSound(null, proj.getX(), proj.getY(), proj.getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.8f, 1.7f);
            if (d.haloShards <= 0) break;
        }
        float drain = 0.01f + 0.003f * d.haloShards;
        d.aura = Math.max(0, d.aura - drain * (1f - d.efficiency));
        if (d.aura <= 0) { d.haloOn = false; d.haloShards = 0; d.mark(); }
    }

    // ---------- placing blocks ----------

    private static boolean replaceable(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        return st.isAir() || st.is(Blocks.SNOW) || st.is(Blocks.GRASS) || st.is(Blocks.TALL_GRASS) || st.is(Blocks.FERN) || (!st.getFluidState().isEmpty() && st.getFluidState().isSource());
    }

    private static boolean castPlace(ServerPlayer p, FvData d, ShapeSpec s, float density, List<Vec3> stroke, ShapeLimits lim) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Set<BlockPos> plan = new LinkedHashSet<>();
        int outOfReach = 0;
        Direction facing = p.getDirection();
        if (s.stroke && stroke != null && stroke.size() >= 2) {
            List<Vec3> pts = densify(stroke);
            for (Vec3 v : pts) {
                if (v.distanceTo(eye) > lim.reach() + 1.5) { outOfReach++; continue; } // Level 3 weakness: too far from the hands
                BlockPos c = BlockPos.containing(v);
                stampStroke(level, plan, c, s);
                if (plan.size() > MAX_BLOCKS) break;
            }
        } else {
            BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(p.getLookAngle().scale(lim.reach() + 2.0)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
            if (hit.getType() == HitResult.Type.MISS) { ServerActions.msg(p, "Aim at a surface within reach."); return false; }
            if (hit.getLocation().distanceTo(eye) > lim.reach() + 1.5) { shatterFail(p, d, hit.getLocation()); return false; }
            BlockPos base = hit.getBlockPos().relative(hit.getDirection());
            stampShape(level, plan, base, facing, p.getLookAngle(), s, density);
        }
        plan.removeIf(pos -> !replaceable(level, pos) || !level.mayInteract(p, pos));
        if (plan.isEmpty()) { ServerActions.msg(p, outOfReach > 0 ? "The ice breaks before it forms: too far from your hands." : "No room for that shape."); if (outOfReach > 0) shatterFail(p, d, eye.add(p.getLookAngle().scale(lim.reach() + 1))); return false; }
        float cost = finalCost(p, d, 1.2f + plan.size() * 0.55f, density, lim);
        if (!ServerActions.spend(p, d, cost)) return false;
        int life = density >= 1.8f ? 3 : density >= 1.1f ? 2 : 1;
        if (lim.lifetimeMul() > 1.2f) life = Math.min(3, life + 1);
        int placed = 0;
        for (BlockPos pos : plan) {
            if (ConjuredIceBlock.place(level, pos, life)) placed++;
        }
        BlockPos any = plan.iterator().next();
        level.sendParticles(ParticleTypes.SNOWFLAKE, any.getX() + 0.5, any.getY() + 0.8, any.getZ() + 0.5, Math.min(60, placed * 2), 1.0, 0.7, 1.0, 0.02);
        level.playSound(null, any, SoundEvents.AMETHYST_BLOCK_PLACE, SoundSource.BLOCKS, 1f, 0.9f);
        level.playSound(null, any, SoundEvents.GLASS_PLACE, SoundSource.BLOCKS, 0.8f, 1.1f);
        if (outOfReach > 0) ServerActions.msg(p, "Part of the stroke broke: beyond the reach of your hands.");
        if (s.prim == ShapeSpec.Prim.WALL) MissionManager.event(p, "wall_built", String.valueOf(placed));
        MissionManager.event(p, "blocks_placed", String.valueOf(placed));
        if (s.stroke) MissionManager.event(p, "stroke_cast", s.extrude.name().toLowerCase());
        return true;
    }

    private static void shatterFail(ServerPlayer p, FvData d, Vec3 at) {
        d.focus = Math.max(0, d.focus - 6);
        d.aura = Math.max(0, d.aura - 2);
        d.mark();
        ((ServerLevel) p.level()).sendParticles(ParticleTypes.SNOWFLAKE, at.x, at.y, at.z, 20, 0.3, 0.3, 0.3, 0.1);
        p.level().playSound(null, at.x, at.y, at.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 0.8f, 1.8f);
        ServerActions.msg(p, "The ice shatters beyond your reach. (Level 3 control: train it to reach further.)");
    }

    /** Interpolate a sparse stroke into steps of ~0.6 blocks. */
    private static List<Vec3> densify(List<Vec3> in) {
        List<Vec3> out = new ArrayList<>();
        for (int i = 0; i + 1 < in.size() && out.size() < 140; i++) {
            Vec3 a = in.get(i), b = in.get(i + 1);
            double len = a.distanceTo(b);
            int n = Math.max(1, (int) Math.ceil(len / 0.6));
            for (int k = 0; k < n; k++) out.add(a.lerp(b, k / (double) n));
        }
        out.add(in.get(in.size() - 1));
        return out;
    }

    /** One footprint of a freehand stroke, thickened by the recipe's extrude mode. */
    private static void stampStroke(ServerLevel level, Set<BlockPos> plan, BlockPos c, ShapeSpec s) {
        int w = Math.max(0, Math.round(s.width) - 1) / 2;
        switch (s.extrude) {
            case WALL -> {
                int h = Math.max(1, Math.round(s.length));
                for (int y = 0; y < h; y++) for (int dx = -w; dx <= w; dx++) for (int dz = -w; dz <= w; dz++) plan.add(c.offset(dx, y, dz));
            }
            case FLAT -> {
                int r = Math.max(0, Math.round(s.width * 0.6f));
                for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= r * r + 1) plan.add(c.offset(dx, -1, dz).below(0));
            }
            case BLOB -> {
                int r = Math.max(1, Math.round(s.width * 0.6f));
                for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dy * dy + dz * dz <= r * r + 1) plan.add(c.offset(dx, dy, dz));
            }
        }
    }

    /** One stamp of a primitive at the aimed surface. */
    private static void stampShape(ServerLevel level, Set<BlockPos> plan, BlockPos base, Direction facing, Vec3 look, ShapeSpec s, float density) {
        Direction across = facing.getClockWise();
        int W = Math.max(1, Math.round(s.width * 2)); // blocks across
        int H = Math.max(1, Math.round(s.length));
        int thick = density >= 1.6f ? 2 : 1;
        switch (s.prim) {
            case WALL -> {
                for (int i = -(W / 2); i <= W / 2; i++) {
                    float t = W <= 1 ? 0 : Math.abs(i) / (W / 2f);
                    int bend = Math.round(s.curve * t * t * 2f);
                    for (int y = 0; y < H; y++) for (int th = 0; th < thick; th++) plan.add(base.relative(across, i).relative(facing, bend + th).above(y));
                }
            }
            case DISC -> {
                int r = Math.max(1, Math.round(s.width * 1.2f));
                for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= r * r + 1) plan.add(base.offset(dx, 0, dz));
            }
            case SPIKE -> {
                int h = Math.max(2, Math.round(s.length * 1.5f));
                for (int y = 0; y < h; y++) {
                    int r = Math.max(0, Math.round((1f - y / (float) h) * s.width * 0.5f));
                    for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) if (dx * dx + dz * dz <= r * r + 1) plan.add(base.offset(dx, y, dz));
                }
            }
            case SPHERE -> { // a dome shelter
                int r = Math.max(2, Math.round(s.width * 1.2f + s.length * 0.5f));
                for (int dx = -r; dx <= r; dx++) for (int dy = 0; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                    double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (dist <= r + 0.3 && dist >= r - 0.9) plan.add(base.offset(dx, dy, dz));
                }
            }
            case SHARD, BLADE, LANCE -> { // a diagonal pole in the looked direction
                int n = Math.max(2, Math.round(s.length * 2));
                int r = Math.max(0, Math.round(s.width * 0.4f) - 1);
                for (int i = 0; i < n; i++) {
                    BlockPos c = BlockPos.containing(Vec3.atCenterOf(base).add(look.scale(i)));
                    for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) plan.add(c.offset(dx, 0, dz));
                }
            }
            case CLUSTER -> {
                int count = 3 + Math.round(s.width);
                net.minecraft.util.RandomSource rnd = level.getRandom();
                for (int k = 0; k < count; k++) {
                    BlockPos b = base.offset(rnd.nextInt(5) - 2, 0, rnd.nextInt(5) - 2);
                    int h = 2 + rnd.nextInt(Math.max(1, Math.round(s.length)) + 1);
                    for (int y = 0; y < h; y++) plan.add(b.above(y));
                }
            }
        }
    }

    // ---------- Snowmaker ----------

    private static boolean castSnow(ServerPlayer p, FvData d, ShapeSpec s, float density, List<Vec3> stroke, ShapeLimits lim) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        float sizeBoost = d.styleUses(IceStyle.FROSTFIELD) >= IceStyle.PERK_AT ? 1.4f : 1f;
        if (s.stroke && stroke != null && stroke.size() >= 2) { // Snow Brush: paint snow along the stroke
            Set<BlockPos> plan = new LinkedHashSet<>();
            int layers = Mth.clamp(Math.round(s.length), 1, 6);
            int r = Math.max(0, Math.round(s.width * 0.8f) - 1);
            for (Vec3 v : densify(stroke)) {
                if (v.distanceTo(eye) > lim.reach() + 2.5) continue;
                BlockPos c = BlockPos.containing(v);
                for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) plan.add(c.offset(dx, 0, dz));
                if (plan.size() > MAX_BLOCKS) break;
            }
            float cost = finalCost(p, d, 2f + plan.size() * 0.18f, density, lim);
            if (plan.isEmpty()) return false;
            if (!ServerActions.spend(p, d, cost)) return false;
            int placed = 0;
            for (BlockPos pos : plan) {
                if (!level.mayInteract(p, pos) || !replaceable(level, pos) || !level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) continue;
                level.setBlock(pos, Blocks.SNOW.defaultBlockState().setValue(SnowLayerBlock.LAYERS, layers), 3);
                placed++;
            }
            BlockPos any = plan.iterator().next();
            level.sendParticles(ParticleTypes.SNOWFLAKE, any.getX() + 0.5, any.getY() + 1, any.getZ() + 0.5, 40, 1.2, 0.5, 1.2, 0.03);
            level.playSound(null, any, SoundEvents.SNOW_PLACE, SoundSource.BLOCKS, 1f, 0.9f);
            MissionManager.event(p, "snow_brush", String.valueOf(placed));
            return placed > 0;
        }
        BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(p.getLookAngle().scale(lim.reach() + 3)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        BlockPos at = hit.getType() == HitResult.Type.MISS ? p.blockPosition() : hit.getBlockPos().above();
        float radius = (2f + s.width * 1.4f) * sizeBoost;
        int duration = (int) (200 + s.length * 100) * (int) Math.max(1, lim.lifetimeMul());
        float cost = finalCost(p, d, (4f + radius * 2.5f + duration / 40f) * (sizeBoost > 1 ? 0.85f : 1f), density, lim);
        if (!ServerActions.spend(p, d, cost)) return false;
        level.addFreshEntity(SnowFieldEntity.create(p, at, radius, duration));
        level.playSound(null, at, SoundEvents.POWDER_SNOW_PLACE, SoundSource.PLAYERS, 1f, 0.8f);
        MissionManager.event(p, "snowfield", "");
        return true;
    }
}
