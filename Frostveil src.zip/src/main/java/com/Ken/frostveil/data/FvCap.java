package com.Ken.frostveil.data;

import com.Ken.frostveil.Fv;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Capability plumbing: attach, copy on death, sync on login / respawn / dimension change. */
@Mod.EventBusSubscriber(modid = Fv.ID)
public final class FvCap {
    public static final Capability<FvData> CAP = CapabilityManager.get(new CapabilityToken<>() {});
    private static final net.minecraft.resources.ResourceLocation KEY = Fv.id("data");

    private FvCap() {}

    /** Client-side copy of the local player's data (filled by the sync message). */
    public static final FvData CLIENT = new FvData();

    /** Set by the client: height scale of any player by UUID (from broadcast appearance). */
    public static java.util.function.Function<java.util.UUID, Float> CLIENT_SCALE = u -> 1f;

    public static FvData get(Player player) {
        if (player.level().isClientSide) {
            return CLIENT; // on the client only the local player's data exists (others use ClientState appearance)
        }
        return player.getCapability(CAP).orElseGet(FvData::new);
    }

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(KEY, new Provider());
        }
    }

    @SubscribeEvent
    public static void clone(net.minecraftforge.event.entity.player.PlayerEvent.Clone event) {
        event.getOriginal().reviveCaps();
        event.getOriginal().getCapability(CAP).ifPresent(old -> event.getEntity().getCapability(CAP).ifPresent(now -> {
            now.copyFrom(old);
            if (event.isWasDeath()) {
                // Death penalty from the design: a small aura loss; story progress is kept.
                now.aura = Math.max(5, now.aura * 0.5f);
                now.focus = 100;
                now.flow = 0;
                now.skinSenseOn = false; now.shroudOn = false; now.forgeLimb = 0; now.infuseTicks = 0;
            }
        }));
        event.getOriginal().invalidateCaps();
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        sync(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp) {
            if (sp.level() instanceof net.minecraft.server.level.ServerLevel sl0) com.Ken.frostveil.world.Population.ensure(sl0);
            FvData d = get(sp);
            if (!d.created) com.Ken.frostveil.network.FvNet.toPlayer(sp, new com.Ken.frostveil.network.FvNet.ScreenMsg("mode_select"));
            // tell the new player about everyone else's look
            for (ServerPlayer other : sp.server.getPlayerList().getPlayers()) {
                FvData od = get(other);
                if (od.created) com.Ken.frostveil.network.FvNet.toPlayer(sp, new com.Ken.frostveil.network.FvNet.AppearanceMsg(other.getUUID(), od.profile.toTag(), od.ageStage, od.mode));
            }
        }
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) { sync(e.getEntity()); }

    @SubscribeEvent
    public static void dim(PlayerEvent.PlayerChangedDimensionEvent e) {
        sync(e.getEntity());
        if (e.getEntity() instanceof ServerPlayer sp && sp.level() instanceof net.minecraft.server.level.ServerLevel sl) com.Ken.frostveil.world.Population.ensure(sl);
    }

    public static void sync(Player p) {
        if (p instanceof ServerPlayer sp) {
            com.Ken.frostveil.network.FvNet.syncData(sp);
            com.Ken.frostveil.network.FvNet.broadcastAppearance(sp);
        }
    }

    private static final class Provider implements ICapabilitySerializable<CompoundTag> {
        private final FvData data = new FvData();
        private final LazyOptional<FvData> opt = LazyOptional.of(() -> data);

        @Override
        public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
            return cap == CAP ? opt.cast() : LazyOptional.empty();
        }

        @Override
        public CompoundTag serializeNBT() { return data.save(); }

        @Override
        public void deserializeNBT(CompoundTag nbt) { data.load(nbt); }
    }
}
