package com.Ken.frostveil.data;

import net.minecraft.network.FriendlyByteBuf;

/** The part of a player's state that other players can see (halo, glow, guard pose...). Broadcast on change. */
public record PublicState(boolean haloOn, int haloShards, int haloPattern, float haloRadius, float haloLen, float haloWid, float haloSpin,
                          int forgeLimb, boolean skinSense, boolean shroud, boolean flow, boolean guard) {

    public static final PublicState NONE = new PublicState(false, 0, 0, 1.6f, 0.9f, 0.3f, 0.5f, 0, false, false, false, false);

    public void write(FriendlyByteBuf b) {
        b.writeBoolean(haloOn); b.writeVarInt(haloShards); b.writeVarInt(haloPattern);
        b.writeFloat(haloRadius); b.writeFloat(haloLen); b.writeFloat(haloWid); b.writeFloat(haloSpin);
        b.writeVarInt(forgeLimb); b.writeBoolean(skinSense); b.writeBoolean(shroud); b.writeBoolean(flow); b.writeBoolean(guard);
    }

    public static PublicState read(FriendlyByteBuf b) {
        return new PublicState(b.readBoolean(), b.readVarInt(), b.readVarInt(), b.readFloat(), b.readFloat(), b.readFloat(), b.readFloat(),
                b.readVarInt(), b.readBoolean(), b.readBoolean(), b.readBoolean(), b.readBoolean());
    }

    public static PublicState of(FvData d, long gameTime) {
        com.Ken.frostveil.ice.ShapeSpec h = d.haloSpec;
        return new PublicState(d.haloOn, d.haloShards, h.extrude.ordinal(), 1.1f + h.spread * 2.0f, h.length, h.width, h.spin,
                d.forgeLimb, d.skinSenseOn, d.shroudOn, gameTime < d.flowUntil, d.guarding);
    }
}
