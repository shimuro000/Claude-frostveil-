package com.Ken.frostveil.data;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;

/**
 * The look of a character: everything the 3D creator can change. Shimoro's story preset is one instance of this.
 * The same profile paints the skin texture (client SkinPainter), picks the 3D hair meshes and sets the height.
 * To add a new option: add its value list, a field, one OPTIONS entry and (optionally) use it in SkinPainter / HairLayer.
 */
public final class CharacterProfile {
    public static final List<String> BODY = List.of("male", "female");
    public static final List<String> BUILD = List.of("slim", "athletic", "heavy");
    public static final List<String> SKIN = List.of("pale", "fair", "yellow", "tan", "brown", "dark");
    public static final List<String> EYE = List.of("blue", "green", "brown", "grey", "amber", "violet"); // violet halo is locked in the creator (Fargas / OEIU)
    public static final List<String> EYE_SHAPE = List.of("round", "sharp", "soft");
    public static final List<String> BROWS = List.of("thin", "straight", "thick");
    public static final List<String> SCAR = List.of("none", "cheek", "brow", "lip");
    public static final List<String> MOLE = List.of("none", "cheek", "chin");
    public static final List<String> HAIR = List.of("long_hanging", "ponytail", "three_ties", "topknot", "messy", "wolf_cut", "curly", "bald");
    public static final List<String> HAIR_COLOR = List.of("black", "brown", "white", "grey", "red", "blond", "golden", "silver", "orange");
    public static final List<String> HIGHLIGHT = List.of("none", "blue", "red", "green", "silver", "violet");
    public static final List<String> COAT = List.of("shimoro_coat", "long_coat", "cloak", "wool_shirt", "none");
    public static final List<String> COAT_COLOR = List.of("midnight", "charcoal", "ice", "crimson", "forest", "sand", "violet", "white");
    public static final List<String> SHIRT_COLOR = List.of("charcoal", "navy", "grey", "red", "green", "cream");
    public static final List<String> TRIM = List.of("white_fur", "silver", "gold", "cyan", "red", "black");
    public static final List<String> BOOTS = List.of("waterproof", "fur", "plain");
    public static final List<String> SCARF = List.of("none", "white", "red", "blue");
    public static final List<String> ELEMENT = List.of("unknown", "ice", "fire", "wind", "lightning", "earth", "water");

    public String bodyType = "male";
    public String build = "slim";
    public String skin = "pale";
    public String eyeColor = "blue";
    public String eyeShape = "round";
    public String brows = "straight";
    public String scar = "none";
    public String mole = "none";
    public String hair = "long_hanging";
    public String hairColor = "black";
    public String highlight = "blue";
    public String coat = "shimoro_coat";
    public String coatColor = "midnight";
    public String shirtColor = "charcoal";
    public String trim = "white_fur";
    public String boots = "waterproof";
    public String scarf = "none";
    public boolean waistBag = true;
    public boolean lanternBackpack = false;
    public boolean goggles = false;
    public boolean earring = false;
    public float height = 1.0f;
    public String parentA = "unknown";
    public String parentB = "unknown";

    /** One editable option shown by the creator screen. */
    public record Option(String key, List<String> values, Function<CharacterProfile, String> get, BiConsumer<CharacterProfile, String> set) {}

    public static final List<Option> OPTIONS = new ArrayList<>();
    static {
        add("body", BODY, p -> p.bodyType, (p, v) -> p.bodyType = v);
        add("build", BUILD, p -> p.build, (p, v) -> p.build = v);
        add("skin", SKIN, p -> p.skin, (p, v) -> p.skin = v);
        add("eye_color", EYE, p -> p.eyeColor, (p, v) -> p.eyeColor = v);
        add("eye_shape", EYE_SHAPE, p -> p.eyeShape, (p, v) -> p.eyeShape = v);
        add("brows", BROWS, p -> p.brows, (p, v) -> p.brows = v);
        add("scar", SCAR, p -> p.scar, (p, v) -> p.scar = v);
        add("mole", MOLE, p -> p.mole, (p, v) -> p.mole = v);
        add("hair", HAIR, p -> p.hair, (p, v) -> p.hair = v);
        add("hair_color", HAIR_COLOR, p -> p.hairColor, (p, v) -> p.hairColor = v);
        add("highlight", HIGHLIGHT, p -> p.highlight, (p, v) -> p.highlight = v);
        add("coat", COAT, p -> p.coat, (p, v) -> p.coat = v);
        add("coat_color", COAT_COLOR, p -> p.coatColor, (p, v) -> p.coatColor = v);
        add("shirt_color", SHIRT_COLOR, p -> p.shirtColor, (p, v) -> p.shirtColor = v);
        add("trim", TRIM, p -> p.trim, (p, v) -> p.trim = v);
        add("boots", BOOTS, p -> p.boots, (p, v) -> p.boots = v);
        add("scarf", SCARF, p -> p.scarf, (p, v) -> p.scarf = v);
        add("waist_bag", List.of("off", "on"), p -> p.waistBag ? "on" : "off", (p, v) -> p.waistBag = v.equals("on"));
        add("backpack", List.of("off", "on"), p -> p.lanternBackpack ? "on" : "off", (p, v) -> p.lanternBackpack = v.equals("on"));
        add("goggles", List.of("off", "on"), p -> p.goggles ? "on" : "off", (p, v) -> p.goggles = v.equals("on"));
        add("earring", List.of("off", "on"), p -> p.earring ? "on" : "off", (p, v) -> p.earring = v.equals("on"));
        add("parent_a", ELEMENT, p -> p.parentA, (p, v) -> p.parentA = v);
        add("parent_b", ELEMENT, p -> p.parentB, (p, v) -> p.parentB = v);
    }

    private static void add(String key, List<String> values, Function<CharacterProfile, String> get, BiConsumer<CharacterProfile, String> set) {
        OPTIONS.add(new Option(key, values, get, set));
    }

    public static Option option(String key) {
        for (Option o : OPTIONS) {
            if (o.key().equals(key)) return o;
        }
        return null;
    }

    /** Lore scale: 12 years old is about 0.8 of the 15-year-old model (174 cm = 1.0). */
    public float effectiveScale(int ageStage) {
        float age = ageStage <= 12 ? 0.8f : (ageStage <= 15 ? 1.0f : 1.04f);
        return Mth.clamp(height, 0.85f, 1.15f) * age;
    }

    public static CharacterProfile defaults() {
        CharacterProfile p = new CharacterProfile();
        p.hair = "messy";
        p.highlight = "none";
        p.eyeColor = "brown";
        p.coat = "wool_shirt";
        p.trim = "silver";
        return p;
    }

    /** Shimoro: black hair with blue sheen hanging down, pale skin, blue eyes, black coat with white fur and long collar, waist bag. */
    public static CharacterProfile shimoro() {
        CharacterProfile p = new CharacterProfile();
        p.bodyType = "male";
        p.build = "slim";
        p.skin = "pale";
        p.eyeColor = "blue";
        p.hair = "long_hanging";
        p.hairColor = "black";
        p.highlight = "blue";
        p.coat = "shimoro_coat";
        p.coatColor = "midnight";
        p.trim = "white_fur";
        p.waistBag = true;
        return p;
    }

    public CharacterProfile copy() {
        return fromTag(toTag());
    }

    public CompoundTag toTag() {
        CompoundTag t = new CompoundTag();
        for (Option o : OPTIONS) t.putString(o.key(), o.get().apply(this));
        t.putFloat("height", height);
        return t;
    }

    public static CharacterProfile fromTag(CompoundTag t) {
        CharacterProfile p = new CharacterProfile();
        if (t == null) return p;
        for (Option o : OPTIONS) {
            if (t.contains(o.key())) {
                String v = t.getString(o.key());
                if (o.values().contains(v)) o.set().accept(p, v);
            }
        }
        if (t.contains("height")) p.height = Mth.clamp(t.getFloat("height"), 0.85f, 1.15f);
        return p;
    }
}
