package com.Ken.frostveil.data;

import com.Ken.frostveil.ice.IceStyle;
import com.Ken.frostveil.ice.ShapeSpec;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraftforge.common.capabilities.AutoRegisterCapability;

/**
 * All per-player Frostveil state. One capability, one NBT blob, synced as a whole.
 * Keep it plain: fields are public so systems can read them; call {@link #mark()} after changing anything that must reach the client.
 */
@AutoRegisterCapability
public final class FvData {
    public static final int MODE_NONE = 0, MODE_STORY = 1, MODE_FREE = 2;
    public static final int FORM_SOLID = 0, FORM_SNOW = 1, FORM_HALO = 2;

    // --- setup ---
    public int mode = MODE_NONE;
    public boolean created = false;
    public CharacterProfile profile = CharacterProfile.defaults();
    public int ageStage = 15;
    public String element = "ice";

    // --- EIU ---
    public float aura = 40, quantity = 40, output = 12, efficiency = 0.05f;
    public float focus = 100;
    public float flow = 0;
    public float strength = 8, speed = 8, endurance = 8, perception = 8, bodyLimit = 20;
    public int ctrlMental = 1, ctrlPhysical = 1, ctrlExternal = 1; // control levels, 1..10
    public int points = 0;
    public float fatigue = 0;

    // --- basic techniques (stages) ---
    public boolean awakened = false;
    public int skinSenseStage = 0, forgeStage = 0, cutoffStage = 0, infuseStage = 0;
    public boolean skinSenseOn = false, shroudOn = false;
    public int forgeLimb = 0; // 0 off, 1 right arm, 2 left arm, 3 legs, 4 torso
    public int infuseTicks = 0;

    // --- ice shaping ---
    public int unlockedForms = 1; // bit 0 Solid Shaper, bit 1 Snowmaker, bit 2 Ice Halo
    public int unlockedPrims = 0; // bit per ShapeSpec.Prim
    public int form = FORM_SOLID;
    public final ShapeSpec[] presets = new ShapeSpec[8];
    public int selected = 0;
    public final int[] style = new int[IceStyle.values().length];
    public boolean haloOn = false;
    public ShapeSpec haloSpec = defaultHalo();

    // --- story ---
    public final Map<String, Integer> active = new HashMap<>();   // mission id -> objective index
    public final Map<String, Integer> progress = new HashMap<>(); // mission id -> counter inside the objective
    public final Set<String> completed = new HashSet<>();
    public final Set<String> flags = new HashSet<>();
    public final Map<String, Integer> trust = new HashMap<>();
    public final Map<String, Long> doneAt = new HashMap<>();      // mission id -> game time it was completed (for pacing delays)
    public final Map<String, Integer> train = new HashMap<>();    // training counters (activity -> count, g_<key> -> gains so far)
    public String tracked = "";
    public String party = ""; // comma separated companion ids, e.g. "awi,ryo"
    public String trackedTitle = "", trackedObj = "";
    public long trackedPos = 0; // BlockPos.asLong of the objective, 0 = none
    public String trackedNpc = "";

    // --- transient (not saved) ---
    public transient boolean dirty = true;
    public transient int comboIndex = 0;
    public transient long comboExpire = 0;
    public transient long nextAttack = 0;
    public transient long guardSince = -100;
    public transient boolean guarding = false;
    public transient long dodgeUntil = 0;
    public transient long lastHurt = -1000;
    public transient long lastCast = -1000;
    public transient long flowUntil = 0;
    public transient int heldConstruct = -1;
    public transient int haloShards = 0;
    public transient long lastTrainDay = -1;
    public transient final Map<String, Long> objTimers = new HashMap<>();
    public transient double lastX = 0, lastZ = 0;

    public FvData() {
        for (int i = 0; i < presets.length; i++) presets[i] = ShapeSpec.fromTag(null);
        presets[0].prim = ShapeSpec.Prim.SPHERE;
    }

    public static ShapeSpec defaultHalo() {
        ShapeSpec h = ShapeSpec.fromTag(null);
        h.form = FORM_HALO; h.prim = ShapeSpec.Prim.SHARD; h.behavior = ShapeSpec.Behavior.ORBIT;
        h.length = 0.9f; h.width = 0.35f; h.count = 4; h.spread = 0.4f; h.spin = 0.5f;
        return h;
    }

    public void mark() { dirty = true; }

    public boolean inStory() { return mode == MODE_STORY; }
    public boolean active() { return mode != MODE_NONE; }

    public boolean hasFlag(String f) { return flags.contains(f); }
    public void setFlag(String f) { if (flags.add(f)) mark(); }
    public boolean done(String mission) { return completed.contains(mission); }

    public int styleUses(IceStyle s) { return style[s.ordinal()]; }
    public void addStyle(IceStyle s, int n) { style[s.ordinal()] += n; mark(); }

    /** The style the player uses most, or null if none yet. */
    public IceStyle dominantStyle() {
        int best = 0; IceStyle out = null;
        for (IceStyle s : IceStyle.values()) {
            if (style[s.ordinal()] > best) { best = style[s.ordinal()]; out = s; }
        }
        return out;
    }

    public boolean formUnlocked(int f) { return (unlockedForms & (1 << f)) != 0; }
    public boolean primUnlocked(ShapeSpec.Prim p) { return (unlockedPrims & (1 << p.ordinal())) != 0; }
    public void unlockPrim(ShapeSpec.Prim p) { unlockedPrims |= (1 << p.ordinal()); mark(); }

    public int trustOf(String npc) { return trust.getOrDefault(npc, 0); }
    public void addTrust(String npc, int n) { trust.merge(npc, n, Integer::sum); mark(); }

    public boolean inParty(String npc) {
        for (String s : party.split(",")) if (s.equals(npc)) return true;
        return false;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("mode", mode); t.putBoolean("created", created); t.put("profile", profile.toTag());
        t.putInt("age", ageStage); t.putString("element", element);
        t.putFloat("aura", aura); t.putFloat("quantity", quantity); t.putFloat("output", output); t.putFloat("eff", efficiency);
        t.putFloat("focus", focus); t.putFloat("flow", flow);
        t.putFloat("str", strength); t.putFloat("spd", speed); t.putFloat("end", endurance); t.putFloat("per", perception); t.putFloat("body", bodyLimit);
        t.putInt("cm", ctrlMental); t.putInt("cp", ctrlPhysical); t.putInt("ce", ctrlExternal);
        t.putInt("points", points); t.putFloat("fatigue", fatigue);
        t.putBoolean("awake", awakened);
        t.putInt("ss", skinSenseStage); t.putInt("fg", forgeStage); t.putInt("co", cutoffStage); t.putInt("in", infuseStage);
        t.putBoolean("ssOn", skinSenseOn); t.putBoolean("shroud", shroudOn); t.putInt("limb", forgeLimb); t.putInt("infT", infuseTicks);
        t.putInt("forms", unlockedForms); t.putInt("prims", unlockedPrims); t.putInt("form", form); t.putInt("sel", selected);
        ListTag ps = new ListTag();
        for (ShapeSpec s : presets) ps.add(s.toTag());
        t.put("presets", ps);
        t.putIntArray("style", style);
        t.putBoolean("haloOn", haloOn); t.put("haloSpec", haloSpec.toTag());
        t.put("active", mapToTag(active)); t.put("progress", mapToTag(progress)); t.put("trust", mapToTag(trust));
        CompoundTag da = new CompoundTag(); for (Map.Entry<String, Long> en : doneAt.entrySet()) da.putLong(en.getKey(), en.getValue()); t.put("doneAt", da);
        t.put("train", mapToTag(train));
        t.put("done", setToTag(completed)); t.put("flags", setToTag(flags));
        t.putString("tracked", tracked); t.putString("party", party);
        t.putString("trNpc", trackedNpc); t.putString("trTitle", trackedTitle); t.putString("trObj", trackedObj); t.putLong("trPos", trackedPos);
        return t;
    }

    public void load(CompoundTag t) {
        mode = t.getInt("mode"); created = t.getBoolean("created");
        profile = CharacterProfile.fromTag(t.getCompound("profile"));
        ageStage = t.contains("age") ? t.getInt("age") : 15; element = t.contains("element") ? t.getString("element") : "ice";
        aura = t.getFloat("aura"); quantity = Math.max(1, t.getFloat("quantity")); output = Math.max(1, t.getFloat("output")); efficiency = Mth.clamp(t.getFloat("eff"), 0, 0.8f);
        focus = t.contains("focus") ? t.getFloat("focus") : 100; flow = t.getFloat("flow");
        strength = t.getFloat("str"); speed = t.getFloat("spd"); endurance = t.getFloat("end"); perception = t.getFloat("per"); bodyLimit = Math.max(5, t.getFloat("body"));
        ctrlMental = clampLvl(t.getInt("cm")); ctrlPhysical = clampLvl(t.getInt("cp")); ctrlExternal = clampLvl(t.getInt("ce"));
        points = t.getInt("points"); fatigue = t.getFloat("fatigue");
        awakened = t.getBoolean("awake");
        skinSenseStage = t.getInt("ss"); forgeStage = t.getInt("fg"); cutoffStage = t.getInt("co"); infuseStage = t.getInt("in");
        skinSenseOn = t.getBoolean("ssOn"); shroudOn = t.getBoolean("shroud"); forgeLimb = t.getInt("limb"); infuseTicks = t.getInt("infT");
        unlockedForms = t.contains("forms") ? t.getInt("forms") : 1; unlockedPrims = t.getInt("prims"); form = t.getInt("form"); selected = Mth.clamp(t.getInt("sel"), 0, presets.length - 1);
        ListTag ps = t.getList("presets", Tag.TAG_COMPOUND);
        for (int i = 0; i < presets.length && i < ps.size(); i++) presets[i] = ShapeSpec.fromTag(ps.getCompound(i));
        haloOn = t.getBoolean("haloOn");
        haloSpec = t.contains("haloSpec") ? ShapeSpec.fromTag(t.getCompound("haloSpec")) : defaultHalo();
        haloSpec.form = FORM_HALO;
        int[] st = t.getIntArray("style");
        for (int i = 0; i < style.length; i++) style[i] = i < st.length ? st[i] : 0;
        tagToMap(t.getCompound("active"), active); tagToMap(t.getCompound("progress"), progress); tagToMap(t.getCompound("trust"), trust);
        CompoundTag dac = t.getCompound("doneAt"); doneAt.clear(); for (String k : dac.getAllKeys()) doneAt.put(k, dac.getLong(k));
        tagToMap(t.getCompound("train"), train);
        tagToSet(t.getList("done", Tag.TAG_STRING), completed); tagToSet(t.getList("flags", Tag.TAG_STRING), flags);
        tracked = t.getString("tracked"); party = t.getString("party");
        trackedNpc = t.getString("trNpc"); trackedTitle = t.getString("trTitle"); trackedObj = t.getString("trObj"); trackedPos = t.getLong("trPos");
        dirty = true;
    }

    public void copyFrom(FvData o) {
        load(o.save());
    }

    private static int clampLvl(int v) { return Mth.clamp(v <= 0 ? 1 : v, 1, 10); }

    private static CompoundTag mapToTag(Map<String, Integer> m) {
        CompoundTag t = new CompoundTag();
        for (Map.Entry<String, Integer> e : m.entrySet()) t.putInt(e.getKey(), e.getValue());
        return t;
    }

    private static void tagToMap(CompoundTag t, Map<String, Integer> m) {
        m.clear();
        for (String k : t.getAllKeys()) m.put(k, t.getInt(k));
    }

    private static ListTag setToTag(Set<String> s) {
        ListTag l = new ListTag();
        for (String v : s) l.add(StringTag.valueOf(v));
        return l;
    }

    private static void tagToSet(ListTag l, Set<String> s) {
        s.clear();
        for (int i = 0; i < l.size(); i++) s.add(l.getString(i));
    }
}
