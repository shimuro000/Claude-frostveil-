# LORE_GAPS

Things the code needs but the design document does not define. Each is a PLACEHOLDER for the author to fill.

| Item | Where used | Status |
|------|-----------|--------|
| First mission id and text (story start in Tatsuma) | `PlayerStoryData.activeMission`, `data/frostveil/missions` | PLACEHOLDER |
| Shimoro's appearance / default skin | character creator, player model | PLACEHOLDER |
| EIU starting value and growth | `PlayerStoryData` | [DESIGN] tuning value (100), not lore |
| CRP effects per technique | techniques | PLACEHOLDER (not yet implemented) |
| Veyrskin look and stats | Curios slot | PLACEHOLDER (not yet implemented) |
| NPC dialogue lines | `data/frostveil/dialogues` | PLACEHOLDER (not yet implemented) |

Canon rules (from the author):
- Vantus is the dark version of EIU. It does not appear in the first saga; it is lore only for now.
- Use only the names spelled in the glossary (e.g. Volcred, never other spellings).
- Author-provided lore text is stored under `lore/` as reference. Code and data must follow it, not invent beyond it.

Spelling conflicts inside the author's lore files (code/UI/data use the glossary spelling only):
- "OEIU" in the lore text means Vantus. Spilts means Spiltz. Vulcred means Volcred. Nanashi/nanashi means Nanachi.
- Full lore sections are now complete in lore/ (B, C, D, E, F), extracted from the master PDF.

Section G gaps:
- Which of Aura Quantity / Output / Efficiency is Shimoro's weaker stat: PLACEHOLDER (`PlayerEnergyData.weakStat` is empty).
- Shimoro's starting stat values: [DESIGN] defaults only (Quantity 100, Output 10, Efficiency 0.05, body stats 10).
- Temporary key B cycles the Forge limb because G7 says the limb is chosen in the technique wheel, which belongs to section H.
