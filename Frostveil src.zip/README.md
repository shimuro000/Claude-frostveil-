# Frostveil (Minecraft Java 1.20.1, Forge 47.x)

Story-driven action RPG built on the EIU system. You play as Shimoro.
Version **1.6.0** ("Ash and Elements" update).

## Required mods (put all jars in `mods/`)
| Mod | Version | Needed by |
|---|---|---|
| Minecraft Forge | 1.20.1, 47.2.0 or newer (built against 47.3.0) | everything |
| **Player Animation Library** (`playeranimator`, by KosmX) | 1.0.2-rc1 for 1.20 (Forge) | player animations (client) |

Nothing else is required. (GeckoLib is not used in this version.)

## Build
Push the CONTENTS of this folder to the root of your GitHub repo (so `settings.gradle` sits at the repo root) and run the
"Build Frostveil" workflow. The jar appears under *Actions -> run -> Artifacts*. Locally: `gradle build` (Gradle 8.1.1, JDK 17).

## Play
1. Install Forge 1.20.1, drop in Frostveil and Player Animation Library, create a world (or join one).
2. On first join the Frostveil menu opens (also `/frostveil menu`): **Story Mode** (you are Shimoro) or **Free World**.
3. Story starts at dawn in Tatsuma (dimension `frostveil:world`).
Testing helpers (operators): `/frostveil unlock`, `/frostveil points <n>`, `/frostveil mission <id>`, `/frostveil aura`, `/frostveil tatsuma`, `/frostveil reset`.

## Keys (all rebindable under Controls -> Frostveil)
F cast (hold = Mental, release near the ring = perfect) | R Shape Studio | N next recipe | T next ice form | G feel the core (hold, stand still)
Z Skin Sense | X Forge (hold) | V change Forge limb | C Cutoff (tap) / EIU Shroud (hold) | B Infuse held item
H Ice Halo on/off | J release Halo shards | K character sheet | L journal | Left Alt dodge | U companion order
Left click (not on a block) = 3-hit combo, sprint + click = heavy | Right mouse (empty hand or sword) = guard; guard just before a hit = parry.

## The creative ice system (Shape Studio, R)
Each recipe = base shape + knobs. Shapes: sphere, wall, spike, shard, blade, disc, lance, cluster (unlocked by the story).
Knobs: length, width, curve, spread, spin, count. What it does: **launch**, **hold** (a weapon in your hand: reach, damage and look follow the recipe),
**place** (temporary ice blocks that crack and shatter), **orbit** (Ice Halo). **Freehand**: turn it on, hold F and sweep the crosshair: the stroke becomes
a wall, a floor/bridge or a tunnel. Snowmaker: snowfields (slow enemies, cheaper ice, Skin Sense bonus) and a snow brush. Ice Halo: orbiting shards
(ring / spiral / shell) that intercept projectiles and can be released at a target.
Limits come from your three control levels: Shimoro starts with a **reach of 3 blocks** (Level 3 weakness): ice shaped farther away breaks.
Playstyle: every cast trains one of 6 styles (Blade Dancer, Shard Barrage, Glacier Wall, Frost Strider, Snow Warden, Halo Keeper); at 40 uses each unlocks a perk.

## Customising (files to edit)
- Story: `data/frostveil/missions/*.json`, `data/frostveil/dialogues/*.json` (action script documented in `story/Actions.java`).
- Animations: `client/fx/Anims.java` (arrays of radians per body part).
- Impact feel: `client/fx/Juice.java` (shake, FOV punch, hit-stop, particles).
- Character options: `data/CharacterProfile.java`; look painting: `client/SkinPainter.java`.
- NPC looks/stats: `entity/NpcDefs.java` (or drop `assets/frostveil/textures/entity/npc/<id>.png`).
- Village layout: `world/TatsumaBuilder.java`.
- Textures are placeholders (generated); see `ASSETS.md`.


## What is new in 1.1.0
- **Fixed:** holding G now awakens EIU (story and Free World); the sphere is unlocked on awakening (it blocked Fang's lesson); short tries count as failed tries.
- **Compass for every mission:** top-centre compass + a tall objective beam in the world; it follows NPCs, Fargas and hostile enemies live. Journal has "Skip current objective" if anything ever sticks; stuck objectives also time out by themselves.
- **The Stranger (Fargas):** appears right in front of you with a boss bar, smoke and a painted look (breathing mask, glowing violet eyes), cannot stall the scene.
- **3D character:** real 3D hair with spring physics (long, ponytail, three ties, topknot, messy, wolf cut, curly), coat tails / cloak / scarf that flow when you move, fur collar, bag and lantern backpack, 3D eyes that blink, brows that react, nose and mouth. Works on players, NPCs and enemies.
- **Living village:** ~30 people with homes, beds, daily schedules (cook, forge, farm, market, patrol, train, play, sleep), special abilities (Awi dash, Yu frost burst, Fang slam, Kaina bow), speech bubbles, merchants you can buy from (Tenn), horses and chickens, a farm, more houses.
- **More impact:** sweeping slash arcs per combo hit, attack lunge, charge audio that rises to the perfect moment, FOV squeeze while charging, parry shockwave, landing and sprint dust, Skin Sense ripples, Forge sparks, Flow trails.


## What is new in 1.2.0
- **Menus scroll** with the mouse wheel (creator, Shape Studio, character sheet, journal) and a scroll bar shows where you are. Buttons that are scrolled out of view are hidden, so nothing overlaps (the Skip objective button now has its own place).
- **No vanilla monsters** in the Frostveil world (zombies, creepers, skeletons, spiders, phantoms...). Only Frostveil's own enemies exist.
- **Duplicate / fighting bug fixed:** villagers are created once (when the village is built) and only come back if they died; duplicates among loaded NPCs are removed automatically. Friends never attack each other (children's snowballs are harmless, a sparring Fang or Ryo is only hostile to you).
- **Story, closer to the chapters:** the stranger freezes you, grabs your wrist and you faint -> you wake on Awi's horse -> you run back -> Kaina, Awi and Yu fight him with you until he leaves -> Igor and the smith arrive late -> Kaina checks on you -> the real council meeting at the round table (Yu, Kaina, Awi, Igor, Tetsu, the smith; Fang walks in) -> you ask Fang to train you.
- **Ash Knight raid:** exactly 10 knights come through the north gate and march into the village; Awi, Yu, Kaina, the guards, hunters and you fight them. The mission completes only when all 10 are down, then any leftover raider is cleared.


## What is new in 1.3.0
- **Pacing:** missions that are hours apart now wait (Fang's spar -> he leaves at noon -> night falls -> the Ash Knights; also the council, training, the road).
- **Dying restarts the mission** (the fight, the spar, the raid, the road encounter), with enemies reset, instead of leaving the story broken.
- **Fang's training gives 3 Training Points (TP)** (spend them in the character sheet, K). After it comes a **time-skip cutscene**: you watch Tatsuma from above while days and nights cycle, then: age 15, **174 cm** (was ~150), Strength +7, EIU Pool +12, EIU Power x2, Speed +2, Endurance +7 (that is your max health), Body Limit +6, each control level +1.
- **Speed and Endurance are real now** (walking speed, max health).
- **Learn by doing:** 10 ice techniques = +1 EIU Power and +1 EIU Pool; 15 freehand strokes = +1 reach; 25 hits = +1 Strength; 12 dodges = +1 Speed; parries and Skin Sense time = +1 Perception; Forge use = +1 Body Limit; sprinting = +1 Endurance; meditating = +1 Mental control. Each gain in the same activity needs a little more.
- **Backpack:** Shift + right click puts the Lantern Backpack on your back (chest slot, drawn in 3D), right click or `I` opens its 27 slots, `Y` toggles the lantern light that follows you. **Pop-up Tent:** right click the ground, a tent with a bed and campfire unfolds and becomes your respawn.
- **Scenes instead of empty moments:** Awi's training with her ice ball, the boys' snowball ambush and their laughing now play as short scenes.
- **The road south is much longer** and the Ryo encounter is far away (new worlds build the road; the compass and beam guide you either way).
- **Character face and hair rebuilt:** bigger anime-style eyes (iris, pupil, sparkles, lashes, blink), fringe that never covers the eyes, denser hair in two layers with highlights and softer physics.


## What is new in 1.4.0
- **3D clothes and accessories (creator options, all with physics where it makes sense):** hats (beanie with a swinging pom-pom, fur hat with flaps, headband with tails, hood, earmuffs, cap), masks (half mask, breathing mask), gloves (fingerless, fur, wrist straps), shoulders (fur mantle with a fur fringe, pauldrons, shawl), capes (short, long, with a clasp), belts (pouches that swing, sash with a tail), boots in 3D (fur, waterproof, plain) and fur cuffs on Shimoro's coat. A separate Accent colour tints them. Story mode now lets you dress Shimoro in all of them.
- **NPC animations:** hammering at the forge, stirring the pot, Awi's training forms, eating, selling, farming (bending), kids running, guards with crossed arms, talking gestures, waving, and a breathing idle.
- **Smarter NPCs:** greet you by time of day (and by name; friends are warmer), walk over to their friends and chat (Kaina and Yu, Awi and Fang, Igor and Tetsu, Drayt and Awi), strike up small talk with neighbours, go home in a storm, run home and stay inside during a raid, kids cheer when you cast ice.
- **More impact:** combo counter with rank words (NICE / GREAT / BRUTAL / FROSTBITE!), a rising column of light and a chime when training raises a stat, poof burst on heavy hits, red pulse when your health is low, snow puffs under your boots.


## What is new in 1.5.0 - fighting animations for NPCs
- **Kaina and the hunters (bow):** aim stance with the string drawn back, a release with recoil, body turned to the target.
- **Ryo and the Ash Knights (swords):** a wind-up, a cut across the body and a recovery; every second hit is a backhand from the other side, with a lunge in the legs.
- **Awi (spear):** pull back, thrust forward with a step, recover; her dash is a low leaning lunge that ends in a stab. She now carries a spear-like trident.
- **Fang:** two-handed overhead slam: arms up with a lean back, then a crushing drop with his whole body.
- **Yu:** frost burst: arms open wide to gather the cold, then thrust outward.
- **Everyone:** a ready stance when they have a target (weapon up, feet apart, a slight bob), and a stagger when they are hit hard.
Animations live in `client/render/Renderers.java` (NpcModel.setupAnim): each is a few key poses per limb, easy to tune.


## What is new in 1.6.0
- **Katana** (new item, Ryo carries one): low draw stance, horizontal draw-cut, rising cut and a fast overhead cut, for NPCs and for you. For the player, the first katana strike after a pause is a quick-draw hit (x1.45), and combos are faster.
- **Smarter villagers in a raid:** the brave (about a third of the civilians) fight with their tools, the rest run home, shout and hide. Fighters (Awi, Yu, Kaina, guards, hunters) defend. Voices: villagers, children and raiders have their own pitch; shouts are louder.
- **Ash Knights:** each has an element and a technique (fire throws fire, ice freezes, wind dashes and pushes, lightning is a telegraphed strike you can dodge, earth hardens and cracks the ground), says different lines, retreats when badly hurt and recovers, and some are **arsonists** who set the house nearest to you on fire (limited, so the village is damaged, not erased). The fires are put out when the raid ends and the house that burned is the one that was set alight.
- **Ash Knight armor** (helmet, chestplate, leggings, boots): worn by the knights (20% drop chance each). If you wear it you get the **Ash Curse**: slower, weaker blows, less max health and your aura drains.
- **The well is covered** (new worlds) and NPCs never walk into it.
- **Story:** the three boys now ambush Shimoro while he runs: they appear in front of him, throw snowballs one after another with their lines ("Want more?", "I have all the snowballs you dream of, Shimoro!", "We all have some like those, too!"), run away, and he shouts after them. Drayt's invitation to the workshop is part of Kaina's breakfast scene.
- **Elements have their own studio** (Free World): Fire, Earth, Wind, Water and Lightning each have named forms (shaper / field / halo) and shapes, their own damage, speed and cost, hit effects (burn, stun, knock-up, slow, extinguish), block types for "place" (magma, stone, glass-like wind, water, glowing lightning) and field effects (Wildfire burns, Storm Field throws enemies, Rain Field heals, Thunder Field strikes, Quake Field slows). **Free World now unlocks all three forms** (shaper, Snowmaker-style field, Halo) and every shape from the start.
- **Faces:** the face is now one smooth painted plane in front of the head (big eyes with iris, pupil, two sparkles, lashes, brows, blush, nose, mouth; blinks and frowns when hurt; glowing eyes for the Stranger), so it is always visible.
- **Shimoro's hair:** shorter at the back, and the blue is a subtle tint (hair colour pushed toward blue on a few strands) instead of bright stripes.
