# Frostveil

Story-driven action RPG mod for Minecraft Java 1.20.1 (Forge 47.x, Java 17, official Mojang mappings).
Mod id `frostveil`, base package `com.Ken.frostveil`. You play as Shimoro in story mode. Power system: EIU.

## Status (phase 2: section G slice)

Implemented (server-authoritative, **not compiled or run: the build could not be run here**):
- Per-player story save and EIU energy capability (aura, Quantity/Output/Efficiency, body stats, Focus, Flow, channel state, injuries).
- Energy engine: cost = base x density x environment x (1 - efficiency), sustained drain, full-drain penalty, regeneration (sleep x3), Forge body limit (broken hand), Focus loss on hit, Flow state, forced closure.
- Controls (G3) with a "Frostveil" key category: Dodge (Left Alt, i-frames), Skin Sense (Z), Forge (hold X, limb cycle on B until the wheel exists), Cutoff tap / EIU Shroud hold (C), Infuse (hold V), focus / meditation (hold G). Ice Infuse works on the held item.
- HUD (G4): aura bar, focus bar, active-state labels, Flow glow, low-aura warning (placeholder visuals).
- Tuning in the common config (`frostveil-common.toml`).
- Test commands (op level 2): `/frostveil awaken`, `aura <n>`, `learn skin_sense|forge|cutoff|infuse <stage>`, `closure true|false`, `flow`. In Saga 1 the techniques are unlocked by story, so use `learn` to test.

Not implemented yet (TODO hooks): title screen and menus (G2), 3D character creator (G5), stats screen / point allocation (G6), training minigames (G8), technique wheel and casting (section H), Skin Sense directional alerts, guard/parry, Flow slow-motion, missions, NPCs, structures, dimension, Codex.

## How to build

1. Push the contents of this project (the project root, not a parent folder) to a GitHub repository.
2. Add `build.yml` to the repository as `.github/workflows/build.yml`.
3. Open the **Actions** tab, choose **Build Frostveil**, and click **Run workflow** (it also runs on every push to main/master).
4. When the run finishes, download the `frostveil-jar` artifact.
5. Put the jar in your `mods` folder together with the library jars: GeckoLib, Curios API, Patchouli,
   Player Animation Library (playerAnimator). JEI is optional.

## Library versions

Versions in `gradle.properties` are best-effort and unverified. If one does not resolve, use the nearest
1.20.1-compatible version and note it here.
