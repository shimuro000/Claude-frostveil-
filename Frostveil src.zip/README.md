# Frostveil (Minecraft Java 1.20.1, Forge 47.x)

Story-driven action RPG built on the EIU system. You play as Shimoro.
Version **1.0.0** ("Shape Studio" update) - rebuilt from scratch with official Mojang mappings.

## Required mods (put all jars in `mods/`)
| Mod | Version | Needed by |
|---|---|---|
| Minecraft Forge | 1.20.1, 47.2.0 or newer (built against 47.3.0) | everything |
| **Player Animation Library** (`playeranimator`, by KosmX) | 1.0.2-rc1 for 1.20 (Forge) | player animations (client) |

Nothing else is required. (GeckoLib is not used in this version.)

## Build
Push the CONTENTS of this folder to the root of your GitHub repo (so `settings.gradle` sits at the repo root) and run the
"Build Frostveil" workflow. The jar appears under *Actions -> run -> Artifacts*. Locally: `gradle build` (Gradle 8.1.1, JDK 17).

## Play
1. Install Forge 1.20.1, drop in Frostveil and Player Animation Library, create a world (or join one).
2. On first join the Frostveil menu opens (also `/frostveil menu`): **Story Mode** (you are Shimoro) or **Free World**.
3. Story starts at dawn in Tatsuma (dimension `frostveil:world`).
Testing helpers (operators): `/frostveil unlock`, `/frostveil points <n>`, `/frostveil mission <id>`, `/frostveil aura`, `/frostveil tatsuma`, `/frostveil reset`.

## Keys (all rebindable under Controls -> Frostveil)
F cast (hold = Mental, release near the ring = perfect) | R Shape Studio | N next recipe | T next ice form | G feel the core (hold, stand still)
Z Skin Sense | X Forge (hold) | V change Forge limb | C Cutoff (tap) / EIU Shroud (hold) | B Infuse held item
H Ice Halo on/off | J release Halo shards | K character sheet | L journal | Left Alt dodge | U companion order
Left click (not on a block) = 3-hit combo, sprint + click = heavy | Right mouse (empty hand or sword) = guard; guard just before a hit = parry.

## The creative ice system (Shape Studio, R)
Each recipe = base shape + knobs. Shapes: sphere, wall, spike, shard, blade, disc, lance, cluster (unlocked by the story).
Knobs: length, width, curve, spread, spin, count. What it does: **launch**, **hold** (a weapon in your hand: reach, damage and look follow the recipe),
**place** (temporary ice blocks that crack and shatter), **orbit** (Ice Halo). **Freehand**: turn it on, hold F and sweep the crosshair: the stroke becomes
a wall, a floor/bridge or a tunnel. Snowmaker: snowfields (slow enemies, cheaper ice, Skin Sense bonus) and a snow brush. Ice Halo: orbiting shards
(ring / spiral / shell) that intercept projectiles and can be released at a target.
Limits come from your three control levels: Shimoro starts with a **reach of 3 blocks** (Level 3 weakness): ice shaped farther away breaks.
Playstyle: every cast trains one of 6 styles (Blade Dancer, Shard Barrage, Glacier Wall, Frost Strider, Snow Warden, Halo Keeper); at 40 uses each unlocks a perk.

## Customising (files to edit)
- Story: `data/frostveil/missions/*.json`, `data/frostveil/dialogues/*.json` (action script documented in `story/Actions.java`).
- Animations: `client/fx/Anims.java` (arrays of radians per body part).
- Impact feel: `client/fx/Juice.java` (shake, FOV punch, hit-stop, particles).
- Character options: `data/CharacterProfile.java`; look painting: `client/SkinPainter.java`.
- NPC looks/stats: `entity/NpcDefs.java` (or drop `assets/frostveil/textures/entity/npc/<id>.png`).
- Village layout: `world/TatsumaBuilder.java`.
- Textures are placeholders (generated); see `ASSETS.md`.
