package com.Ken.frostveil.eiu;

import com.Ken.frostveil.combat.CombatService;
import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.ice.IceConstructEntity;
import com.Ken.frostveil.ice.IceShaping;
import com.Ken.frostveil.network.FvNet;
import com.Ken.frostveil.registry.ModItems;
import com.Ken.frostveil.story.MissionManager;
import com.Ken.frostveil.world.FrostveilWorld;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;

/** Everything the client may ask for by name. Every branch re-checks the rules; the client is never trusted. */
public final class ServerActions {
    private ServerActions() {}

    public static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    public static void handle(ServerPlayer p, String action, int a, int b, float f) {
        FvData d = FvCap.get(p);
        if (!d.active()) return;
        long now = p.level().getGameTime();
        switch (action) {
            case "skin_sense" -> {
                if (!d.awakened || d.skinSenseStage < 1) { msg(p, "You have not learned Skin Sense yet."); return; }
                d.skinSenseOn = !d.skinSenseOn;
                if (d.skinSenseOn) MissionManager.event(p, "technique_used", "skin_sense");
                d.mark();
            }
            case "forge_limb" -> {
                if (a == 0) { d.forgeLimb = 0; d.mark(); return; }
                if (!d.awakened || d.forgeStage < 1) { msg(p, "You have not learned Forge yet."); return; }
                if (d.aura < 2) { msg(p, "Not enough aura."); return; }
                d.forgeLimb = Mth.clamp(a, 1, 4);
                d.shroudOn = false;
                MissionManager.event(p, "technique_used", "forge");
                d.mark();
            }
            case "shroud" -> {
                if (!d.awakened || d.cutoffStage < 2) { msg(p, "You have not learned the EIU Shroud yet."); return; }
                d.shroudOn = a == 1;
                d.mark();
            }
            case "cutoff" -> {
                if (!d.awakened || d.cutoffStage < 1) { msg(p, "You have not learned Cutoff yet."); return; }
                cutoff(p, d);
                MissionManager.event(p, "technique_used", "cutoff");
            }
            case "infuse" -> {
                if (!d.awakened || d.infuseStage < 1) { msg(p, "You have not learned Infuse yet."); return; }
                ItemStack held = p.getMainHandItem();
                if (held.isEmpty()) { msg(p, "Hold something to infuse."); return; }
                float cost = EiuRules.cost(6f, 1f, EiuRules.environmentCost(d.element, p.level(), p.blockPosition()), d.efficiency);
                if (!spend(p, d, cost)) return;
                d.infuseTicks = 400 + d.infuseStage * 200;
                MissionManager.event(p, "technique_used", "infuse");
                d.mark();
            }
            case "meditate" -> {
                if (a == 1) {
                    p.getPersistentData().putBoolean("fv_meditating", true);
                    p.getPersistentData().putLong("fv_med_start", now);
                } else {
                    // remember how long the breath lasted BEFORE clearing the flag (train_feel arrives right after this message)
                    long start = p.getPersistentData().getLong("fv_med_start");
                    p.getPersistentData().putLong("fv_med_len", p.getPersistentData().getBoolean("fv_meditating") ? now - start : 0);
                    p.getPersistentData().putBoolean("fv_meditating", false);
                }
            }
            case "train_feel" -> {
                long len = p.getPersistentData().getLong("fv_med_len");
                p.getPersistentData().putLong("fv_med_len", 0);
                boolean can = d.awakened || d.hasFlag("can_awaken") || d.mode == FvData.MODE_FREE;
                if (len >= 45 && can) {
                    if (!d.awakened) {
                        d.awakened = true;
                        d.unlockPrim(com.Ken.frostveil.ice.ShapeSpec.Prim.SPHERE); // the first shape you can make
                        msg(p, "You feel it: a faint pulse in your chest. EIU is yours.");
                        p.playNotifySound(net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_CHIME, net.minecraft.sounds.SoundSource.PLAYERS, 1f, 1.4f);
                    }
                    MissionManager.event(p, "feel_core", "success");
                    d.mark();
                } else {
                    msg(p, !can ? "You feel nothing. Only cold." : "Hold G longer, standing still (about 3 seconds).");
                    MissionManager.event(p, "feel_core", "fail");
                }
            }
            case "skip_obj" -> MissionManager.skip(p);
            case "form" -> {
                int target = Mth.clamp(a, 0, 2);
                if (d.formUnlocked(target)) { d.form = target; d.mark(); } else msg(p, "That ice form is not yours yet.");
            }
            case "slot" -> { d.selected = Mth.clamp(a, 0, d.presets.length - 1); d.mark(); }
            case "point" -> allocate(p, d, a);
            case "dodge" -> dodge(p, d, now);
            case "guard" -> {
                d.guarding = a == 1;
                if (d.guarding) d.guardSince = now;
            }
            case "halo" -> IceShaping.setHalo(p, d, !d.haloOn);
            case "halo_release" -> IceShaping.releaseHalo(p, d);
            case "drop_held" -> IceShaping.dropHeld(p, d);
            case "journal" -> FvNet.toPlayer(p, new FvNet.JournalMsg(MissionManager.journal(p)));
            case "order" -> companionOrder(p, a);
            case "training" -> MissionManager.event(p, "training", String.valueOf(a));
            default -> { }
        }
    }

    public static boolean spend(ServerPlayer p, FvData d, float cost) {
        if (d.aura < cost) {
            msg(p, "Your aura is too low.");
            return false;
        }
        d.aura -= cost;
        d.mark();
        return true;
    }

    static void cutoff(ServerPlayer p, FvData d) {
        d.skinSenseOn = false; d.forgeLimb = 0; d.infuseTicks = 0;
        IceShaping.dropHeld(p, d);
        if (d.haloOn) IceShaping.setHalo(p, d, false);
        d.mark();
        FvNet.toPlayer(p, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY() + 1f, (float) p.getZ(), 0.3f, d.element, 5, 0));
    }

    private static void allocate(ServerPlayer p, FvData d, int stat) {
        if (d.points <= 0) { msg(p, "No points to spend."); return; }
        switch (stat) {
            case 0 -> { d.quantity += 5; d.aura += 5; }
            case 1 -> d.output += 1.5f;
            case 2 -> d.efficiency = Math.min(0.6f, d.efficiency + 0.01f);
            case 3 -> d.strength += 1;
            case 4 -> d.speed += 1;
            case 5 -> d.endurance += 1;
            case 6 -> d.perception += 1;
            case 7 -> d.bodyLimit += 2;
            default -> { return; }
        }
        d.points--;
        d.mark();
    }

    private static void dodge(ServerPlayer p, FvData d, long now) {
        if (now < d.dodgeUntil + 6) return; // small cooldown
        if (d.aura < 4 && !d.skinSenseOn) return;
        if (!d.skinSenseOn) d.aura -= 3;
        d.dodgeUntil = now + 8;
        d.mark();
        FvNet.toNear((ServerLevel) p.level(), p.getX(), p.getY(), p.getZ(), 48, new FvNet.ImpactMsg(p.getId(), (float) p.getX(), (float) p.getY() + 0.8f, (float) p.getZ(), 0.4f, d.element, 5, 0));
    }

    private static void companionOrder(ServerPlayer p, int order) {
        List<com.Ken.frostveil.entity.FvNpcEntity> npcs = p.level().getEntitiesOfClass(com.Ken.frostveil.entity.FvNpcEntity.class, p.getBoundingBox().inflate(40));
        for (com.Ken.frostveil.entity.FvNpcEntity n : npcs) {
            if (p.getUUID().equals(n.getOwnerId())) n.setOrder(order, p);
        }
    }

    /** Creator result. Story mode ignores everything except outfit colours: the hero is Shimoro. */
    public static void setProfile(ServerPlayer p, CompoundTag tag, int mode) {
        FvData d = FvCap.get(p);
        CharacterProfile sent = CharacterProfile.fromTag(tag);
        if (d.created && d.mode != FvData.MODE_NONE && mode != d.mode && false) return;
        if (mode == FvData.MODE_STORY) {
            if (d.mode == FvData.MODE_STORY && d.created) {
                // already in the story: only outfit colours may change
                d.profile.coatColor = sent.coatColor; d.profile.trim = sent.trim; d.profile.shirtColor = sent.shirtColor; d.profile.scarf = sent.scarf;
                d.mark();
                FvNet.broadcastAppearance(p);
                return;
            }
            startStory(p, d, sent);
        } else if (mode == FvData.MODE_FREE) {
            if (d.mode == FvData.MODE_FREE && d.created) {
                d.profile = sent; d.mark(); FvNet.broadcastAppearance(p); p.refreshDimensions();
                return;
            }
            startFree(p, d, sent);
        }
    }

    public static void startStory(ServerPlayer p, FvData d, CharacterProfile sent) {
        d.mode = FvData.MODE_STORY;
        d.created = true;
        d.profile = CharacterProfile.shimoro();
        d.profile.coatColor = sent.coatColor; d.profile.trim = sent.trim; d.profile.shirtColor = sent.shirtColor;
        d.ageStage = 12;
        d.element = "ice";
        d.aura = 20; d.quantity = 20; d.output = 8; d.efficiency = 0.02f; d.focus = 100; d.flow = 0;
        d.strength = 6; d.speed = 6; d.endurance = 6; d.perception = 6; d.bodyLimit = 20;
        d.ctrlMental = 3; d.ctrlPhysical = 3; d.ctrlExternal = 1; // Fang's training raises them; level 3 is the weak one (reach 3 blocks)
        d.points = 0; d.awakened = false;
        d.skinSenseStage = 0; d.forgeStage = 0; d.cutoffStage = 0; d.infuseStage = 0;
        d.unlockedForms = 1; d.unlockedPrims = 0; d.form = FvData.FORM_SOLID;
        d.active.clear(); d.progress.clear(); d.completed.clear(); d.flags.clear(); d.trust.clear(); d.party = "";
        d.mark();
        p.refreshDimensions();
        FrostveilWorld.startStory(p);
    }

    public static void startFree(ServerPlayer p, FvData d, CharacterProfile sent) {
        d.mode = FvData.MODE_FREE;
        d.created = true;
        d.profile = sent;
        d.ageStage = 15;
        String el = pickElement(sent, p);
        d.element = el;
        d.aura = 40; d.quantity = 40; d.output = 12; d.efficiency = 0.05f; d.focus = 100;
        d.ctrlMental = 3; d.ctrlPhysical = 3; d.ctrlExternal = 3;
        d.awakened = false;
        d.skinSenseStage = 0; d.forgeStage = 0; d.cutoffStage = 0; d.infuseStage = 0;
        d.unlockedForms = 1;
        d.unlockedPrims = 0x1F; // sphere, wall, spike, shard, blade
        d.points = 3;
        d.mark();
        p.refreshDimensions();
        p.getInventory().add(new ItemStack(ModItems.ICE_STICK.get()));
        FrostveilWorld.startFree(p);
        msg(p, "Hold G (standing still, ~3 s) to feel your core and awaken your EIU.");
    }

    /** Free World: the element comes from the parents the player chose (D5), never from a menu pick. */
    private static String pickElement(CharacterProfile sent, ServerPlayer p) {
        String a = Element.valid(sent.parentA) ? sent.parentA : null;
        String b = Element.valid(sent.parentB) ? sent.parentB : null;
        if (a != null && b != null) return p.getRandom().nextBoolean() ? a : b;
        if (a != null) return a;
        if (b != null) return b;
        String[] all = {"ice", "fire", "wind", "lightning", "earth", "water"};
        return all[p.getRandom().nextInt(all.length)];
    }

    /** Used by missions/commands to discard an entity safely. */
    public static void discard(Entity e) {
        if (e != null && e.isAlive()) e.discard();
    }

    static IceConstructEntity unused() { return null; }

    static void touch(CombatService unused) { }
}
