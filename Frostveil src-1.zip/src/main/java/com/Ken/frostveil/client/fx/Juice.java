package com.Ken.frostveil.client.fx;

import com.Ken.frostveil.client.ClientState;
import com.Ken.frostveil.eiu.Element;
import com.Ken.frostveil.network.FvNet;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;

/**
 * "Game feel": every important moment arrives as a bundle of small effects: particles, camera kick, FOV punch,
 * a short freeze of the player's movement (hit-stop), a colour flash and floating damage numbers.
 * Tune the numbers here; nothing else in the mod depends on them.
 */
public final class Juice {
    public static float shake = 0f;        // camera shake amount (decays)
    public static float shakeSeed = 0f;
    public static float fov = 0f;          // extra FOV degrees (decays)
    public static int hitstop = 0;         // ticks of movement freeze
    public static int flash = 0;           // ARGB flash colour
    public static float flashAlpha = 0f;
    public static float kickPitch = 0f;    // directional camera kick (decays)
    public static float vignette = 0f;     // red vignette when hurt

    private Juice() {}

    private static ParticleOptions iceChunks() { return new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()); }

    public static void onImpact(FvNet.ImpactMsg m) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        RandomSource r = mc.level.random;
        double x = m.x(), y = m.y(), z = m.z();
        double dist = mc.player.distanceToSqr(x, y, z);
        float near = (float) Mth.clamp(1.0 - Math.sqrt(dist) / 20.0, 0.0, 1.0);
        float s = m.strength();
        ParticleOptions el = m.element().equals("none") ? ParticleTypes.CRIT : Element.particle(m.element());
        switch (m.kind()) {
            case 0, 1 -> {
                boolean heavy = m.kind() == 1;
                int n = heavy ? 22 : 10;
                for (int i = 0; i < n; i++) mc.level.addParticle(el, x, y, z, (r.nextDouble() - 0.5) * 0.7, r.nextDouble() * 0.5, (r.nextDouble() - 0.5) * 0.7);
                for (int i = 0; i < (heavy ? 12 : 5); i++) mc.level.addParticle(iceChunks(), x, y, z, (r.nextDouble() - 0.5) * 0.5, r.nextDouble() * 0.4, (r.nextDouble() - 0.5) * 0.5);
                mc.level.addParticle(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0, 0);
                if (heavy) { mc.level.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0.05, 0); ring(x, y - 0.4, z, ParticleTypes.CLOUD, 18, 0.3); mc.level.playLocalSound(x, y, z, net.minecraft.sounds.SoundEvents.ANVIL_LAND, net.minecraft.sounds.SoundSource.PLAYERS, 0.25f, 1.7f, false); }
                kick(s * (heavy ? 0.9f : 0.35f) * near, heavy ? 3.5f : 1.2f * s, heavy ? 3 : 1);
                kickPitch += heavy ? 1.6f : 0.5f;
                if (heavy) setFlash(0x40FFFFFF, 0.25f);
                number(x, y + 0.6, z, m.damage(), heavy ? 0xFFE98A : 0xFFFFFF, heavy);
            }
            case 2 -> { // parry
                for (int i = 0; i < 26; i++) mc.level.addParticle(ParticleTypes.END_ROD, x, y, z, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9);
                mc.level.addParticle(ParticleTypes.FLASH, x, y, z, 0, 0, 0);
                ring(x, y, z, ParticleTypes.END_ROD, 28, 0.35);
                ring(x, y - 0.3, z, ParticleTypes.SNOWFLAKE, 20, 0.25);
                mc.level.playLocalSound(x, y, z, net.minecraft.sounds.SoundEvents.AMETHYST_BLOCK_RESONATE, net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 1.6f, false);
                kick(0.5f * Math.max(near, 0.5f), 5f, 4);
                setFlash(0x60BFE8FF, 0.4f);
            }
            case 3 -> { // shatter
                int n = Math.round(14 + s * 30);
                for (int i = 0; i < n; i++) mc.level.addParticle(iceChunks(), x, y, z, (r.nextDouble() - 0.5) * 0.7, r.nextDouble() * 0.6, (r.nextDouble() - 0.5) * 0.7);
                for (int i = 0; i < 10; i++) mc.level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, (r.nextDouble() - 0.5) * 0.4, r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.4);
                kick(0.25f * s * near, 1.5f * s, 0);
            }
            case 4 -> { // cast burst around the hands / body
                for (int i = 0; i < 18; i++) {
                    double a = r.nextDouble() * Math.PI * 2;
                    mc.level.addParticle(ParticleTypes.SNOWFLAKE, x + Math.cos(a) * 0.5, y, z + Math.sin(a) * 0.5, Math.cos(a) * 0.08, 0.03 + r.nextDouble() * 0.05, Math.sin(a) * 0.08);
                }
                mc.level.addParticle(ParticleTypes.END_ROD, x, y, z, 0, 0.1, 0);
                if (mc.player.getId() == m.entityId()) fov += 2.5f + 3f * s;
            }
            case 5 -> { // dodge afterimage
                for (int i = 0; i < 8; i++) mc.level.addParticle(ParticleTypes.CLOUD, x + (r.nextDouble() - 0.5) * 0.5, y + r.nextDouble() * 1.4 - 0.7, z + (r.nextDouble() - 0.5) * 0.5, 0, 0.01, 0);
                if (mc.player.getId() == m.entityId()) fov += 4f;
            }
            case 6 -> { fov += 7f; setFlash(0x30FFFFFF, 0.5f); ClientState.flowUntil = mc.level.getGameTime() + 200; }
            case 7 -> { vignette = Math.min(1f, vignette + 0.5f + s * 0.5f); kick(0.4f + s * 0.6f, -2f, 2); kickPitch += 1.2f * s; }
            default -> { }
        }
    }

    public static void landing(float fall) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        RandomSource r = mc.level.random;
        for (int i = 0; i < 18; i++) {
            double a = Math.PI * 2 * i / 18.0;
            mc.level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.SNOW_BLOCK.defaultBlockState()), mc.player.getX() + Math.cos(a) * 0.5, mc.player.getY() + 0.1, mc.player.getZ() + Math.sin(a) * 0.5, Math.cos(a) * 0.15, 0.08 + r.nextDouble() * 0.05, Math.sin(a) * 0.15);
        }
        kick(Math.min(0.5f, fall * 0.06f), -Math.min(4f, fall * 0.4f), 1);
        kickPitch += Math.min(2f, fall * 0.25f);
    }

    public static void ring(double x, double y, double z, ParticleOptions p, int n, double speed) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            mc.level.addParticle(p, x, y, z, Math.cos(a) * speed, 0.02, Math.sin(a) * speed);
        }
    }

    private static void kick(float amount, float fovPunch, int stop) {
        shake = Math.min(1.4f, shake + amount);
        fov += fovPunch;
        hitstop = Math.max(hitstop, stop);
    }

    private static void setFlash(int argb, float alpha) { flash = argb; flashAlpha = Math.max(flashAlpha, alpha); }

    private static void number(double x, double y, double z, float v, int color, boolean big) {
        if (v <= 0) return;
        ClientState.NUMBERS.add(new ClientState.Number(x, y, z, v, color, big));
        if (ClientState.NUMBERS.size() > 40) ClientState.NUMBERS.remove(0);
    }

    /** Called every client tick. */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        shake *= 0.82f; if (shake < 0.01f) shake = 0f;
        fov *= 0.8f; if (Math.abs(fov) < 0.05f) fov = 0f;
        flashAlpha *= 0.85f;
        kickPitch *= 0.7f;
        vignette *= 0.92f;
        shakeSeed += 1.7f;
        if (hitstop > 0 && mc.player != null) {
            hitstop--;
            mc.player.setDeltaMovement(mc.player.getDeltaMovement().multiply(0.15, 1.0, 0.15)); // hit-stop: the world feels heavy for a moment
        }
        for (int i = ClientState.NUMBERS.size() - 1; i >= 0; i--) {
            ClientState.Number n = ClientState.NUMBERS.get(i);
            if (++n.age > 26) ClientState.NUMBERS.remove(i);
        }
        if (ClientState.captionTicks > 0) ClientState.captionTicks--;
    }
}
