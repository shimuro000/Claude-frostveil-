package com.Ken.frostveil.client.screen;

import com.Ken.frostveil.client.ClientState;
import com.Ken.frostveil.data.CharacterProfile;
import com.Ken.frostveil.data.FvCap;
import com.Ken.frostveil.data.FvData;
import com.Ken.frostveil.network.FvNet;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * 3D character creator. The model on the right is your own player re-skinned live (painted skin + 3D hair, clothes and face with physics).
 * The option list scrolls with the mouse wheel. Story mode keeps Shimoro and only lets you pick outfit colours; Free World opens everything.
 */
public class CreatorScreen extends Screen {
    private final boolean story;
    private final CharacterProfile profile;
    private final Scroller sc = new Scroller();
    private float spin = 0f;
    private boolean dragging = false;
    private static final List<String> STORY_OPEN = List.of("coat_color", "shirt_color", "trim", "scarf");

    public CreatorScreen(boolean story) {
        super(Component.literal(story ? "Shimoro" : "Create your character"));
        this.story = story;
        FvData cur = FvCap.CLIENT;
        this.profile = story ? CharacterProfile.shimoro() : (cur.created ? cur.profile.copy() : CharacterProfile.defaults());
    }

    private static String pretty(String s) {
        String t = s.replace('_', ' ');
        return t.isEmpty() ? t : Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    @Override
    protected void init() {
        ClientState.preview = profile;
        sc.clear();
        List<CharacterProfile.Option> opts = CharacterProfile.OPTIONS;
        for (int i = 0; i < opts.size(); i++) {
            CharacterProfile.Option o = opts.get(i);
            boolean open = !story || STORY_OPEN.contains(o.key());
            int y = 44 + i * 24;
            Button l = Button.builder(Component.literal("<"), b -> step(o, -1)).bounds(150, y, 20, 20).build();
            Button r = Button.builder(Component.literal(">"), b -> step(o, 1)).bounds(260, y, 20, 20).build();
            l.active = open; r.active = open;
            sc.add(l, y); sc.add(r, y);
            addRenderableWidget(l); addRenderableWidget(r);
        }
        sc.bounds(44, height - 66, 44 + opts.size() * 24);
        int fy = height - 60;
        Button hm = Button.builder(Component.literal("Height -"), b -> profile.height = Mth.clamp(profile.height - 0.02f, 0.85f, 1.15f)).bounds(20, fy, 60, 20).build();
        Button hp = Button.builder(Component.literal("Height +"), b -> profile.height = Mth.clamp(profile.height + 0.02f, 0.85f, 1.15f)).bounds(84, fy, 60, 20).build();
        Button rnd = Button.builder(Component.literal("Randomize"), b -> randomize()).bounds(148, fy, 70, 20).build();
        hm.active = !story; hp.active = !story; rnd.active = !story;
        addRenderableWidget(hm); addRenderableWidget(hp); addRenderableWidget(rnd);
        addRenderableWidget(Button.builder(Component.literal(story ? "Begin the story" : "Create & enter the world"), b -> confirm()).bounds(width - 200, height - 30, 180, 22).build());
        if (FvCap.CLIENT.created) addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> onClose()).bounds(width - 280, height - 30, 70, 22).build());
    }

    private void step(CharacterProfile.Option o, int dir) {
        List<String> v = o.values();
        int i = v.indexOf(o.get().apply(profile));
        String next = v.get(Math.floorMod(i + dir, v.size()));
        if (o.key().equals("eye_color") && next.equals("violet") && !story) next = v.get(Math.floorMod(i + 2 * dir, v.size())); // violet halo is not for players
        o.set().accept(profile, next);
    }

    private void randomize() {
        java.util.Random r = new java.util.Random();
        for (CharacterProfile.Option o : CharacterProfile.OPTIONS) {
            if (o.key().startsWith("parent")) continue;
            String v = o.values().get(r.nextInt(o.values().size()));
            if (v.equals("violet") && o.key().equals("eye_color")) v = "blue";
            o.set().accept(profile, v);
        }
    }

    private void confirm() {
        ClientState.preview = null;
        FvNet.toServer(new FvNet.ProfileMsg(profile.toTag(), story ? FvData.MODE_STORY : FvData.MODE_FREE));
        minecraft.setScreen(null);
    }

    @Override
    public void onClose() {
        ClientState.preview = null;
        super.onClose();
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) { return (x < 300 && sc.wheel(delta)) || super.mouseScrolled(x, y, delta); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xFF0A1220, 0xFF18304A);
        g.drawString(font, title, 20, 12, 0xFFDDF1FF, false);
        g.drawString(font, story ? "Story: you are Shimoro. Only outfit colours can be changed." : "Free World: every option is open. Parents decide your element.", 20, 25, 0xFF8FB4D6, false);
        g.drawString(font, "(mouse wheel scrolls the list)", 20, 36, 0xFF6F8FA8, false);
        List<CharacterProfile.Option> opts = CharacterProfile.OPTIONS;
        for (int i = 0; i < opts.size(); i++) {
            CharacterProfile.Option o = opts.get(i);
            int y = 44 + i * 24 - sc.offset();
            if (y < sc.top() || y + 20 > sc.bottom()) continue;
            g.drawString(font, pretty(o.key()), 20, y + 6, 0xFFB7D3EA, false);
            g.drawCenteredString(font, pretty(o.get().apply(profile)), 215, y + 6, 0xFFFFFFFF);
        }
        sc.bar(g, 286);
        g.drawString(font, "Height: " + Math.round(174 * profile.height) + " cm", 20, height - 36, 0xFF8FB4D6, false);
        if (!dragging) spin += 0.8f;
        int cx = width - 150, cy = height - 80;
        if (minecraft.player != null) {
            float fake = (float) Math.sin(Math.toRadians(spin)) * 70f;
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, cx, cy, 70, fake, -20f, minecraft.player);
        }
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean mouseDragged(double x, double y, double bx, double by, double dx, double dy) {
        if (x > width - 300) { dragging = true; spin += (float) dx * 1.5f; return true; }
        return super.mouseDragged(x, y, bx, by, dx, dy);
    }

    @Override public boolean mouseReleased(double x, double y, int b) { dragging = false; return super.mouseReleased(x, y, b); }
    @Override public boolean isPauseScreen() { return false; }
}
