package com.Ken.frostveil.client.render;

import com.Ken.frostveil.Fv;
import com.Ken.frostveil.client.SkinPainter;
import com.Ken.frostveil.data.CharacterProfile;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 3D character details with simple physics, drawn as small boxes on top of the painted skin:
 * hair (strands that swing with movement, turning and wind), coat tails / cloak / scarf (panels that flow when you walk and run),
 * fur collar, bag and backpack, and the face (3D eyes that blink, eyebrows that react, nose, mouth).
 * Physics = one damped spring per strand segment, driven by the entity's real movement. Tune the numbers in STIFF / DAMP / the style tables.
 * Used for players, NPCs and enemies (any LivingEntity with a CharacterProfile).
 */
public final class Cosmetics {
    static final ResourceLocation WHITE = Fv.id("textures/entity/white.png");
    private static final float STIFF = 0.16f, DAMP = 0.22f;

    /** One chain of segments hanging from an anchor. */
    private static final class Chain {
        final int n;
        final float[] ax, vx, az, vz, pax, paz;
        Chain(int n) { this.n = n; ax = new float[n]; vx = new float[n]; az = new float[n]; vz = new float[n]; pax = new float[n]; paz = new float[n]; }

        void step(float tx, float tz, float stiff, float damp, float follow) {
            for (int i = 0; i < n; i++) {
                pax[i] = ax[i]; paz[i] = az[i];
                float targetX = tx * (i == 0 ? 0.55f : 0.35f) + (i > 0 ? ax[i - 1] * follow : 0f);
                float targetZ = tz * (i == 0 ? 0.55f : 0.35f) + (i > 0 ? az[i - 1] * follow : 0f);
                vx[i] += (targetX - ax[i]) * stiff - vx[i] * damp;
                vz[i] += (targetZ - az[i]) * stiff - vz[i] * damp;
                ax[i] = Mth.clamp(ax[i] + vx[i], -1.25f, 1.25f);
                az[i] = Mth.clamp(az[i] + vz[i], -1.25f, 1.25f);
            }
        }
    }

    private static final class Sim {
        final Map<String, Chain> chains = new HashMap<>();
        int lastTick = -1, seen = 0;
        double lx, ly, lz;
        float lyaw;
        float fwd, side, dy, turn, limb, limbAmt;

        Chain chain(String key, int n) { return chains.computeIfAbsent(key, k -> new Chain(n)); }
    }

    private static final Map<Integer, Sim> SIMS = new HashMap<>();

    private Cosmetics() {}

    // ------------------------------------------------------------------ box helper
    private static void box(PoseStack ps, VertexConsumer vc, int light, float x0, float y0, float z0, float x1, float y1, float z1, int rgb, float a, float shade) {
        PoseStack.Pose pose = ps.last();
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        float r = ((rgb >> 16) & 255) / 255f * shade, g = ((rgb >> 8) & 255) / 255f * shade, b = (rgb & 255) / 255f * shade;
        float[][] faces = {
                {x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, 0, -1, 0, 1.0f},   // top (model +y is down, so y0 is the top)
                {x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, 0, 1, 0, 0.55f},   // bottom
                {x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0, 0, 0, -1, 0.85f},  // front
                {x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1, 0, 0, 1, 0.7f},    // back
                {x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1, -1, 0, 0, 0.75f},  // side
                {x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0, 1, 0, 0, 0.75f}};  // side
        float[][] uv = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
        for (float[] f : faces) {
            float sh = f[15];
            for (int i = 0; i < 4; i++) {
                vc.vertex(m, f[i * 3], f[i * 3 + 1], f[i * 3 + 2]).color(Math.min(1f, r * sh), Math.min(1f, g * sh), Math.min(1f, b * sh), a).uv(uv[i][0], uv[i][1])
                        .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, f[12], f[13], f[14]).endVertex();
            }
        }
    }

    private static void hang(PoseStack ps, VertexConsumer vc, int light, Chain c, float x, float y, float z, float len, float w, float d, int rgb, int rgbEnd, float baseX, float baseZ, float partial) {
        ps.pushPose();
        ps.translate(x, y, z);
        for (int i = 0; i < c.n; i++) {
            float ax = Mth.lerp(partial, c.pax[i], c.ax[i]) + (i == 0 ? baseX : 0f);
            float az = Mth.lerp(partial, c.paz[i], c.az[i]) + (i == 0 ? baseZ : 0f);
            ps.mulPose(Axis.XP.rotation(ax));
            ps.mulPose(Axis.ZP.rotation(az));
            float taper = 1f - 0.3f * i / Math.max(1, c.n);
            box(ps, vc, light, -w * 0.5f * taper, 0, -d * 0.5f * taper, w * 0.5f * taper, len, d * 0.5f * taper, i == c.n - 1 ? rgbEnd : rgb, 1f, 1f);
            ps.translate(0, len, 0);
        }
        ps.popPose();
    }

    // ------------------------------------------------------------------ the layer
    public static final class Layer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
        private final Function<T, CharacterProfile> look;

        public Layer(RenderLayerParent<T, M> parent, Function<T, CharacterProfile> look) {
            super(parent);
            this.look = look;
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, T e, float limbSwing, float limbAmt, float partial, float age, float headYaw, float headPitch) {
            CharacterProfile p = look.apply(e);
            if (p == null || e.isInvisible()) return;
            Sim sim = SIMS.computeIfAbsent(e.getId(), k -> new Sim());
            sim.seen = e.tickCount;
            update(sim, e, limbSwing, limbAmt);
            if (SIMS.size() > 160) SIMS.entrySet().removeIf(en -> Math.abs(en.getValue().seen - e.tickCount) > 400);
            VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(WHITE));
            int hairC = SkinPainter.hair(p.hairColor), hlC = SkinPainter.highlight(p.highlight), skinC = SkinPainter.skin(p.skin);

            ps.pushPose();
            getParentModel().head.translateAndRotate(ps);
            ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
            drawHair(ps, vc, light, p, sim, e, hairC, hlC, partial);
            drawFace(ps, buf, vc, light, p, e, skinC, hairC, partial);
            ps.popPose();

            ps.pushPose();
            getParentModel().body.translateAndRotate(ps);
            ps.scale(1f / 16f, 1f / 16f, 1f / 16f);
            drawClothes(ps, vc, light, p, sim, partial);
            ps.popPose();
        }
    }

    private static void update(Sim s, LivingEntity e, float limbSwing, float limbAmt) {
        if (s.lastTick == e.tickCount) return;
        boolean first = s.lastTick < 0;
        s.lastTick = e.tickCount;
        double dx = first ? 0 : e.getX() - s.lx, dz = first ? 0 : e.getZ() - s.lz, dy = first ? 0 : e.getY() - s.ly;
        s.lx = e.getX(); s.ly = e.getY(); s.lz = e.getZ();
        float yaw = e.yBodyRot;
        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        s.fwd = (float) Mth.clamp(dx * fx + dz * fz, -0.6, 0.6);
        s.side = (float) Mth.clamp(dx * Math.cos(rad) + dz * Math.sin(rad), -0.6, 0.6);
        s.dy = (float) Mth.clamp(dy, -1.0, 1.0);
        s.turn = first ? 0f : Mth.clamp(Mth.wrapDegrees(yaw - s.lyaw), -30f, 30f);
        s.lyaw = yaw;
        s.limb = limbSwing; s.limbAmt = limbAmt;
        float wind = (float) Math.sin(e.tickCount * 0.07 + e.getId()) * 0.05f + (float) Math.sin(e.tickCount * 0.19 + e.getId() * 2) * 0.025f;
        float tx = s.fwd * 3.4f + wind - (s.dy < -0.1f ? 0.35f : 0f) + (e.isCrouching() ? 0.15f : 0f);
        float tz = s.side * 3.4f - s.turn * 0.02f + wind * 0.6f;
        for (Map.Entry<String, Chain> en : s.chains.entrySet()) {
            String k = en.getKey();
            boolean cloth = k.startsWith("c");
            float swing = cloth ? (float) Math.sin(s.limb * 0.6662f + (k.endsWith("l") ? 0 : Math.PI)) * s.limbAmt * 0.55f : 0f;
            en.getValue().step(tx + swing, tz, cloth ? 0.2f : STIFF, cloth ? 0.26f : DAMP, cloth ? 0.55f : 0.45f);
        }
    }

    // ------------------------------------------------------------------ hair
    private static void drawHair(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, LivingEntity e, int hair, int hl, float pt) {
        if (p.hair.equals("bald")) return;
        boolean hasHl = hl >= 0;
        int dark = SkinPainter.shade(hair, 0.82f);
        // scalp volume + fringe (static)
        box(ps, vc, light, -4.45f, -8.55f, -4.45f, 4.45f, -6.9f, 4.45f, hair, 1f, 1f);
        if (!p.hair.equals("topknot")) {
            float[] fx = {-3.4f, -1.7f, 0f, 1.7f, 3.4f};
            for (int i = 0; i < 5; i++) {
                float drop = p.hair.equals("messy") ? 1.2f + ((i * 7) % 3) * 0.7f : (p.hair.equals("wolf_cut") ? 2.2f + (i % 2) : 1.6f + (i % 2) * 0.5f);
                int c = hasHl && i == 3 ? hl : hair;
                box(ps, vc, light, fx[i] - 1.0f, -8.3f, -4.7f, fx[i] + 1.0f, -8.3f + drop + 1.2f, -4.2f, c, 1f, 1f);
            }
        }
        switch (p.hair) {
            case "long_hanging" -> {
                for (int i = 0; i < 7; i++) {
                    float x = -3.6f + i * 1.2f;
                    hang(ps, vc, light, sim.chain("h" + i, 6), x, -7.2f, 3.9f, 2.5f, 1.3f, 1.2f, (hasHl && i % 3 == 1) ? hl : hair, hair, 0.04f, 0f, pt);
                }
                for (int s = -1; s <= 1; s += 2) {
                    hang(ps, vc, light, sim.chain("hs" + s, 5), 4.45f * s, -6.6f, 0.4f, 2.3f, 0.9f, 2.6f, hair, hl >= 0 ? hl : hair, 0f, -0.08f * s, pt);
                }
            }
            case "ponytail" -> {
                box(ps, vc, light, -1.6f, -8.0f, 3.9f, 1.6f, -5.4f, 5.6f, hair, 1f, 1f);
                hang(ps, vc, light, sim.chain("pt", 6), 0f, -7.2f, 5.0f, 2.5f, 2.4f, 2.2f, hair, hasHl ? hl : hair, 0.5f, 0f, pt);
                for (int s = -1; s <= 1; s += 2) hang(ps, vc, light, sim.chain("ps" + s, 3), 4.4f * s, -6.3f, 0.6f, 2.0f, 0.8f, 2.4f, hair, hair, 0f, -0.06f * s, pt);
            }
            case "three_ties" -> {
                for (int i = -1; i <= 1; i++) {
                    hang(ps, vc, light, sim.chain("t" + (i + 1), 5), 2.6f * i, -7.2f, 4.0f, 2.3f, 1.1f, 1.1f, i == 0 && hasHl ? hl : hair, hair, 0.12f, 0f, pt);
                    box(ps, vc, light, 2.6f * i - 0.7f, -6.5f, 3.7f, 2.6f * i + 0.7f, -5.9f, 5.0f, 0xC03030, 1f, 1f); // the tie
                }
                for (int s = -1; s <= 1; s += 2) hang(ps, vc, light, sim.chain("ts" + s, 3), 4.4f * s, -6.4f, 0.3f, 1.8f, 0.8f, 2.2f, hair, hair, 0f, -0.05f * s, pt);
            }
            case "topknot" -> {
                box(ps, vc, light, -2.2f, -11.4f, -1.6f, 2.2f, -8.0f, 2.8f, hair, 1f, 1f);
                hang(ps, vc, light, sim.chain("tk", 3), 0f, -11.0f, 2.8f, 2.2f, 1.5f, 1.5f, hair, hair, 0.3f, 0f, pt);
                box(ps, vc, light, -4.5f, -8.6f, -4.5f, 4.5f, -7.3f, -3.8f, hair, 1f, 1f);
            }
            case "messy" -> {
                java.util.Random r = new java.util.Random(e.getId() * 977L + p.hairColor.hashCode());
                for (int i = 0; i < 9; i++) {
                    float x = -3.6f + r.nextFloat() * 7.2f, z = -3.2f + r.nextFloat() * 6.4f;
                    hang(ps, vc, light, sim.chain("m" + i, 2), x, -8.4f, z, 1.5f + r.nextFloat(), 1.4f, 1.4f, (hasHl && i % 3 == 0) ? hl : hair, dark, -(0.5f + r.nextFloat() * 0.7f) * (z < 0 ? -1 : 1) * 0.6f, (x > 0 ? -1 : 1) * 0.5f, pt);
                }
            }
            case "wolf_cut" -> {
                for (int i = 0; i < 5; i++) hang(ps, vc, light, sim.chain("w" + i, 3), -3.4f + i * 1.7f, -6.4f, 4.0f, 1.9f, 1.8f, 1.2f, (hasHl && i == 2) ? hl : hair, dark, 0.05f, 0f, pt);
                for (int s = -1; s <= 1; s += 2) {
                    hang(ps, vc, light, sim.chain("ws" + s, 3), 4.5f * s, -6.0f, -0.6f, 1.9f, 1.0f, 3.0f, hair, dark, 0f, -0.1f * s, pt);
                    hang(ps, vc, light, sim.chain("wf" + s, 2), 3.0f * s, -8.0f, -4.4f, 1.8f, 1.8f, 0.9f, hair, dark, -0.1f, 0f, pt);
                }
            }
            case "curly" -> {
                java.util.Random r = new java.util.Random(p.hairColor.hashCode() * 31L + e.getId());
                for (int i = 0; i < 12; i++) {
                    double a = i * Math.PI * 2 / 12.0;
                    float x = (float) Math.cos(a) * 4.0f, z = (float) Math.sin(a) * 4.0f;
                    hang(ps, vc, light, sim.chain("cu" + i, 2), x, -7.0f + r.nextFloat() * 1.6f, z, 1.7f, 2.2f, 2.2f, (hasHl && i % 4 == 0) ? hl : hair, dark, 0.1f, 0f, pt);
                }
                box(ps, vc, light, -4.7f, -9.2f, -4.7f, 4.7f, -7.6f, 4.7f, hair, 1f, 1f);
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ face
    private static void drawFace(PoseStack ps, MultiBufferSource buf, VertexConsumer vc, int light, CharacterProfile p, LivingEntity e, int skin, int hair, float pt) {
        int eye = SkinPainter.eye(p.eyeColor);
        boolean violet = p.eyeColor.equals("violet");
        float w = p.eyeShape.equals("sharp") ? 2.5f : (p.eyeShape.equals("soft") ? 2.1f : 2.3f);
        float h = p.eyeShape.equals("sharp") ? 1.25f : (p.eyeShape.equals("soft") ? 1.7f : 1.9f);
        boolean blink = ((e.tickCount + e.getId() * 13) % 96) < 4 || e.isSleeping();
        float hh = blink ? 0.2f : h;
        float y = -3.7f;
        for (int s = -1; s <= 1; s += 2) {
            float x = 2.0f * s;
            box(ps, vc, light, x - w / 2, y - hh / 2, -4.07f, x + w / 2, y + hh / 2, -4.0f, 0xF4F4F8, 1f, 1f);                  // sclera
            if (!blink) {
                int lt = violet ? 15728880 : light;
                box(ps, vc, lt, x - 0.6f, y - Math.min(hh, 1.5f) / 2, -4.14f, x + 0.6f, y + Math.min(hh, 1.5f) / 2, -4.07f, eye, 1f, violet ? 1.35f : 1f); // iris
                box(ps, vc, light, x - 0.25f, y - 0.35f, -4.17f, x + 0.25f, y + 0.35f, -4.14f, 0x101015, 1f, 1f);                  // pupil
                box(ps, vc, 15728880, x + 0.1f, y - 0.6f, -4.19f, x + 0.4f, y - 0.3f, -4.17f, 0xFFFFFF, 1f, 1f);                  // sparkle
            } else {
                box(ps, vc, light, x - w / 2, y - 0.1f, -4.12f, x + w / 2, y + 0.15f, -4.07f, SkinPainter.shade(skin, 0.7f), 1f, 1f);
            }
            if (!p.eyeShape.equals("round") || p.bodyType.equals("female")) // lashes / lids
                box(ps, vc, light, x - w / 2 - 0.1f, y - hh / 2 - 0.4f, -4.12f, x + w / 2 + 0.1f, y - hh / 2, -4.04f, 0x16161C, 1f, 1f);
            // eyebrows react to pain and to the eye shape
            float tilt = (p.eyeShape.equals("sharp") ? 0.22f : (p.eyeShape.equals("soft") ? -0.12f : 0f)) * s;
            if (e.hurtTime > 0) tilt = 0.35f * s;
            ps.pushPose();
            ps.translate(x, y - h / 2 - 1.5f + (e.hurtTime > 0 ? 0.5f : 0f), -4.1f);
            ps.mulPose(Axis.ZP.rotation(tilt));
            float bw = p.brows.equals("thick") ? 1.5f : (p.brows.equals("thin") ? 0.55f : 0.95f);
            box(ps, vc, light, -1.4f, -bw / 2, -0.1f, 1.4f, bw / 2, 0.08f, p.hair.equals("bald") ? SkinPainter.shade(skin, 0.55f) : SkinPainter.shade(hair, 0.9f), 1f, 1f);
            ps.popPose();
        }
        box(ps, vc, light, -0.55f, -2.4f, -4.45f, 0.55f, -1.2f, -4.0f, SkinPainter.shade(skin, 0.93f), 1f, 1f);                   // nose
        boolean mask = violet;
        if (mask) box(ps, vc, light, -3.6f, -1.9f, -4.3f, 3.6f, -0.1f, -4.0f, 0x2B2B33, 1f, 1f);                                   // the Stranger's breathing mask
        else box(ps, vc, light, -1.0f, -0.9f, -4.1f, 1.0f, -0.55f, -4.0f, SkinPainter.shade(skin, 0.7f), 1f, 1f);                  // mouth
        if (violet) { // eerie glow around the eyes
            VertexConsumer g = buf.getBuffer(RenderType.entityTranslucent(WHITE));
            for (int s = -1; s <= 1; s += 2) box(ps, g, 15728880, 2.0f * s - 1.6f, y - 1.2f, -4.25f, 2.0f * s + 1.6f, y + 1.2f, -4.2f, 0xA060FF, 0.35f, 1f);
        }
    }

    // ------------------------------------------------------------------ clothes
    private static void drawClothes(PoseStack ps, VertexConsumer vc, int light, CharacterProfile p, Sim sim, float pt) {
        int coat = SkinPainter.cloth(p.coatColor), trim = SkinPainter.trim(p.trim);
        boolean fur = p.coat.equals("shimoro_coat");
        if (p.coat.equals("shimoro_coat") || p.coat.equals("long_coat")) {
            int end = fur ? trim : SkinPainter.shade(coat, 0.7f);
            hang(ps, vc, light, sim.chain("cfl", 3), 2.1f, 11.2f, -2.4f, 3.4f, 3.9f, 0.7f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfr", 3), -2.1f, 11.2f, -2.4f, 3.4f, 3.9f, 0.7f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cbl", 3), 0f, 11.2f, 2.4f, 3.7f, 8.4f, 0.7f, SkinPainter.shade(coat, 0.9f), end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("csl", 3), 4.35f, 11.0f, 0f, 3.0f, 0.7f, 3.8f, coat, end, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("csr", 3), -4.35f, 11.0f, 0f, 3.0f, 0.7f, 3.8f, coat, end, 0f, 0f, pt);
        } else if (p.coat.equals("cloak")) {
            box(ps, vc, light, -4.8f, -0.6f, -2.6f, 4.8f, 1.2f, 2.9f, coat, 1f, 1f);
            hang(ps, vc, light, sim.chain("cbl", 4), 0f, 1.0f, 2.9f, 3.4f, 9.6f, 0.7f, coat, SkinPainter.shade(coat, 0.7f), 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfl", 3), 4.9f, 1.0f, 0f, 3.6f, 0.7f, 5.2f, coat, coat, 0f, 0f, pt);
            hang(ps, vc, light, sim.chain("cfr", 3), -4.9f, 1.0f, 0f, 3.6f, 0.7f, 5.2f, coat, coat, 0f, 0f, pt);
        }
        if (fur) { // high fur collar
            box(ps, vc, light, -4.7f, -1.4f, -2.8f, 4.7f, 1.2f, 2.8f, trim, 1f, 1f);
            box(ps, vc, light, -4.7f, -2.6f, 1.5f, 4.7f, 0.2f, 2.9f, trim, 1f, 1f);
        }
        if (!p.scarf.equals("none")) {
            int sc = p.scarf.equals("white") ? 0xEDEDF2 : (p.scarf.equals("red") ? 0xB03030 : 0x3A63B8);
            box(ps, vc, light, -4.5f, -0.9f, -2.5f, 4.5f, 0.9f, 2.5f, sc, 1f, 1f);
            hang(ps, vc, light, sim.chain("cscarf", 4), 3.0f, 0.6f, 2.6f, 2.8f, 1.9f, 0.7f, sc, SkinPainter.shade(sc, 0.8f), 0.1f, 0f, pt);
        }
        if (p.waistBag) {
            box(ps, vc, light, -6.0f, 9.6f, -1.8f, -4.0f, 12.6f, 1.8f, 0x5A4126, 1f, 1f);
            box(ps, vc, light, -6.1f, 9.4f, -0.4f, -3.9f, 10.2f, 0.4f, 0xC9A24A, 1f, 1f);
        }
        if (p.lanternBackpack) {
            box(ps, vc, light, -3.2f, 0.8f, 2.4f, 3.2f, 9.5f, 5.0f, 0x5A4126, 1f, 1f);
            hang(ps, vc, 15728880, sim.chain("clant", 1), 0f, 0.6f, 5.1f, 2.0f, 1.8f, 1.8f, 0xFFD36B, 0xFFD36B, 0.2f, 0f, pt);
        }
    }

    /** Called by the creator preview so the character wiggles when you turn it. */
    public static void nudge(int entityId, float x, float z) {
        Sim s = SIMS.get(entityId);
        if (s == null) return;
        for (Chain c : s.chains.values()) { c.vx[0] += x; c.vz[0] += z; }
    }
}
