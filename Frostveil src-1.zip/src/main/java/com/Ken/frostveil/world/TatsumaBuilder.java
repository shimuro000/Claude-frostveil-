package com.Ken.frostveil.world;

import com.Ken.frostveil.registry.ModBlocks;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Builds Tatsuma in code (no NBT needed). From the world-building notes: simple round house-shops, a well in the middle,
 * artificial Soma forest, tents, a blacksmith with an open roof, a big round council hall, a stable, a wooden fence.
 * Coordinates are offsets from the village centre (the well). Tweak the layout in the constants below.
 */
public final class TatsumaBuilder {
    /** name -> {dx, dz}. Used by missions ("poi") and spawning. */
    public static final Map<String, int[]> POIS = new HashMap<>();
    private static final int FLAT = 44;   // flattened radius
    private static final int FENCE = 40;  // fence radius

    /** name, centre x, centre z, radius, beds */
    private static final int[][] HOUSES = {
            {-12, 8, 5, 3}, {-14, -10, 5, 2}, {-6, -17, 4, 2}, {0, -23, 7, 0}, {6, 15, 4, 2}, {-24, -2, 4, 2}, {-20, 18, 4, 2}, {14, -30, 4, 2}, {-8, 30, 4, 2}, {20, 26, 4, 2}};
    private static final String[] HOUSE_NAMES = {"kaina_house", "yu_house", "awi_house", "council_hall", "house_market", "house_w", "house_sw", "house_ne", "house_s", "house_se"};

    private static int[] door(int cx, int cz) {
        int dx = Math.abs(cx) > Math.abs(cz) ? (int) Math.signum(-cx) : 0;
        int dz = dx == 0 ? (int) Math.signum(-cz) : 0;
        return new int[]{dx, dz};
    }

    /** Foot of bed k (0-based) of a house; the head is one block east. */
    private static int[] bedFoot(int cx, int cz, int r, int k) {
        int[] d = door(cx, cz);
        if (d[0] != 0) return new int[]{cx - d[0] * (r - 3), cz + (k - 1) * 2};
        return new int[]{cx - 2 + k * 2, cz - d[1] * (r - 3)};
    }

    static {
        POIS.put("center", new int[]{0, 0});
        POIS.put("spawn", new int[]{26, -16});          // near Awi's training square, dawn
        POIS.put("awi_table", new int[]{26, -8});
        POIS.put("watch_spot", new int[]{26, -30});      // behind the dry tree
        POIS.put("kaina_table", new int[]{-3, 14});
        POIS.put("council", new int[]{0, -16});
        POIS.put("forge", new int[]{16, 12});
        POIS.put("stable", new int[]{25, 4});
        POIS.put("market", new int[]{8, 21});
        POIS.put("farm", new int[]{31, 16});
        POIS.put("soma_forest", new int[]{-40, -40});
        POIS.put("north_gate", new int[]{0, -FENCE});
        POIS.put("south_gate", new int[]{0, FENCE});
        POIS.put("road_clearing", new int[]{0, 96});
        POIS.put("road_post", new int[]{0, 130});
        for (int i = 0; i < HOUSES.length; i++) {
            int cx = HOUSES[i][0], cz = HOUSES[i][1], r = HOUSES[i][2], beds = HOUSES[i][3];
            int[] d = door(cx, cz);
            POIS.put(HOUSE_NAMES[i], new int[]{cx + d[0] * (r + 1), cz + d[1] * (r + 1)});
            for (int k = 0; k < beds; k++) { int[] b = bedFoot(cx, cz, r, k); POIS.put(HOUSE_NAMES[i] + "_bed" + (k + 1), new int[]{b[0], b[1]}); }
        }
        POIS.put("council", new int[]{0, -16});
        for (int i = 0; i < 6; i++) { double a = i * Math.PI / 3.0; POIS.put("council_seat" + (i + 1), new int[]{(int) Math.round(Math.cos(a) * 3), -23 + (int) Math.round(Math.sin(a) * 3)}); }
        POIS.put("council_corner", new int[]{-5, -20});
        POIS.put("wake_spot", new int[]{-22, -22});
    }

    private TatsumaBuilder() {}

    private static void set(ServerLevel l, int x, int y, int z, Block b) { l.setBlock(new BlockPos(x, y, z), b.defaultBlockState(), 2); }
    private static void set(ServerLevel l, int x, int y, int z, BlockState s) { l.setBlock(new BlockPos(x, y, z), s, 2); }

    public static void build(ServerLevel l, FrostveilWorld.Data data) {
        int base = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, 0, 0) - 1;
        base = Math.max(base, l.getSeaLevel() + 1);
        data.baseY = base;
        RandomSource rnd = l.getRandom();
        // 1. flatten and cover with snowy grass
        for (int x = -FLAT - 2; x <= FLAT + 2; x++) {
            for (int z = -FLAT - 2; z <= FLAT + 2; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d > FLAT + 2) continue;
                for (int y = base - 5; y < base; y++) set(l, x, y, z, Blocks.DIRT);
                set(l, x, base, z, d > FLAT - 1 ? Blocks.SNOW_BLOCK : Blocks.GRASS_BLOCK);
                for (int y = base + 1; y <= base + 24; y++) set(l, x, y, z, Blocks.AIR);
                if (d <= FLAT - 1) l.setBlock(new BlockPos(x, base + 1, z), Blocks.SNOW.defaultBlockState().setValue(SnowLayerBlock.LAYERS, 1 + rnd.nextInt(2)), 2);
            }
        }
        // 2. paths: cross roads and a ring path
        for (int i = -FENCE; i <= FENCE; i++) { path(l, i, 0, base); path(l, 0, i, base); path(l, i, 1, base); path(l, 1, i, base); }
        for (int a = 0; a < 720; a++) { double r = 6; path(l, (int) Math.round(Math.cos(a * Math.PI / 360) * r), (int) Math.round(Math.sin(a * Math.PI / 360) * r), base); }
        // 3. the well
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
            boolean edge = Math.abs(x) == 2 || Math.abs(z) == 2;
            set(l, x, base + 1, z, edge ? Blocks.COBBLESTONE : Blocks.AIR);
            if (!edge) { set(l, x, base, z, Blocks.WATER); }
        }
        for (int[] c : new int[][]{{-2, -2}, {2, -2}, {-2, 2}, {2, 2}}) for (int y = 2; y <= 4; y++) set(l, c[0], base + y, c[1], Blocks.SPRUCE_FENCE);
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) set(l, x, base + 5, z, Blocks.SPRUCE_SLAB);
        // 4. houses (round, doors facing the well)
        for (int i = 0; i < HOUSES.length; i++) house(l, HOUSES[i][0], HOUSES[i][1], HOUSES[i][2], HOUSES[i][2] == 7 ? 5 : 4, HOUSES[i][3], base);
        // kaina's soup corner: long table, pot on a fire
        for (int x = -6; x <= 0; x++) { set(l, x, base + 2, 12, Blocks.SPRUCE_SLAB); set(l, x, base + 1, 12, Blocks.SPRUCE_FENCE); }
        set(l, -3, base + 1, 14, Blocks.CAMPFIRE); set(l, -3, base + 2, 14, Blocks.CAULDRON);
        // 5. forge with an open roof
        forge(l, 16, 12, base);
        // 6. stable
        for (int x = 21; x <= 30; x++) for (int z = 0; z <= 7; z++) {
            if (x == 21 || x == 30 || z == 0 || z == 7) { if (!(x == 21 && z == 3)) set(l, x, base + 1, z, Blocks.SPRUCE_FENCE); }
        }
        set(l, 28, base + 1, 5, Blocks.HAY_BLOCK); set(l, 27, base + 1, 5, Blocks.HAY_BLOCK); set(l, 29, base + 1, 2, Blocks.WATER_CAULDRON);
        // 7. Awi's training square: table + the dry tree twenty steps away
        set(l, 26, base + 1, -8, Blocks.SPRUCE_FENCE); set(l, 26, base + 2, -8, Blocks.SPRUCE_PRESSURE_PLATE);
        deadTree(l, 26, -30, base);
        // 8. tents
        tent(l, -30, -16, base, Blocks.WHITE_WOOL); tent(l, -32, -8, base, Blocks.LIGHT_GRAY_WOOL);
        farm(l, 31, 16, base);
        // 9. market stalls
        for (int i = 0; i < 3; i++) stall(l, 2 + i * 4, 22, base);
        // 10. fence ring with gates (north and south)
        for (int a = 0; a < 1440; a++) {
            double ang = a * Math.PI / 720.0;
            int x = (int) Math.round(Math.cos(ang) * FENCE), z = (int) Math.round(Math.sin(ang) * FENCE);
            if (Math.abs(x) <= 2 && Math.abs(z) >= FENCE - 3) continue; // gates
            set(l, x, base + 1, z, Blocks.SPRUCE_FENCE); set(l, x, base + 2, z, Blocks.SPRUCE_FENCE);
        }
        for (int s : new int[]{-1, 1}) for (int x : new int[]{-3, 3}) for (int y = 1; y <= 4; y++) set(l, x, base + y, s * FENCE, Blocks.SPRUCE_LOG);
        // 11. road south toward Arabisel, and a small road post
        for (int z = FLAT; z <= 130; z++) {
            int ty = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, 0, z) - 1;
            for (int x = -1; x <= 1; x++) set(l, x, ty, z, Blocks.DIRT_PATH);
        }
        // 12. Soma Forest (outside the fence, north-west)
        somaForest(l, -52, -52, rnd);
    }

    /** A fenced crop field with a water channel; farmers and chickens live here. */
    private static void farm(ServerLevel l, int cx, int cz, int base) {
        for (int x = -4; x <= 4; x++) for (int z = -3; z <= 3; z++) {
            boolean edge = Math.abs(x) == 4 || Math.abs(z) == 3;
            if (edge) { if (!(z == 3 && x == 0)) set(l, cx + x, base + 1, cz + z, Blocks.SPRUCE_FENCE); continue; }
            if (z == 0) { set(l, cx + x, base, cz + z, Blocks.WATER); continue; }
            set(l, cx + x, base, cz + z, Blocks.FARMLAND);
            Block crop = (x + z) % 3 == 0 ? Blocks.POTATOES : ((x + z) % 3 == 1 ? Blocks.CARROTS : Blocks.WHEAT);
            l.setBlock(new BlockPos(cx + x, base + 1, cz + z), crop.defaultBlockState().setValue(CropBlock.AGE, 3), 2);
        }
    }

    private static void path(ServerLevel l, int x, int z, int base) {
        set(l, x, base, z, Blocks.DIRT_PATH);
        set(l, x, base + 1, z, Blocks.AIR);
    }

    /** Round building: walls, floor, door facing the village centre, windows, conical roof. */
    private static void house(ServerLevel l, int cx, int cz, int r, int h, int beds, int base) {
        int doorX = Math.abs(cx) > Math.abs(cz) ? (int) Math.signum(-cx) : 0;
        int doorZ = doorX == 0 ? (int) Math.signum(-cz) : 0;
        for (int x = -r - 1; x <= r + 1; x++) for (int z = -r - 1; z <= r + 1; z++) {
            double d = Math.sqrt(x * x + z * z);
            int wx = cx + x, wz = cz + z;
            if (d <= r - 0.5) set(l, wx, base, wz, Blocks.SPRUCE_PLANKS);
            if (d <= r + 0.5 && d > r - 0.5) {
                for (int y = 1; y <= h; y++) set(l, wx, base + y, wz, y == 1 ? Blocks.COBBLESTONE : Blocks.SPRUCE_PLANKS);
                boolean door = (doorX != 0 && x * doorX > r - 2 && Math.abs(z) <= 0) || (doorZ != 0 && z * doorZ > r - 2 && Math.abs(x) <= 0);
                if (door) { set(l, wx, base + 1, wz, Blocks.AIR); set(l, wx, base + 2, wz, Blocks.AIR); }
                else if (((x + z) % 4 == 0) && Math.abs(x) + Math.abs(z) > r) set(l, wx, base + 3, wz, Blocks.GLASS_PANE);
            }
        }
        for (int k = 0; k <= r + 1; k++) {
            double rr = r + 1.2 - k * ((r + 1.2) / (r + 1.5));
            for (int x = -r - 2; x <= r + 2; x++) for (int z = -r - 2; z <= r + 2; z++) {
                if (Math.sqrt(x * x + z * z) <= rr) set(l, cx + x, base + h + 1 + k, cz + z, k >= r ? Blocks.SNOW_BLOCK : Blocks.DARK_OAK_PLANKS);
            }
        }
        set(l, cx, base + 1, cz, Blocks.CRAFTING_TABLE);
        set(l, cx + 1, base + 1, cz + 1, Blocks.BARREL);
        set(l, cx - 1, base + 3, cz, Blocks.LANTERN);
        if (r == 7) { // the council hall: a round table in the middle
            for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) if (Math.sqrt(x * x + z * z) <= 2.3) set(l, cx + x, base + 2, cz + z, Blocks.SPRUCE_SLAB);
            set(l, cx, base + 1, cz, Blocks.SPRUCE_FENCE);
        }
        for (int k = 0; k < beds; k++) {
            int[] b = bedFoot(cx, cz, r, k);
            BlockState foot = Blocks.RED_BED.defaultBlockState().setValue(BedBlock.FACING, Direction.EAST).setValue(BedBlock.PART, BedPart.FOOT);
            set(l, b[0], base + 1, b[1], foot);
            set(l, b[0] + 1, base + 1, b[1], foot.setValue(BedBlock.PART, BedPart.HEAD));
        }
    }

    private static void forge(ServerLevel l, int cx, int cz, int base) {
        for (int x = -4; x <= 4; x++) for (int z = -4; z <= 4; z++) set(l, cx + x, base, cz + z, Blocks.STONE_BRICKS);
        for (int[] c : new int[][]{{-4, -4}, {4, -4}, {-4, 4}, {4, 4}}) for (int y = 1; y <= 5; y++) set(l, cx + c[0], base + y, cz + c[1], Blocks.SPRUCE_LOG);
        for (int x = -4; x <= 4; x++) { set(l, cx + x, base + 5, cz - 4, Blocks.SPRUCE_LOG); set(l, cx + x, base + 5, cz + 4, Blocks.SPRUCE_LOG); }
        for (int z = -4; z <= 4; z++) { set(l, cx - 4, base + 5, cz + z, Blocks.SPRUCE_LOG); set(l, cx + 4, base + 5, cz + z, Blocks.SPRUCE_LOG); } // open roof: only a frame
        set(l, cx, base + 1, cz - 3, Blocks.BLAST_FURNACE); set(l, cx + 2, base + 1, cz - 3, Blocks.ANVIL); set(l, cx - 2, base + 1, cz - 3, Blocks.WATER_CAULDRON);
        set(l, cx + 3, base + 1, cz + 2, Blocks.GRINDSTONE);
    }

    private static void tent(ServerLevel l, int cx, int cz, int base, Block wool) {
        for (int k = 0; k < 4; k++) for (int x = -3 + k; x <= 3 - k; x++) for (int z = -3 + k; z <= 3 - k; z++) {
            boolean shell = Math.abs(x) == 3 - k || Math.abs(z) == 3 - k;
            if (shell) set(l, cx + x, base + 1 + k, cz + z, wool);
        }
        set(l, cx, base + 1, cz + 3, Blocks.AIR); set(l, cx, base + 2, cz + 3, Blocks.AIR);
        set(l, cx, base + 1, cz, Blocks.CAMPFIRE);
    }

    private static void stall(ServerLevel l, int cx, int cz, int base) {
        for (int x = 0; x < 3; x++) { set(l, cx + x, base + 1, cz, Blocks.SPRUCE_SLAB); set(l, cx + x, base + 4, cz - 1, Blocks.RED_WOOL); set(l, cx + x, base + 4, cz, Blocks.WHITE_WOOL); }
        set(l, cx, base + 1, cz - 1, Blocks.SPRUCE_FENCE); set(l, cx, base + 2, cz - 1, Blocks.SPRUCE_FENCE); set(l, cx, base + 3, cz - 1, Blocks.SPRUCE_FENCE);
        set(l, cx + 2, base + 1, cz - 1, Blocks.SPRUCE_FENCE); set(l, cx + 2, base + 2, cz - 1, Blocks.SPRUCE_FENCE); set(l, cx + 2, base + 3, cz - 1, Blocks.SPRUCE_FENCE);
        set(l, cx + 1, base + 2, cz, Blocks.BARREL);
    }

    private static void deadTree(ServerLevel l, int x, int z, int base) {
        for (int y = 1; y <= 8; y++) set(l, x, base + y, z, Blocks.SPRUCE_LOG);
        for (int[] b : new int[][]{{1, 0}, {2, 0}, {3, 1}, {-1, 0}, {-2, 1}, {0, 1}, {0, 2}, {0, -1}, {-1, -2}}) {
            set(l, x + b[0], base + 5 + Math.abs(b[1]) + 1, z + b[1], Blocks.SPRUCE_LOG);
        }
    }

    /** Soma trees: bare trunks with branches, spaced for walkways. Cutting them gives soma firewood. */
    private static void somaForest(ServerLevel l, int cx, int cz, RandomSource rnd) {
        for (int gx = 0; gx < 6; gx++) for (int gz = 0; gz < 6; gz++) {
            int x = cx + gx * 5 + rnd.nextInt(2), z = cz + gz * 5 + rnd.nextInt(2);
            int y0 = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z);
            int h = 6 + rnd.nextInt(4);
            for (int y = 0; y < h; y++) set(l, x, y0 + y, z, ModBlocks.SOMA_LOG.get());
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                if (rnd.nextBoolean()) {
                    for (int k = 1; k <= 2; k++) set(l, x + dir.getStepX() * k, y0 + h - 2, z + dir.getStepZ() * k, ModBlocks.SOMA_LOG.get().defaultBlockState().setValue(net.minecraft.world.level.block.RotatedPillarBlock.AXIS, dir.getAxis()));
                    set(l, x + dir.getStepX() * 2, y0 + h - 1, z + dir.getStepZ() * 2, Blocks.SPRUCE_LEAVES.defaultBlockState().setValue(net.minecraft.world.level.block.LeavesBlock.PERSISTENT, true));
                }
            }
            if (rnd.nextInt(3) == 0) for (int y = 1; y < 5; y++) set(l, x + 1, y0 + y, z, Blocks.LADDER.defaultBlockState().setValue(net.minecraft.world.level.block.LadderBlock.FACING, Direction.EAST));
        }
    }

    /** The raid leaves a mark: Awi's house burns, part of the crop is gone. */
    public static void burnHouse(ServerLevel l, FrostveilWorld.Data data) {
        int base = data.baseY;
        int cx = -6, cz = -17, r = 4;
        RandomSource rnd = l.getRandom();
        for (int x = -r - 2; x <= r + 2; x++) for (int z = -r - 2; z <= r + 2; z++) for (int y = 0; y <= 12; y++) {
            BlockPos p = new BlockPos(cx + x, base + y, cz + z);
            BlockState s = l.getBlockState(p);
            if (s.isAir() || y == 0) continue;
            float c = rnd.nextFloat();
            if (c < 0.28f) l.setBlock(p, Blocks.AIR.defaultBlockState(), 2);
            else if (c < 0.6f) l.setBlock(p, Blocks.COAL_BLOCK.defaultBlockState(), 2);
            else if (c < 0.7f) l.setBlock(p, Blocks.BLACKSTONE.defaultBlockState(), 2);
        }
        for (int i = 0; i < 6; i++) l.setBlock(new BlockPos(cx + rnd.nextInt(5) - 2, base + 1, cz + rnd.nextInt(5) - 2), Blocks.FIRE.defaultBlockState(), 2);
    }
}
