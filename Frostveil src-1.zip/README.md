# Frostveil (Minecraft Java 1.20.1, Forge 47.x)

Story-driven action RPG built on the EIU system. You play as Shimoro.
Version **1.2.0** ("Story and Raid" update).

## Required mods (put all jars in `mods/`)
| Mod | Version | Needed by |
|---|---|---|
| Minecraft Forge | 1.20.1, 47.2.0 or newer (built against 47.3.0) | everything |
| **Player Animation Library** (`playeranimator`, by KosmX) | 1.0.2-rc1 for 1.20 (Forge) | player animations (client) |

Nothing else is required. (GeckoLib is not used in this version.)

## Build
Push the CONTENTS of this folder to the root of your GitHub repo (so `settings.gradle` sits at the repo root) and run the
"Build Frostveil" workflow. The jar appears under *Actions -> run -> Artifacts*. Locally: `gradle build` (Gradle 8.1.1, JDK 17).

## Play
1. Install Forge 1.20.1, drop in Frostveil and Player Animation Library, create a world (or join one).
2. On first join the Frostveil menu opens (also `/frostveil menu`): **Story Mode** (you are Shimoro) or **Free World**.
3. Story starts at dawn in Tatsuma (dimension `frostveil:world`).
Testing helpers (operators): `/frostveil unlock`, `/frostveil points <n>`, `/frostveil mission <id>`, `/frostveil aura`, `/frostveil tatsuma`, `/frostveil reset`.

## Keys (all rebindable under Controls -> Frostveil)
F cast (hold = Mental, release near the ring = perfect) | R Shape Studio | N next recipe | T next ice form | G feel the core (hold, stand still)
Z Skin Sense | X Forge (hold) | V change Forge limb | C Cutoff (tap) / EIU Shroud (hold) | B Infuse held item
H Ice Halo on/off | J release Halo shards | K character sheet | L journal | Left Alt dodge | U companion order
Left click (not on a block) = 3-hit combo, sprint + click = heavy | Right mouse (empty hand or sword) = guard; guard just before a hit = parry.

## The creative ice system (Shape Studio, R)
Each recipe = base shape + knobs. Shapes: sphere, wall, spike, shard, blade, disc, lance, cluster (unlocked by the story).
Knobs: length, width, curve, spread, spin, count. What it does: **launch**, **hold** (a weapon in your hand: reach, damage and look follow the recipe),
**place** (temporary ice blocks that crack and shatter), **orbit** (Ice Halo). **Freehand**: turn it on, hold F and sweep the crosshair: the stroke becomes
a wall, a floor/bridge or a tunnel. Snowmaker: snowfields (slow enemies, cheaper ice, Skin Sense bonus) and a snow brush. Ice Halo: orbiting shards
(ring / spiral / shell) that intercept projectiles and can be released at a target.
Limits come from your three control levels: Shimoro starts with a **reach of 3 blocks** (Level 3 weakness): ice shaped farther away breaks.
Playstyle: every cast trains one of 6 styles (Blade Dancer, Shard Barrage, Glacier Wall, Frost Strider, Snow Warden, Halo Keeper); at 40 uses each unlocks a perk.

## Customising (files to edit)
- Story: `data/frostveil/missions/*.json`, `data/frostveil/dialogues/*.json` (action script documented in `story/Actions.java`).
- Animations: `client/fx/Anims.java` (arrays of radians per body part).
- Impact feel: `client/fx/Juice.java` (shake, FOV punch, hit-stop, particles).
- Character options: `data/CharacterProfile.java`; look painting: `client/SkinPainter.java`.
- NPC looks/stats: `entity/NpcDefs.java` (or drop `assets/frostveil/textures/entity/npc/<id>.png`).
- Village layout: `world/TatsumaBuilder.java`.
- Textures are placeholders (generated); see `ASSETS.md`.


## What is new in 1.1.0
- **Fixed:** holding G now awakens EIU (story and Free World); the sphere is unlocked on awakening (it blocked Fang's lesson); short tries count as failed tries.
- **Compass for every mission:** top-centre compass + a tall objective beam in the world; it follows NPCs, Fargas and hostile enemies live. Journal has "Skip current objective" if anything ever sticks; stuck objectives also time out by themselves.
- **The Stranger (Fargas):** appears right in front of you with a boss bar, smoke and a painted look (breathing mask, glowing violet eyes), cannot stall the scene.
- **3D character:** real 3D hair with spring physics (long, ponytail, three ties, topknot, messy, wolf cut, curly), coat tails / cloak / scarf that flow when you move, fur collar, bag and lantern backpack, 3D eyes that blink, brows that react, nose and mouth. Works on players, NPCs and enemies.
- **Living village:** ~30 people with homes, beds, daily schedules (cook, forge, farm, market, patrol, train, play, sleep), special abilities (Awi dash, Yu frost burst, Fang slam, Kaina bow), speech bubbles, merchants you can buy from (Tenn), horses and chickens, a farm, more houses.
- **More impact:** sweeping slash arcs per combo hit, attack lunge, charge audio that rises to the perfect moment, FOV squeeze while charging, parry shockwave, landing and sprint dust, Skin Sense ripples, Forge sparks, Flow trails.


## What is new in 1.2.0
- **Menus scroll** with the mouse wheel (creator, Shape Studio, character sheet, journal) and a scroll bar shows where you are. Buttons that are scrolled out of view are hidden, so nothing overlaps (the Skip objective button now has its own place).
- **No vanilla monsters** in the Frostveil world (zombies, creepers, skeletons, spiders, phantoms...). Only Frostveil's own enemies exist.
- **Duplicate / fighting bug fixed:** villagers are created once (when the village is built) and only come back if they died; duplicates among loaded NPCs are removed automatically. Friends never attack each other (children's snowballs are harmless, a sparring Fang or Ryo is only hostile to you).
- **Story, closer to the chapters:** the stranger freezes you, grabs your wrist and you faint -> you wake on Awi's horse -> you run back -> Kaina, Awi and Yu fight him with you until he leaves -> Igor and the smith arrive late -> Kaina checks on you -> the real council meeting at the round table (Yu, Kaina, Awi, Igor, Tetsu, the smith; Fang walks in) -> you ask Fang to train you.
- **Ash Knight raid:** exactly 10 knights come through the north gate and march into the village; Awi, Yu, Kaina, the guards, hunters and you fight them. The mission completes only when all 10 are down, then any leftover raider is cleared.
